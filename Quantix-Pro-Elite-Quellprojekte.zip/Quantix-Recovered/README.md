Elite 3.10.21 (2026-10-16): Reviewed user-provided Risxn Process Lowering Pack V4 and video HUPQTyaCR50 as data; no third-party executable or batch script run or bundled. Added six allowlisted Feedback/CEIP/offline-map scheduled triggers to automatic cleanup. Durable original enabled state and normalized task-definition fingerprint before disabling; OFF restores original enabled state; changed/missing definitions and managed-device restoration conflicts retain recovery records. No tasks deleted and no active tasks forcibly terminated. Games, Store, Xbox/licensing, sign-in, updates, browser updaters, Bluetooth, printing, VPN, encryption, clock synchronization and maintenance preserved. No blanket startup disabling. Animated purple optimization panel: rotating ring, pulsing glow, real completed-item progress, per-stage text and collapsed detailed report; animations stop on completion/error and respect reduced-motion preference. Process/FPS target unverified; no live cleanup applied.

Elite 3.10.20 (2026-10-16): Expanded automatic cleanup to 12 exact optional app names, six optional services and two version/edition-gated Widgets/news-feed policies. Apps removed only for the account running Elite; no provisioning, all-user removal, Win32 uninstallers or dependency/runtime removal. OFF restores saved service settings and policy values/absence, not removed apps. Managed/unverified devices skip new service/policy changes; existing nonzero admin policies and dependent/paused services preserved. Windows Search removed from new-change targets, with legacy backup restoration retained. Process before/after snapshots and per-item progress shown; no process-count or FPS promise. Core services, browsers, Discord, Steam, Xbox/game launchers, anti-cheat, runtimes, WebView2, Store, Search, Get Help, updates, security, devices and networking excluded. No live cleanup applied during development.
Policy sources: https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-newsandinterests ; https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-feeds

Elite 3.10.19: Consolidated nine CPU/chipset/port ASPM definitions into one grouped PCIe ASPM control. Added explicit grouped matching for repeated Core Performance Boost, Global C-state and DDR power-down questions; validates each firmware key and target label, patches every matched member, saves changed members individually, restores only saved members with conflict checks. Already-at-target members do not gain invented originals. Group write policy now allowlists each matched key. Duplicate key collisions and unsupported target choices still block the group. No PBO, voltages, memory profiles, security bypasses or claims that missing firmware settings have become exposed. No live firmware writes.

Elite 3.10.18: BIOS page renders only settings resolved uniquely in this customer's export. No full catalog, unavailable/other CPU/guidance switches or unsupported-settings expander. Unscanned state shows a scan prompt; zero-match state explains no supported controls found and retains recovery access. UI count is matched controls, not full catalog or FPS gains. Firmware matching/write policy unchanged; this presentation change does not unlock missing firmware settings.

Elite 3.10.17: Gaming performance section appears first. Added AMD stock Core Performance Boost (Auto), AMD memory-channel interleaving (Enabled), Intel Turbo Boost, Speed Shift and SpeedStep. Existing ReBAR and AMD CPPC controls moved into that section. Exact unique firmware matching, CPU-vendor checks, existing ReBAR boot prerequisites and original-value restore retained. No PBO/voltage/clock/timing changes. Customer saved export has duplicate Core Performance Boost addresses; boost remains unavailable there. Auto memory interleaving may already be effective; enabling its preference is not evidence of faster gaming. Existing ReBAR/CPPC already enabled in saved export. No live firmware writes or FPS measurement.
Sources: https://www.amd.com/en/resources/support-articles/faqs/CPU-PB2.html ; https://www.intel.com/content/www/us/en/gaming/resources/how-intel-technologies-boost-cpu-performance.html ; https://gpuopen.com/learn/get-the-most-out-of-smart-access-memory/

Elite 3.10.16: Added Fusion Message C State, SB C1E Support, memory power-down, ErP Ready and ACPI standby definitions. Catalog: 44 definitions; availability requires unique firmware option identity and matching CPU vendor. Saved customer export matches 19 definitions, including individual PCIe ports; this is not 19 different performance improvements. Duplicate C-state/memory/ECO addresses remain blocked. ACPI standby disables sleep; ErP changes standby power, neither is an FPS optimization. No firmware writes performed during verification.

## Elite 3.10.15 — BIOS mapping expansion
Eight scoped firmware ASPM definitions added: Dev1/Func2, Dev2/Func1, Dev2/Func2, Device4/5/6/7 and the separate chipset ASPM setting. Each requires one exact exposed firmware question and target choice; duplicate identities remain rejected. Addresses, values and connected-device identity are never guessed. These PCIe idle-power experiments may increase power or affect device/sleep behavior; they are not a broad automatic FPS preset.
Latest saved customer export matches 17 catalog entries (previously 9); catalog now 39. Seven new port settings have Auto baselines and separate Disabled targets; the chipset setting is already Disabled. Matched settings appear first; unsupported, ambiguous, other-CPU and manual-validation entries remain in a collapsed full-catalog section after a scan. Existing single-switch apply, durable originals, fresh-read conflict handling and isolated OFF restoration retained. This does not implement every AdamX/CPU/memory setting or make inaccessible firmware writable across all motherboards.
PASS: 179 parser/policy/navigation checks, including all new preset fixtures and exact single-setting/restore round trips on the actual saved BIOS export. Saved-export preview rendered/inspected. No SCEWIN invocation or firmware writes during development; live firmware apply and cross-motherboard validation remain untested. GPU, cleanup and Pro unchanged.
## Elite 3.10.14 — seven distinct extra GPU controls
Below NVIDIA Profile Inspector and the existing GPU rows: 1) GPU MSI mode; 2) AC PCIe link power saving off; 3) NVIDIA global FPS limiter off; 4) background apps capped at 30 FPS; 5) OpenGL triple buffering off; 6) Windows MPO disabled for optional flicker troubleshooting; 7) Vulkan/OpenGL DXGI presentation preference. The Windows per-game controls remain below. Header counts include the added controls. No new setting ID overlaps the bundled 28-setting Quantix profile; old duplicates are available only for recovery when originals were saved.
Native NVIDIA choices use public NVIDIA settings IDs, with original explicit/predefined state saved before writes, readback and isolated OFF restoration. MPO uses NVIDIA's documented HKLM SOFTWARE/Microsoft/Windows/Dwm OverlayTestMode=5 workaround, saved/restored exactly including absence. It requires admin and reboot and is not recommended as a blanket FPS optimization. Windows PCIe policy affects all PCIe links on AC, not only GPU; battery settings unchanged. Background limiting does not improve active-game FPS. Triple buffering/presentation options depend on application API and workload. Already configured values are shown truthfully; no default value invented for OFF without a saved original.
PASS: 63 checks including all new setting targets/restores, conflicts, failures, absent/predefined/custom baselines, MSI hardware capability/admin/driver changes, PCIe plan conflicts, live read-only checks, profile non-overlap and 7-row count. UI top and lower sections rendered/inspected. No live writes or FPS/latency benchmarks executed. No universal stability/performance guarantee. Pro, BIOS and cleanup unchanged.
NVIDIA references: https://www.nvidia.com/content/Control-Panel-Help/vLatest/en-us/mergedProjects/3D%20Settings/Manage_3D_Settings_(reference).htm ; https://nvidia.custhelp.com/app/answers/detail/a_id/5157 ; public NVIDIA/nvapi headers. Downloaded official mpo_disable.reg was read only, never imported.
## Elite 3.10.13 — separate GPU hardware controls
The seven overlapping NVIDIA Profile Inspector switches have been removed from the main list. If a prior switch has a saved backup, a collapsed recovery section allows restoring originals; no new profile tweaks are offered there. Profile Inspector stays first, followed by existing controls, new hardware controls, then per-game preferences.
New GPU MSI mode switch: enumerates present NVIDIA PCI display devices, reads DEVPKEY_PciDevice_InterruptSupport and requires the MSI capability bit. Saves the original MSISupported DWORD or absence before changes. Verifies configuration readback and restores exact original. Admin and restart required. Driver changes or unsupported devices block new application; interrupt priority and message limits remain unchanged. Registry configuration does not prove live interrupt allocation. This PC already has MSISupported=1.
New PCIe link power-saving switch: sets AC-only Link State Power Management to Off in the current Windows plan through documented Windows power APIs. Affects ALL PCIe links, not just GPU. Battery settings unchanged. Original plan/value journal retained on failure; external changes and different active plans block restoration. This PC already has AC ASPM=0. No undocumented NVIDIA power-gating override re-enabled; no 7-unique-tweaks claim or FPS guarantee.
PASS: 65 mocked graphics/MSI/power backup, restore, capabilities, admin, driver/plan changes and actual UI checks. Live reads only; no live registry or power changes during development. Pro, BIOS and cleanup unchanged.
Sources: https://learn.microsoft.com/en-us/windows-hardware/drivers/kernel/enabling-message-signaled-interrupts-in-the-registry and https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/pci-express-settings-link-state-power-management ; MSI capability bits from Microsoft Windows SDK pciprop.h.
## Elite 3.10.12 — NVIDIA switches and GPU layout
NVIDIA Profile Inspector remains first. Seven native NVIDIA driver-setting switches now appear below existing GPU controls: maximum performance, highest refresh rate, driver V-Sync off, OpenGL threading, anisotropic sample optimization, anisotropic filter optimization, and trilinear optimization. The two Windows per-game controls follow below them. These are GLOBAL NVIDIA base-profile changes. Original explicit values or predefined inheritance are saved durably before changes; OFF restores only that setting. External changes and failed readback retain backups. Driver support is checked by reading settings, not guessed registry keys. Restart games and benchmark individual changes; no FPS or stability guarantee.
Native IDs, struct ABI and interface IDs sourced from NVIDIA/nvapi headers (NvApiDriverSettings.h, nvapi.h, nvapi_interface.h). All seven read successfully on this PC's RTX 3060. No live driver writes were executed during development; write/restore/failure/conflict behavior tested through a mock driver. Actual top/bottom GPU layouts rendered and inspected. Pro, cleanup and BIOS unchanged.
AMD currently has 10 visible existing vendor entries: DMA Copy, Block Write, Stutter Mode, ULPS, SCLK Deep Sleep, Light Sleep, GPU Power Down, GPIO Power Saving, Power Gating, Clock Gating. Radeon preemption is retired and hidden. Existing Radeon registry controls are driver-dependent and not newly validated on AMD hardware in this release.
## Elite 3.10.11 — automatic app/service cleanup
The Cleanup tab now starts with one ON/OFF switch above the cache scanner. The old Gaming cleanup selection card is removed. ON silently applies an exact preset of 8 optional app names and 6 optional service names, with per-item progress and results. No manual selection or extra Apply step. OFF restores saved service startup/running settings; app removals are not undone and require Store reinstallation. Failed items retain recovery backups and are reported. The preset excludes game launchers, Xbox/Gaming Services, anti-cheat, audio, browsers, networking, updates and security. No 60–80 process count or FPS gain is promised. No live cleanup was run during development. Pro unchanged; BIOS unchanged in this release.
# Elite 3.10.10: guarded Resizable BAR

ReBAR no longer guidance-only. Requires unique Above 4G Enabled and CSM Disabled firmware rows before the preference can change; no CSM/boot settings are altered. GPU firmware support and actual active large memory window are not verified. Saved customer export matches nine controls and already reports ReBAR Enabled. 139 tests passed including missing-prerequisite rejection and legacy-boot blocking. No firmware writes. Remaining memory/duplicate CPU controls are still incomplete; this is not full catalog parity.

# Elite 3.10.9: full visible BIOS catalog

All 31 Intel/AMD/common catalog entries are displayed. CPU detection and firmware matching still determine availability; other-CPU, missing/ambiguous and unimplemented features show explicit reasons. Eight definitions match the saved MSI B650 export. Twelve entries remain unavailable for automatic application, including memory profiles and ReBAR prerequisites; this release does not claim feature parity or universal compatibility. 136 checks passed. No live firmware changes.

# Elite 3.10.8: six additional usable BIOS mappings

Added exact question/choice mappings for PCIe CLKREQ clock power management, PM L1 substates, AMD PCIe power-management preference, typical-current CPU idle, CPPC and CPPC preferred cores. The saved MSI B650 export uniquely resolves all six plus existing CPU PCIe ASPM and fabric C-states: eight available controls. Original-value backups, independent restoration, fresh export comparison and read-back checks remain. Defaults are not applied automatically. CPPC does not override the separate dynamic preferred-core/driver setting. Typical-current idle is a troubleshooting control, not an FPS optimization. PCIe idle changes may raise power use and require testing device/sleep behavior.

136 synthetic and saved-export read-only checks passed. No live firmware writes, benchmarks or cross-motherboard validation performed. Customer availability depends on exact firmware questions and choices. This version adds actual switch definitions rather than guidance rows.

# Elite 3.10.7: refresh conflicting BIOS state

When a fresh pre-import export differs from the displayed snapshot, import still stops but switches refresh from the fresh export. Saved customer exports show ASPM Disabled and an original Auto backup. No new firmware settings or mappings added. Broader BIOS catalog support remains unfinished. Existing 114 diagnostics passed; no live firmware commands executed during this build.

# Elite 3.10.6: actual available BIOS switches

Removed guidance-only rows from the BIOS switch catalog. After reading firmware, unmatched and ambiguous entries are hidden; the page reports their count. Added the exact CPU PCIe ASPM question name exposed in the saved MSI B650 export. Read-only validation now uniquely matches CPU PCIe ASPM and Fabric C-states. Core C-state/SoC controls contain multiple active firmware addresses and are not guessed or overwritten. There is no claim of universal 25-switch support.

114 BIOS tests passed. No firmware writes were performed. Switch submission/read-back still requires live hardware testing; matching a firmware export is not proof of successful application or improved performance.

# Elite 3.10.5: BIOS export compatibility fix

A successful export was rejected because the tool reported the known duplicate-question warning. That exact warning is now tolerated only during export with zero exit status and an explicit successful-export message. Unknown warnings, errors, nonzero exits and import warnings remain failures. The parser now accepts flat exports without GUID headers, strips option-label comments, and preserves text for round-trip edits. Flat identities use question name/token/offset/width; duplicate questions and duplicate keys still block preset matching.

Validation: 114 BIOS checks passed, including warning policy, flat/commented export round trips and read-only inspection of the saved customer export. The saved MSI B650 export contains 1878 usable questions and uniquely matches Fabric C-states (already Disabled). Other catalog settings are absent, guidance-only or ambiguous and remain unavailable. No live firmware commands or BIOS writes performed. GPU code unchanged from 3.10.4.

# Elite 3.10.4: automatic BIOS support preparation

SCAN BIOS now prepares required support files automatically; customers do not select an EXE or import an export. Administrator rights are required before initialization. On first use it downloads the official MSI Center archive and pinned innoextract 1.9 archive, verifies the extractor SHA256, extracts nested appx/SDK/Engine packages without installing MSI Center, and caches only the three AMI support files. Existing AMI signature checks run before firmware commands. No extracted AMI files are distributed in Quantix installers. First download is large (approximately 560 MB in the inspected package). Internet access and sufficient disk space are required; extraction staging remains for troubleshooting.

Prepared files are not proof of motherboard compatibility. A usable fresh firmware export is required before switches enable; unsupported systems and driver-load failures stop the workflow. No protections are disabled and no firmware bypass flags are used. Each switch still saves originals and validates read-back.

Validation: build plus 104 BIOS policy/UI checks and 17 mock GPU checks. Extraction layout was checked against the previously downloaded MSI package and extractor hash. Automatic downloader and live firmware commands have not been executed end-to-end on the PC. Cross-board support remains unverified.

# Elite 3.10.3: GPU controls and BIOS setup status

Retired GPU restore-only rows are hidden from the active GPU catalog. Their backend definitions and saved-backup recovery remain intact. Added two per-game switches: high-performance GPU preference (requires multiple active PCI graphics adapters) and windowed-game optimization preference (Windows 11 22H2+). Select the actual game EXE. Each preference preserves other flags, saves originals before writing, verifies read-back, and restores only its own token. External-change conflicts, malformed flags and unsupported configurations stop changes. No driver overclocking or undocumented adapter overrides were added. Existing non-retired GPU features remain available.

BIOS now distinguishes NOT READ, GUIDE and NOT EXPOSED rather than labelling every unavailable row N/A. Hardware scan alone cannot initialize BIOS tweaks. SCAN BIOS requires a motherboard-compatible AMI package selected by the customer and administrator rights. No usable live export or tool operation log was found on this PC. The extracted MSI package remains inspection-only, not board-validated or bundled for distribution.

Validation: 17 mock graphics exact-restore/conflict/failure/capability/navigation checks and 104 BIOS checks passed. Actual GPU UI inspected. No live graphics preferences or firmware settings changed. Elite installer payload checked against tested EXE; Pro unchanged at 2.8.7.

# Elite 3.10.2: BIOS Tweaks switches

The user-facing heading is BIOS Tweaks. The page stays inline below the hardware scanner. Checkbox selection and the bottom Apply button are removed. Every exposed tweak has an individual ON/OFF switch in the existing purple style. ON immediately submits that single setting with a durable original-value backup; OFF restores only that setting's saved original. Normal switches do not show a second Apply dialog. Progress locks the controls while importing. Switch state is refreshed from firmware read-back, with reboot and a fresh read still required for final verification.

A setting already at its target value without an Elite backup shows ON but cannot invent an original value for OFF. Unsupported and guidance-only rows remain unavailable and explain why. Restore still blocks unexpected external changes. Backups/reviewed file imports remain under Backups and recovery and keep a confirmation preview. First originals survive repeated imports; the pre-import value is retained so a failed retry remains recoverable.

Catalog: 25 total definitions, 13 importable experiments and 12 labelled guidance entries; Intel/AMD filtering and unique firmware matching remain in place. This is not a promise of 25 working switches on every board. Pro is unchanged at 2.8.7. The latest extreme-cleanup request is separate and remains unfinished.

Validation: 104 synthetic parser/catalog/CPU policy/individual restore/UI checks passed. Actual inline scrolling, switch controls, clean heading, removed launch button and removed Apply button were checked. Published Elite and verified MSI payload against the tested executable. No firmware commands or live BIOS changes were executed. Compatible BIOS tool package required; cross-motherboard behavior and performance remain unverified.

Earlier release notes follow for reference.

# Elite 3.10.1: inline BIOS catalog

The BIOS launch button and separate window are removed. Scroll below the hardware scanner to the BIOS controls, read firmware, select exposed tweaks and apply at the bottom of the list. Controls use the existing purple Quantix button style. Export, reviewed import and original-value restore remain in Backups and recovery.

The catalog now contains 25 definitions: 13 importable experimental settings and 12 visibly labelled guidance entries. Intel/AMD filtering uses the detected CPU; the catalog total is not a claim that all settings can be applied on one motherboard. Only uniquely exposed compatible option names/values are selectable. Added applicable experiments include PCIe clock gating, LTR, Race to Halt, OBFF, PCI delay optimization, AMD fabric C-states, AB clock gating, chipset power saving and Cool'n'Quiet. Core idle, ECO/fabric overclock, boot/ReBAR, memory profiles, USB hand-off and security/virtualization entries remain guidance pending additional model-specific prerequisites. Gaming virtualization/DMA protection is preserved.

The catalog was compared with https://adamx.gg/guide/bios ; its performance claims are not treated as validation. No extracted AMI/MSI binaries are bundled. A customer-supplied compatible SCEWIN package and administrator rights remain required. Original-value backups and firmware identity/external-change checks are retained.

Validation: published Elite and built MSI; 96 synthetic parser/policy/CPU filtering/restore/navigation assertions passed. Actual page scrolling, missing old launch button, inline catalog and bottom Apply control were visually checked. No live SCEWIN commands, firmware export/import or BIOS changes were performed. Cross-motherboard compatibility and performance are not validated. Pro remains 2.8.7.

Earlier release notes follow for reference.

# Elite 3.10.0: in-app BIOS experiments

Open BIOS > BIOS TWEAKS / SCEWIN. The old six-button toolbar is removed: SCAN BIOS selects a package on first use, then reads exposed firmware options. APPLY SELECTED TWEAKS previews changes and asks before importing. Backups and recovery is collapsed by default and contains export, restricted reviewed import, original-value restore and package replacement.

SCEWIN is customer-supplied; no extracted MSI/AMI executables or drivers are bundled. Use an AMI package compatible with the customer's motherboard, with SCEWIN_64.exe, amifldrv64.sys and amigendrv64.sys together. All three must have valid AMI signatures. Administrator rights and AMI firmware identification are required. Unsupported exports, missing/ambiguous settings, signature failures and utility errors stop the operation. Intel and AMD are not assumed compatible merely from CPU vendor.

Initial experiments: PCIe ASPM, Energy Efficient Turbo, Energy Efficient P-state and Spread Spectrum, only when the supported question and Disabled choice are uniquely exposed. All start unchecked. These settings are experimental and are not validated across customer motherboards; no latency/FPS benefit is promised. Boot, Secure Boot, TPM, virtualization, voltage, clocks and memory overclocking are excluded from imports.

Before an import, a fresh export checks for external changes. Original values are durably saved under %LocalAppData%\Quantix\Elite\BIOS, tied to motherboard identity and BIOS version. A machine-wide file lock prevents simultaneous Elite imports. Restore preserves the first original and blocks missing/ambiguous settings or values changed outside Elite. Exports and journals remain after failures. Read-back verification reports whether requested values appeared; restart and reload to check after boot. Windows restore points do not restore firmware; customers need their board's recovery instructions and BitLocker recovery key.

Validation: successful publish and MSI build, 18 synthetic parser/policy/restore/navigation checks, UI screenshots inspected. No SCEWIN executed, no live firmware export/import and no cross-motherboard validation. Pro remains 2.8.7. Original network tweaks remain restored. The earlier cleanup selection UI remains; a new one-click extreme cleanup and a 60-80 process outcome have not been implemented or measured.

Earlier release notes below are historical, not the current feature list.

# Elite 3.9.9: Uninstall unneeded services and apps (10 October 2026)

Elite Cleanup now has a dedicated button for optional app/service removal. It runs Windows PowerShell without a terminal or Windows Settings window, with a loading bar, per-item progress, selection review, and observed before/after process counts. SELECT RECOMMENDED chooses a small optional profile; other listed options are opt-in. Services are disabled rather than deleted, with durable original startup/delayed/running-state backups and a RESTORE SERVICES action. Apps are uninstalled only for the account running Elite; local app data may be lost and Store reinstall is separate from service recovery.

Gaming/Xbox services, anti-cheat, launchers, browsers, Discord, audio, webcams, networking, security, updates and drivers are not cleanup targets. Any service with dependents is skipped. Printing, camera, VR and link-tracking targets from the earlier UI have been removed from new cleanup selections, while old service backups can still be recovered. Administrator rights are required for service changes. Missing rights block a mixed app/service operation before removal starts. Repeated changes preserve the original backup. No 60-80 process target or performance benefit is promised; already disabled services and non-running apps cannot produce that reduction. Counts fluctuate even during read-only scans.

Validation: 37 mocked cleanup assertions, actual Cleanup sidebar entry, live read-only scan with loading state, completed UI and visual inspection. No real cleanup applied on the development PC. Pro stays at 2.8.7 with no code changes.

Installer troubleshooting: Windows logged Error 1500 (another installation active). Cancel did not finish the stuck Elite transaction. Restart Windows, then run the sibling Install-Quantix-One-At-A-Time.cmd to install sequentially with detailed logs. No unattended installation or reboot was performed.

Earlier release notes follow for reference:

# Network rollback — Elite 3.9.8 / Pro 2.8.7

The original Network controls are enabled again. The adaptive panel, Optimize Network preset, and Ethernet disable-extras button were removed following reported higher ping. Automatic session restore points remain. Installing this update does not change existing Windows network values. Original recovery logic is retained. Existing adaptive-profile backups can still be recovered using Shared/Network.ps1 -Mode Restore as administrator; removed presets are blocked.

Earlier release documentation follows for historical reference:

# Ethernet-Erweiterung: Elite 3.9.7 / Pro 2.8.6

Im tatsächlichen Network-Tab erscheint bei aktivem physischem Ethernet ein zusätzlicher Button: "Ethernet: IPv4/IPv6 only + disable extras". Nach Hinweis und Bestätigung werden andere Adapterbindungen deaktiviert, IPv4 und IPv6 bleiben aktiviert. Unterstützte angeforderte Energiespar-, Wake-on-Magic-Packet-, RSS-, Checksum-Offload-, Interrupt-Moderation- und Flow-Control-Einstellungen werden deaktiviert. Der Treiber muss einen eindeutigen Disabled-Wert veröffentlichen; unbekannte/mehrdeutige Werte werden übersprungen und gemeldet. Speed & Duplex / Auto Negotiation bleibt unverändert. Diese Sonderfunktion ist unabhängig vom kleineren sicheren Optimize-Network-Profil.

Vor jeder Änderung werden alle Bindungen und betroffenen Treiberwerte dauerhaft gesichert. Restore Defaults stellt die ursprünglichen Werte einschließlich ursprünglich deaktivierter Bindungen wieder her. Vorherige RSS-Backups werden beim Wechsel aus Optimize Network übernommen. WLAN und virtuelle Adapter können die Funktion nicht ausführen. Bindungsänderungen können die Verbindung kurz unterbrechen und Datei-/Druckerfreigaben, VPNs und virtuelle Netzwerke beeinträchtigen. Das Abschalten von RSS/Offloads kann die Leistung verschlechtern. Treiberwerte werden ohne automatischen Adapterneustart gesetzt; ein späterer Windows-Neustart kann erforderlich sein. Der Statusbereich meldet Änderungen und übersprungene Optionen.

Die Änderungen wurden mit simulierten Treibern/Bindungen und tatsächlicher UI-Navigation geprüft. Am Entwicklungs-PC wurden keine Netzwerkwerte verändert.

# Quantix Pro 2.8.5 und Elite 3.9.6

Korrektur in Elite 3.9.6: Die adaptive Anzeige wird jetzt in dem tatsächlich über die Seitenleiste geöffneten `TweakTabView` für Network eingeblendet. Die frühere 3.9.5 enthielt sie nur in einer separaten, dort nicht verwendeten Netzwerkansicht. Beide Editionen wurden jetzt zusätzlich über die echte Seitenleisten-Navigation geprüft: ein Panel mit Live-Daten im Network-Tab, kein Panel in anderen Tabs und keine Duplikate beim Zurückwechseln. Die Versionsanzeige folgt dem tatsächlichen Build.

Beide Utilities wurden aus den bereitgestellten MSIs Pro 2.8.3 und Elite 3.9.4 rekonstruiert und erweitert. Die vorhandenen Oberflächenressourcen, Logos, übrigen Funktionsbereiche, HWID-Erkennung und QTX2-Lizenzprüfung wurden übernommen. Die Oberfläche liegt weiterhin als kompiliertes WPF-Markup (BAML) vor; dies ist ein wieder baubares rekonstruiertes Projekt, keine Wiederherstellung des ursprünglichen Quellcode-Archivs.

## Start und Wiederherstellungspunkt

Ein normaler App-Start startet genau einen Hintergrundversuch pro Prozess/App-Session:

- Pro: `Quantix Pro - Before Tweaks`
- Elite: `Quantix Elite - Before Tweaks`

Die Oberfläche wartet nicht auf den Versuch. Fehlende Administratorrechte, deaktivierter Systemschutz und Windows-Fehler werden als Status protokolliert; die App bleibt verfügbar. Windows kann die Erstellung ablehnen, deshalb wird kein erfolgreicher Punkt vorgetäuscht. Für eine erfolgreiche Erstellung muss die Utility mit Administratorrechten laufen und Windows-Systemschutz verfügbar sein. Der Network-Tab zeigt das Ergebnis. Die Lizenzaktivierung bleibt erforderlich.

Windows' Frequenzbegrenzung wird für diesen Versuch vorübergehend aufgehoben; der ursprüngliche Registry-Wert einschließlich Typ bzw. Abwesenheit wird anschließend wiederhergestellt. Ein unabhängiger unsichtbarer Helfer führt dies auch nach normalem Schließen der Oberfläche zu Ende. Diagnose- und Lizenzimport-Aufrufe erzeugen keine echten Wiederherstellungspunkte. Die Erstellung aktiviert Systemschutz nicht automatisch.

## Network-Tab

Der aktive Adapter wird anhand der Windows-Standardrouten und ihrer kombinierten Routen-/Schnittstellenmetrik erkannt; bei Dual Stack wird die IPv4-Standardroute bevorzugt. Die Anzeige enthält Verbindungstyp, Adapter, Link Speed, DNS und Status. „Connected“ bezeichnet die aktive Standardroute, keine Garantie für Internetzugang. Elite verwendet dieselbe Erkennung auch in der bisherigen Detailanzeige.

`Optimize Network` prüft den Adapter vor jeder Änderung neu:

| Profil | Änderungen |
|---|---|
| Pro / WLAN oder Ethernet | Windows-Update-Peer-Sharing abschalten; direkte Downloads bleiben möglich |
| Elite / WLAN | Zusätzlich die vorhandene WLAN-Leistungspräferenz des aktuellen Energieschemas auf Netzstrom auf maximale Leistung setzen, sofern auslesbar; Akkueinstellung bleibt erhalten |
| Elite / Ethernet | Zusätzlich RSS aktivieren, wenn der konkrete physische Adapter dies unterstützt und RSS bisher deaktiviert ist; kein erzwungener Adapter-Neustart |
| Offline, virtuelle oder unbekannte Standardroute | Keine Optimierung |

DNS-Server, feste Link-Geschwindigkeit, Offloads, Interrupt-Moderation, Nagle, NetBIOS und globale TCP-Parameter werden nicht automatisch umgeschrieben. Ein bereits passender Wert wird nicht verändert. RSS kann abhängig vom Treiber erst nach einem späteren Neustart vollständig wirksam werden. Messbare Latenz-/FPS-Gewinne sind nicht zugesichert.

Die älteren Netzwerk-Eingriffe sind als **Legacy Recovery** erhalten. Ihre bisherigen Sicherungen lassen sich weiterhin zurücksetzen; neue Anwendungen dieser pauschalen Eingriffe sind gesperrt. Die übrigen Funktionsbereiche behalten ihre bisherigen Aktionen und vorhandenen Stabilitätsregeln.

## Restore Defaults und Sicherungen

`Restore Defaults` stellt die **gesicherten ursprünglichen Werte** wieder her. Es führt keinen pauschalen Winsock-/TCP-Reset aus und erfindet keine Werkseinstellungen.

- Gemeinsame neue Baseline für Pro und Elite: `%ProgramData%\Quantix\Network\baseline-v1.json`.
- Persistente Sicherung wird vor jeder Änderung atomar geschrieben und auf den Datenträger gespült. Eine Dateisperre schützt parallele Zugriffe.
- Wiederholtes Optimieren überschreibt die Baseline nicht.
- RSS-Sicherungen bleiben an die Adapter-GUID gebunden; WLAN-Netzstromwerte an die ursprüngliche Energieschema-GUID.
- Bei fehlendem Adapter, fehlerhafter Sicherung, Speicherfehlern oder fehlgeschlagener Rücksetzung bleibt die Sicherung erhalten. Außerhalb von Quantix geänderte Werte werden nicht überschrieben.
- Alte Netzwerk-Sicherungen aus `%LocalAppData%\Quantix\restore-backup.json` werden zusätzlich über die bisherige Wiederherstellungslogik berücksichtigt. Ohne vorhandene Sicherung können frühere Änderungen nicht zuverlässig rekonstruiert werden.

## Neue lokale Lizenzmanager

Die separat mitgelieferten Pro-/Elite-Manager sind neu implementierte Verwaltungsprogramme, keine wiedergefundenen Original-Manager oder alten Datenbanken. Sie unterstützen QTX2-Erstellung, Key-Import/-Export, Kopieren, lokale Sperren, kumulative QRV2-Updates und QMS1-Synchronisierung mit der vorhandenen Bot-Schnittstelle.

1. In Railway die **bereits vorhandenen** privaten Signierschlüssel der jeweiligen Edition lokal als PEM-Datei sichern: `QUANTIX_PRO_PRIVATE_KEY_PEM` und `QUANTIX_ELITE_PRIVATE_KEY_PEM`. Keine neuen Schlüssel erzeugen und keine privaten Schlüssel ins GitHub-Repo oder in diesen Chat kopieren. Falls die bisherigen Schlüssel nicht mehr zugänglich sind, lassen sie sich aus MSI/public.pem nicht ableiten; die Schlüsselprüfung wird nicht umgangen.
2. Im passenden Manager `Import signing PEM` wählen. Die Datei muss zum bisherigen öffentlichen Schlüssel passen. Der Manager speichert sie Windows-benutzergebunden mit DPAPI verschlüsselt.
3. Die öffentliche HTTPS-Basisadresse deines Railway-Bots eingeben und `Save Railway URL` wählen. Keine Discord-Tokens eingeben.
4. `Sync now` holt die vorhandenen Bot-Lizenzen und überträgt lokale Änderungen. Während der Manager offen ist, wird alle 30 Sekunden synchronisiert. Signierte Requests verwenden `/api/manager/sync/pro` bzw. `/api/manager/sync/elite`.
5. Vor dem Export von Sperrlisten muss mindestens eine erfolgreiche Synchronisierung erfolgt sein, damit eine leere neue Datenbank nicht die alte Sperrhistorie ersetzt. Lokale Daten bleiben bei Sync-Fehlern erhalten; Versionskonflikte erzeugen eine lokale Konfliktsicherung.

Manager-Daten liegen unter `%LocalAppData%\Quantix\Managers\pro` bzw. `elite`. Vorhandene Railway-Daten wurden bei dieser Arbeit nicht heruntergeladen oder verändert. Die Utilities enthalten ausschließlich die bisherigen öffentlichen Prüfschlüssel. Offline-Utilities benötigen weiterhin einen importierten signierten Lizenz-Update für entfernte Sperren.

## Builds und Prüfung

Windows x64, .NET-8-SDK und WiX 6.0.2 werden zum Neubau benötigt; fertige EXEs benötigen keine separat installierte .NET-Runtime. `Build.ps1` baut die beiden Utilities, Manager und MSIs. Optional `-DotNetExe` und `-WixExe` mit vollständigen Toolpfaden angeben.

Die MSIs behalten die bisherigen editionsbezogenen UpgradeCodes und Installationsordner unter `%LocalAppData%\Programs\QuantixOwner`. Sie sind gebaut und ihre enthaltenen EXEs geprüft; sie wurden nicht auf diesem PC installiert. Es liegt kein Codesignatur-Zertifikat vor; die neuen Artefakte sind nicht signiert.

Durchgeführte Prüfungen:

- 38 Netzwerkassertionen mit simulierten Adaptern/Werten: Pro/Elite, WLAN/Ethernet, Offline/VPN, fehlendes RSS, Wiederholung, Verbindungswechsel, Teilfehler, externe Änderungen und Rücksetzung.
- 15 Restore-Helper-Assertionen mit simuliertem Windows-Provider und Registry: exakte Namen, Erfolg, Fehler, Wert-/Typwiederherstellung und zuvor fehlender Wert.
- Pro Edition 13 Managerassertionen mit temporären Testschlüsseln, inklusive Kompatibilität mit der ursprünglichen `QuantixLicensing.dll`, HWID, Ablauf, Edition, Signatur, Sync-Envelope und Schutz gegen verlorene Serverhistorie.
- 14 Integrationassertionen gegen die tatsächlichen Bot-Module in isolierten SQLite-Datenbanken, inklusive Signatur, Sperrstatus, Versionen, Replay/Timeout und identischen Produktions-Prüfschlüsseln.
- Veröffentlichte EXEs: Views-/Network-Prüfungen beider Editionen sowie Elite-Host und Pro-Katalog erfolgreich; Oberflächenvorschauen visuell geprüft.

Es wurden keine echten Network-Tweaks, echten Wiederherstellungspunkte oder produktiven Lizenzänderungen auf diesem PC ausgeführt. Reale Windows-Wiederherstellung, WLAN-Treiberänderungen und Live-Railway-Sync wurden nicht ausgeführt; sie müssen mit aktiviertem Systemschutz und deinen vorhandenen Signierschlüsseln in einer geeigneten Testumgebung geprüft werden.

Die ausführbaren Programme besitzen Diagnoseoptionen `--verify-views` und `--verify-network <vollständiger PNG-Pfad>`; die Manager `--self-test <vollständiger Report-Pfad>`. Diese Tests umgehen keine normale Aktivierung und wenden keine produktiven Tweaks an. Für Bot-Kompatibilität erst die Manager-Selbsttests ausführen, danach `tests/BotCompatibility.Tests.py <Bot-Repo-Pfad>`. Die PowerShell-Prüfungen stehen in `tests/Network.Tests.ps1` und `tests/RestorePoint.Tests.ps1`.

Referenzen: [Microsoft System Restore](https://learn.microsoft.com/en-us/windows/win32/sr/calling-srsetrestorepoint), [Microsoft RSS](https://learn.microsoft.com/en-us/powershell/module/netadapter/set-netadapterrss), [vorhandenes Bot-Repository](https://github.com/kerem736251-cell/discord-bot-done-done).






param([string]$DotNetExe='dotnet', [string]$WixExe='wix', [string]$OutputRoot=(Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference='Stop'
$OutputRoot=[IO.Path]::GetFullPath($OutputRoot)
foreach($tier in @('Elite','Pro')) {
    $version=if($tier -eq 'Elite'){'3.10.21'}else{'2.8.7'}
    $publish=Join-Path $OutputRoot "Quantix-$tier-$version"
    & $DotNetExe publish (Join-Path $PSScriptRoot "$tier\QuantixTweakingUtility.csproj") -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $publish
    if($LASTEXITCODE -ne 0){throw "$tier publish failed."}
    Move-Item -LiteralPath (Join-Path $publish 'QuantixTweakingUtility.exe') -Destination (Join-Path $publish "Quantix${tier}.exe") -Force
    & $DotNetExe publish (Join-Path $PSScriptRoot "$tier-License-Manager\QuantixLicenseManager.csproj") -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o (Join-Path $OutputRoot "Quantix-$tier-License-Manager")
    if($LASTEXITCODE -ne 0){throw "$tier manager publish failed."}
}
# Installer sources reference the sibling publish folders. Bind paths allow a custom output root.
Push-Location (Join-Path $PSScriptRoot 'installer')
try {
    foreach($tier in @('Elite','Pro')) {
        $version=if($tier -eq 'Elite'){'3.10.21'}else{'2.8.7'}
        $original=Get-Content "$tier.wxs" -Raw
        $source=$original.Replace("../../Quantix-$tier-$version/Quantix${tier}.exe",(Join-Path $OutputRoot "Quantix-$tier-$version\Quantix${tier}.exe"))
        $temporary=Join-Path ([IO.Path]::GetTempPath()) ('quantix-'+[guid]::NewGuid().ToString('N')+'.wxs')
        try {
            [IO.File]::WriteAllText($temporary,$source)
            & $WixExe build $temporary -arch x64 -out (Join-Path $OutputRoot "Quantix${tier}-$version-Setup.msi") -pdbtype none
            if($LASTEXITCODE -ne 0){throw "$tier installer build failed."}
        } finally {Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue}
    }
} finally {Pop-Location}






$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'Shared\RestorePoint.ps1') -Tier Pro -Library
$script:checks=0
function Assert($condition,$message){$script:checks++;if(!$condition){throw "FAILED: $message"}}
function Open-RestoreFrequencyKey { $script:key }
function Get-RestorePoints {
    if ($script:created) { [pscustomobject]@{SequenceNumber=11;Description=('Quantix '+$Tier+' - Before Tweaks')} }
    else { [pscustomobject]@{SequenceNumber=10;Description='Existing point'} }
}
function Create-SystemPoint($description) {
    $script:calls++
    Assert ($script:key.Values['SystemRestorePointCreationFrequency'] -eq 0) 'frequency changed only during request'
    Assert ($description -eq ('Quantix '+$Tier+' - Before Tweaks')) 'exact edition description'
    if($script:throwCreate){throw 'Injected missing-rights failure.'}
    if($script:resultCode -eq 0){$script:created=$true}
    [pscustomobject]@{ReturnValue=$script:resultCode}
}
function Reset-Test($value,$kind){
    $script:created=$false;$script:calls=0;$script:throwCreate=$false;$script:resultCode=0
    $script:key=[pscustomobject]@{Values=@{};Kind=$kind}
    if($null -ne $value){$script:key.Values['SystemRestorePointCreationFrequency']=$value}
    $script:key | Add-Member ScriptMethod GetValueNames { @($this.Values.Keys) }
    $script:key | Add-Member ScriptMethod GetValue {param($name,$default,$options);$this.Values[$name]}
    $script:key | Add-Member ScriptMethod GetValueKind {param($name);$this.Kind}
    $script:key | Add-Member ScriptMethod SetValue {param($name,$value,$kind);$this.Values[$name]=$value;$this.Kind=$kind}
    $script:key | Add-Member ScriptMethod DeleteValue {param($name,$unused);$this.Values.Remove($name)}
    $script:key | Add-Member ScriptMethod Dispose { }
}
Reset-Test 1440 ([Microsoft.Win32.RegistryValueKind]::DWord)
$r=Invoke-RestorePointHelper | ConvertFrom-Json
Assert ($calls -eq 1 -and $r.Message -eq 'Restore point created: Quantix Pro - Before Tweaks') 'one Pro request and verified point'
Assert ($key.Values['SystemRestorePointCreationFrequency'] -eq 1440) 'original frequency restored'

$Tier='Elite';Reset-Test $null ([Microsoft.Win32.RegistryValueKind]::DWord)
$r=Invoke-RestorePointHelper | ConvertFrom-Json
Assert ($r.Message -eq 'Restore point created: Quantix Elite - Before Tweaks') 'Elite point name'
Assert (!$key.Values.ContainsKey('SystemRestorePointCreationFrequency')) 'previously absent frequency removed'

Reset-Test 'custom' ([Microsoft.Win32.RegistryValueKind]::String);$resultCode=5
$r=Invoke-RestorePointHelper | ConvertFrom-Json
Assert ($r.Message.Contains('unavailable') -and $calls -eq 1) 'Windows failure is reported without retry'
Assert ($key.Values['SystemRestorePointCreationFrequency'] -eq 'custom' -and $key.Kind -eq [Microsoft.Win32.RegistryValueKind]::String) 'original value and type restored on failure'

Reset-Test 17 ([Microsoft.Win32.RegistryValueKind]::DWord);$throwCreate=$true
$r=Invoke-RestorePointHelper | ConvertFrom-Json
Assert ($r.Message.Contains('missing-rights') -and $key.Values['SystemRestorePointCreationFrequency'] -eq 17) 'rights exception preserves preference'

Write-Output "PASS: $checks assertions. Mock restore provider and registry only; no real restore points or system preferences changed."

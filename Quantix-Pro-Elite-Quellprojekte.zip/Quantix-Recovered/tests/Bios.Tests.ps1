param([Parameter(Mandatory=$true)][string]$EliteExe)
$ErrorActionPreference='Stop'
$report=Join-Path $PSScriptRoot 'Elite-bios'
Remove-Item -LiteralPath ($report+'.error.txt') -ErrorAction SilentlyContinue
$process=Start-Process -FilePath ([IO.Path]::GetFullPath($EliteExe)) -ArgumentList @('--verify-scewin',('"'+$report+'"')) -WindowStyle Hidden -PassThru
$process.WaitForExit()
if($process.ExitCode -ne 0){Get-Content ($report+'.error.txt');throw 'BIOS diagnostics failed.'}
Get-Content ($report+'.txt')

$ErrorActionPreference='Stop'
$root = Split-Path $PSScriptRoot -Parent
$scratch = Join-Path ([IO.Path]::GetTempPath()) ('quantix-network-tests-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($scratch) | Out-Null
. (Join-Path $root 'Shared\Network.ps1') -Library -BackupPath (Join-Path $scratch 'baseline.json')
$script:checks=0
function Assert($condition,$message) { $script:checks++; if (!$condition) { throw "FAILED: $message" } }
function Assert-Administrator { }
function Get-ActiveConnection {
    $script:routeReads++
    if ($script:routeChanged -and $script:routeReads -gt 1) { return [pscustomobject]@{ Type='Ethernet'; Id='22222222-2222-2222-2222-222222222222'; Physical=$true } }
    [pscustomobject]@{ Type=$script:type; Id='11111111-1111-1111-1111-111111111111'; Physical=($script:type -in @('Wi-Fi','Ethernet')) }
}
function Get-Plan { '33333333-3333-3333-3333-333333333333' }
function Read-Setting($entry) {
    if ($entry.Kind -eq 'Rss' -and !$script:rssSupported) { throw 'Unsupported hardware.' }
    if ($script:unavailable -eq $entry.Key) { throw 'Original adapter unavailable.' }
    return [string]$script:values[$entry.Key]
}
function Write-Setting($entry,[string]$value) {
    # The actual durable journal must exist with the unchanged original before any write.
    $saved = Get-Content -LiteralPath $BackupPath -Raw | ConvertFrom-Json
    Assert (@($saved.Entries | Where-Object { $_.Key -eq $entry.Key -and $_.Original -eq $entry.Original }).Count -eq 1) 'backup precedes write'
    $script:writes.Add($entry.Kind)
    if ($script:failWrite) { throw 'Injected write failure.' }
    $script:values[$entry.Key]=$value
}
function Reset-Test([string]$connection,[string]$edition) {
    $script:type=$connection; $script:Tier=$edition; $script:Mode='Optimize'; $script:routeChanged=$false
    $script:routeReads=0
    $script:rssSupported=$true; $script:unavailable=''; $script:failWrite=$false
    $script:BackupPath=Join-Path $scratch ([guid]::NewGuid().ToString('N')+'.json')
    $script:values=@{delivery='missing'; 'wifi-ac:33333333-3333-3333-3333-333333333333'='2'; 'rss:11111111-1111-1111-1111-111111111111'='False'}
    $script:writes=[Collections.Generic.List[string]]::new()
}
Reset-Test 'Wi-Fi' 'Pro'
$r=Invoke-NetworkWorkflow
Assert $r.Success 'Pro Wi-Fi succeeds'
Assert ($writes.Count -eq 1 -and $writes[0] -eq 'Delivery') 'Pro never changes WLAN driver settings'
$r=Invoke-NetworkWorkflow
Assert ($writes.Count -eq 1) 'repeated optimization does not overwrite baseline'
$Mode='Restore'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $values.delivery -eq 'missing') 'restore deletes previously absent policy'

Reset-Test 'Wi-Fi' 'Elite'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $writes.Count -eq 2 -and 'Rss' -notin $writes) 'Elite Wi-Fi has no Ethernet writes'
$Mode='Restore'; $type='Ethernet'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $values['wifi-ac:33333333-3333-3333-3333-333333333333'] -eq '2') 'restore original WLAN plan after connection change'

Reset-Test 'Ethernet' 'Elite'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and 'Rss' -in $writes -and 'WirelessAC' -notin $writes) 'Elite Ethernet enables only supported RSS'
$Mode='Restore'; $unavailable='rss:11111111-1111-1111-1111-111111111111'; $r=Invoke-NetworkWorkflow
Assert (!$r.Success -and (Get-Content $BackupPath -Raw).Contains('Rss')) 'removed adapter retains restore backup'
$unavailable=''; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $values['rss:11111111-1111-1111-1111-111111111111'] -eq 'False') 'adapter return allows recovery'

Reset-Test 'Ethernet' 'Elite'; $rssSupported=$false; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and 'Rss' -notin $writes) 'unsupported RSS is skipped'
Reset-Test 'Virtual / other' 'Elite'
try { Invoke-NetworkWorkflow; throw 'Expected virtual-route refusal.' } catch { Assert ($writes.Count -eq 0) 'virtual routes cannot trigger physical changes' }
Reset-Test 'Offline' 'Pro'
try { Invoke-NetworkWorkflow; throw 'Expected offline refusal.' } catch { Assert ($writes.Count -eq 0) 'offline makes no changes' }

Reset-Test 'Wi-Fi' 'Elite'; $failWrite=$true; $r=Invoke-NetworkWorkflow
Assert (!$r.Success -and (Test-Path $BackupPath)) 'write failure retains baseline'
$failWrite=$false; $Mode='Restore'; $r=Invoke-NetworkWorkflow
Assert $r.Success 'partial operation can be restored'

Reset-Test 'Ethernet' 'Pro'; Invoke-NetworkWorkflow | Out-Null
$values.delivery='3'; $Mode='Restore'; $r=Invoke-NetworkWorkflow
Assert (!$r.Success -and $values.delivery -eq '3') 'restore does not overwrite externally changed value'
Assert ((Get-Content $BackupPath -Raw).Contains('Delivery')) 'external-change conflict retains baseline'

Reset-Test 'Wi-Fi' 'Elite'; [IO.File]::WriteAllText($BackupPath,'corrupt')
try { Invoke-NetworkWorkflow; throw 'Expected invalid-backup refusal.' } catch { Assert ($writes.Count -eq 0) 'corrupt backup blocks writes' }

Reset-Test 'Wi-Fi' 'Elite'; $routeChanged=$true; $r=Invoke-NetworkWorkflow
Assert (!$r.Success -and $writes.Count -eq 0) 'route change blocks stale adapter writes'

Reset-Test 'Wi-Fi' 'Pro'; Invoke-NetworkWorkflow | Out-Null
$Tier='Elite'; Invoke-NetworkWorkflow | Out-Null
$Mode='Restore'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $values.delivery -eq 'missing') 'Pro and Elite share the original machine baseline'

Reset-Test 'Ethernet' 'Elite'; $values.delivery='0'; $values['rss:11111111-1111-1111-1111-111111111111']='True'; $r=Invoke-NetworkWorkflow
Assert ($r.Success -and $writes.Count -eq 0) 'already-correct settings produce no writes'

Reset-Test 'Wi-Fi' 'Pro'
$originalSave = ${function:Save-Journal}
function Save-Journal($journal) { throw 'Injected storage failure.' }
$r=Invoke-NetworkWorkflow
Assert (!$r.Success -and $writes.Count -eq 0) 'storage failure prevents setting change'
${function:Save-Journal}=$originalSave

Write-Output "PASS: $checks assertions. Mock adapters/settings only; no Windows network settings changed."

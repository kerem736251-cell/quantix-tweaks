$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$scratch=Join-Path $env:TEMP ('quantix-ethernet-tests-'+[guid]::NewGuid().ToString('N'))
. (Join-Path $root 'Shared\Network.ps1') -Library -BackupPath (Join-Path $scratch 'baseline.json')
$script:checks=0
function Assert($v,$m) { $script:checks++; if (!$v) {throw "FAILED: $m"} }
function Assert-Administrator {}
$script:id='11111111-1111-1111-1111-111111111111'
function Get-ActiveConnection { [pscustomobject]@{Type=$script:type;Id=$script:id;Physical=$true} }
function Get-SavedEthernet($e) { if($script:removed){throw 'Adapter removed'}; [pscustomobject]@{Name='Mock Ethernet'} }
function Get-NetAdapterBinding { foreach($k in $script:bindings.Keys) { [pscustomobject]@{ComponentID=$k;Enabled=$script:bindings[$k]} } }
function Get-NetAdapterAdvancedProperty { $script:properties }
function Read-Setting($e) {
    if($script:removed){throw 'Adapter removed'}
    switch($e.Kind) {
        'Binding' {return ([bool]$script:bindings[$e.Component]).ToString()}
        'Advanced' {return [string]$script:advanced[$e.Keyword]}
        'Rss' {return ($script:advanced['*RSS'] -eq '1').ToString()}
        'Delivery' {return [string]$script:delivery}
    }
}
function Write-Setting($e,[string]$v) {
    $saved=Get-Content $BackupPath -Raw | ConvertFrom-Json
    Assert (@($saved.Entries | Where-Object {$_.Key -eq $e.Key}).Count -eq 1) 'durable baseline before write'
    if($Mode -ne 'Restore') { Assert (@($saved.Entries | Where-Object {$_.Kind -eq 'Binding'}).Count -ge 4) 'all bindings backed up before first write' }
    $script:writes++
    if($script:fail){throw 'Injected driver failure'}
    switch($e.Kind) {
        'Binding' {$script:bindings[$e.Component]=[bool]::Parse($v)}
        'Advanced' {$script:advanced[$e.Keyword]=$v}
        'Rss' {$script:advanced['*RSS']=if([bool]::Parse($v)){'1'}else{'0'}}
        'Delivery' {$script:delivery=$v}
    }
    if($script:sideEffects -and $Mode -ne 'Restore' -and $e.Kind -eq 'Binding') { $script:bindings.ms_server=$true }
}
function Reset {
    $script:BackupPath=Join-Path $scratch ([guid]::NewGuid().ToString('N')+'.json')
    $script:Mode='EthernetMinimal';$script:Tier='Elite';$script:type='Ethernet';$script:removed=$false;$script:fail=$false;$script:sideEffects=$false;$script:writes=0;$script:delivery='0'
    $script:bindings=@{ms_tcpip=$true;ms_tcpip6=$false;ms_msclient=$true;ms_server=$false}
    $script:advanced=@{'*RSS'='1';'*FlowControl'='3';GreenEthernet='7';BatterySpeed='2';'*SpeedDuplex'='0'}
    $script:properties=@(
        [pscustomobject]@{DisplayName='RSS localized';RegistryKeyword='*RSS';RegistryValue=@('1');ValidDisplayValues=@('Deaktiviert','Aktiviert');ValidRegistryValues=@('0','1')},
        [pscustomobject]@{DisplayName='Flow Control';RegistryKeyword='*FlowControl';RegistryValue=@('3');ValidDisplayValues=@('Disabled','Rx & Tx Enabled');ValidRegistryValues=@('0','3')},
        [pscustomobject]@{DisplayName='Green Ethernet';RegistryKeyword='GreenEthernet';RegistryValue=@('7');ValidDisplayValues=@('Enabled','Disabled');ValidRegistryValues=@('7','9')},
        [pscustomobject]@{DisplayName='Battery Mode Link Speed';RegistryKeyword='BatterySpeed';RegistryValue=@('2');ValidDisplayValues=@('10 Mbps','100 Mbps');ValidRegistryValues=@('1','2')},
        [pscustomobject]@{DisplayName='Speed & Duplex';RegistryKeyword='*SpeedDuplex';RegistryValue=@('0');ValidDisplayValues=@('Auto Negotiation','1Gbps');ValidRegistryValues=@('0','6')}
    )
}
Reset
$r=Invoke-NetworkWorkflow
Assert $r.Success 'Ethernet apply succeeds'
Assert ($bindings.ms_tcpip -and $bindings.ms_tcpip6 -and !$bindings.ms_msclient -and !$bindings.ms_server) 'only IPv4 and IPv6 remain enabled'
Assert ($advanced['*RSS'] -eq '0' -and $advanced['*FlowControl'] -eq '0') 'RSS and flow control disabled'
Assert ($advanced.GreenEthernet -eq '9') 'vendor disabled value is discovered, never guessed'
Assert ($advanced.BatterySpeed -eq '2' -and $advanced['*SpeedDuplex'] -eq '0') 'ambiguous battery speed skipped and link auto negotiation preserved'
$Mode='Optimize';$r=Invoke-NetworkWorkflow
Assert ($r.Success -and $advanced['*RSS'] -eq '0') 'safe Optimize preserves explicit RSS choice'
$Mode='EthernetMinimal'
$n=$writes;$r=Invoke-NetworkWorkflow
Assert ($writes -eq $n) 'repeat apply is idempotent'
$Mode='Restore';$r=Invoke-NetworkWorkflow
Assert $r.Success 'restore succeeds'
Assert (!$bindings.ms_tcpip6 -and $bindings.ms_msclient -and !$bindings.ms_server) 'restore exact enabled and disabled binding originals'
Assert ($advanced['*RSS'] -eq '1' -and $advanced.GreenEthernet -eq '7' -and $advanced['*FlowControl'] -eq '3') 'restore exact driver originals'
Assert (@((Get-Content $BackupPath -Raw|ConvertFrom-Json).Entries).Count -eq 0) 'successful recovery clears journal'
Reset;$type='Wi-Fi'
try {Invoke-NetworkWorkflow;throw 'Expected refusal'} catch {Assert ($writes -eq 0 -and !(Test-Path $BackupPath)) 'Wi-Fi cannot run Ethernet profile'}
Reset;$fail=$true;$r=Invoke-NetworkWorkflow
Assert (!$r.Success -and (Test-Path $BackupPath)) 'partial failure keeps complete recovery baseline'
Reset;$r=Invoke-NetworkWorkflow;$removed=$true;$Mode='Restore';$r=Invoke-NetworkWorkflow
Assert (!$r.Success -and @((Get-Content $BackupPath -Raw|ConvertFrom-Json).Entries).Count -gt 0) 'removed adapter retains backup'
Reset
[IO.Directory]::CreateDirectory($scratch)|Out-Null
$old=[pscustomobject]@{Version=1;Entries=@([pscustomobject]@{Key=('rss:'+$id);Kind='Rss';AdapterId=$id;Original='False';Target='True';Plan=''})}
Save-Journal $old
$r=Invoke-NetworkWorkflow
Assert $r.Success 'previous Optimize RSS baseline migrates successfully'
$j=Get-Content $BackupPath -Raw|ConvertFrom-Json
Assert (@($j.Entries|Where-Object Kind -eq Rss).Count -eq 0) 'RSS duplicate baseline removed'
Assert (@($j.Entries|Where-Object {$_.Keyword -eq '*RSS' -and $_.Original -eq '0'}).Count -eq 1) 'original pre-optimization disabled RSS retained'
$Mode='Restore';$r=Invoke-NetworkWorkflow
Assert ($r.Success -and $advanced['*RSS'] -eq '0') 'restore does not accidentally re-enable RSS'
Reset;$sideEffects=$true;$r=Invoke-NetworkWorkflow
Assert (!$r.Success -and $bindings.ms_server) 'binding side effects detected in final verification'
$Mode='Restore';$r=Invoke-NetworkWorkflow
Assert ($r.Success -and !$bindings.ms_server) 'observed binding side effects restore original disabled state'
Write-Output "PASS: $checks Ethernet assertions; mocked hardware, no live changes."

$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$scratch=Join-Path $env:TEMP ('quantix-cleanup-tests-'+[guid]::NewGuid().ToString('N'))
. (Join-Path $root 'Elite\Quantix.GamingCleanup.ps1') -Library -BackupRoot $scratch
$script:checks=0
function Assert($value,$message){$script:checks++;if(!$value){throw "FAILED: $message"}}
$script:packages=@([pscustomobject]@{Name='Microsoft.BingNews';PackageFullName='News.Mock';IsFramework=$false;NonRemovable=$false},[pscustomobject]@{Name='Microsoft.GamingServices';PackageFullName='Gaming.Mock';IsFramework=$false;NonRemovable=$false})
$script:service=[pscustomobject]@{Name='MapsBroker';Status='Running';StartType='Automatic';DependentServices=@()}
$script:reg=[pscustomobject]@{Start=2;DelayedAutoStart=1}
$script:writes=0;$script:fail=$false;$script:denied=$false
function Assert-CleanupAdministrator {if($script:denied){throw 'Denied'}}
function Get-CleanupTaskState($definition){return $null}
function Get-CleanupPlatform {return $script:platformMock}
$script:platformMock=@{Build=22631;Edition='Professional';Managed=$false}
function Get-AppxPackage($Name){@($script:packages|Where-Object Name -eq $Name)}
function Remove-AppxPackage($Package){Assert ($Package -eq 'News.Mock') 'only exact optional package removed';$script:packages=@($script:packages|Where-Object PackageFullName -ne $Package);$script:writes++}
function Get-Service($Name){if($Name -eq 'MapsBroker'){$script:service}}
function Get-ItemProperty($LiteralPath){$script:reg}
function Set-Service($Name,$StartupType){Assert (Test-Path (Join-Path $scratch ($Name+'.json'))) 'durable baseline precedes service change';$script:writes++;if($script:fail){throw 'Injected failure'};$script:service.StartType=$StartupType;$script:reg.Start=@{Automatic=2;Manual=3;Disabled=4}[$StartupType]}
function Stop-Service($Name){Assert (Test-Path (Join-Path $scratch ($Name+'.json'))) 'backup precedes stop';$script:service.Status='Stopped';$script:writes++}
function Start-Service($Name){$script:service.Status='Running';$script:writes++}
function Set-ItemProperty($LiteralPath,$Name,$Value){$script:reg.DelayedAutoStart=$Value}
function Remove-ItemProperty($LiteralPath,$Name){$script:reg.DelayedAutoStart=$null}
foreach($id in @('Audiosrv','BFE','Dnscache','Dhcp','BITS','wuauserv','WinDefend','GamingServices','FrameServer','Spooler','SSDPSRV','WSearch','WpnService','WpnUserService','BthServ','Winmgmt','RpcSs','Schedule','AppXSvc','ClipSVC','XblAuthManager','XboxNetApiSvc','EasyAntiCheat','BEService','vgc')){Assert ($id -notin $services) "protected service excluded: $id"}
foreach($id in @('Microsoft.GamingServices','Microsoft.GamingApp','Microsoft.WindowsStore','Microsoft.XboxIdentityProvider','Microsoft.Edge','Microsoft.MixedReality.Portal','Microsoft.MicrosoftSolitaireCollection','Microsoft.XboxGamingOverlay','Microsoft.VCLibs.140.00','Microsoft.NET.Native.Runtime.2.2','Microsoft.UI.Xaml.2.8','Microsoft.DesktopAppInstaller','Microsoft.Windows.Photos','Microsoft.WindowsCamera')){Assert ($id -notin $apps) "protected package excluded: $id"}
$Mode='Scan';$r=Invoke-GamingCleanup
Assert ($writes -eq 0) 'scan is read-only'
Assert (@($r|Where-Object Id -eq MapsBroker).Count -eq 1) 'optional service scanned'
$Mode='Apply';$Selected=@('Microsoft.BingNews','MapsBroker');$denied=$true
try{Invoke-GamingCleanup;throw 'Expected rights refusal'}catch{Assert ($writes -eq 0) 'missing admin blocks mixed changes before app removal'}
$denied=$false;$Selected=@('GamingServices')
try{Invoke-GamingCleanup;throw 'Expected target refusal'}catch{Assert ($writes -eq 0) 'unknown/protected selection refused'}
$Selected=@('MapsBroker');$service.DependentServices=@([pscustomobject]@{Status='Stopped'})
$r=Invoke-GamingCleanup
Assert ($writes -eq 0 -and $r[0].State.StartsWith('Failed:')) 'dependent services prevent disabling even when currently stopped'
$service.DependentServices=@();$Selected=@('Microsoft.BingNews','MapsBroker');$r=Invoke-GamingCleanup
Assert ($service.Status -eq 'Stopped' -and $service.StartType -eq 'Disabled') 'selected service disabled'
Assert (@($packages|Where-Object Name -eq Microsoft.GamingServices).Count -eq 1) 'gaming package retained'
$original=Get-Content (Join-Path $scratch 'MapsBroker.json') -Raw
$r=Invoke-GamingCleanup
Assert ((Get-Content (Join-Path $scratch 'MapsBroker.json') -Raw) -eq $original) 'repeated apply retains original baseline'
$Mode='Restore';$r=Invoke-GamingCleanup
Assert ($service.Status -eq 'Running' -and $reg.Start -eq 2 -and $reg.DelayedAutoStart -eq 1) 'exact service startup/running/delayed restoration'
Assert (!(Test-Path (Join-Path $scratch 'MapsBroker.json'))) 'successful restoration clears backup'
$Mode='Apply';$Selected=@('MapsBroker');$fail=$true;$r=Invoke-GamingCleanup
Assert ($r[0].State.StartsWith('Failed:') -and (Test-Path (Join-Path $scratch 'MapsBroker.json'))) 'partial failure reported with backup retained'
$fail=$false;$Mode='Restore';$r=Invoke-GamingCleanup
Assert ($service.Status -eq 'Running') 'partial failure recoverable'
# Corrupt recovery records must block a new service mutation. Only mock services are used.
$Mode='Apply';$Selected=@('MapsBroker');$before=$writes
[IO.File]::WriteAllText((Join-Path $scratch 'MapsBroker.json'),'{"Name":"OtherService","Start":2,"Delayed":null,"Running":true}')
$r=Invoke-GamingCleanup
Assert ($writes -eq $before -and $r[0].State.StartsWith('Failed:')) 'invalid existing baseline blocks changes'
Remove-Item -LiteralPath (Join-Path $scratch 'MapsBroker.json')
foreach($protection in @('IsFramework','NonRemovable')) {
    $package=[pscustomobject]@{Name='Microsoft.BingNews';PackageFullName='News.Mock';IsFramework=$false;NonRemovable=$false};$package.$protection=$true;$script:packages=@($package)
    $Selected=@('Microsoft.BingNews');$before=$writes;$r=Invoke-GamingCleanup
    Assert ($writes -eq $before -and $packages.Count -eq 1) "protected Appx flag prevents removal: $protection"
}
# Automatic preset must remain a strict subset and preserve data-heavy/critical apps.
$panel=Get-Content (Join-Path $root 'Elite\QuantixTweakingUtility.Views\AutomaticCleanupPanel.cs') -Raw
$targetLine=($panel -split "`n"|Where-Object {$_ -match 'internal static readonly string\[\] Targets'})
$automatic=@([regex]::Matches($targetLine,'"([^"]+)"')|ForEach-Object {$_.Groups[1].Value})
Assert ($automatic.Count -eq 26) 'automatic preset has 12 optional apps, six services, two version-gated policies and six optional scheduled tasks'
Assert (@($automatic|Where-Object {$_ -notin ($apps+$services+@($policies.Keys)+@($tasks.Keys))}).Count -eq 0) 'UI preset matches backend allowlist'
foreach($id in @('Microsoft.YourPhone','Clipchamp.Clipchamp','Microsoft.WindowsSoundRecorder','Microsoft.WindowsMaps','Microsoft.SkypeApp','MapsBroker*','WSearch','Microsoft.GetHelp')){Assert ($id -notin $automatic) "automatic preset preserves personal/unsupported target: $id"}
$Mode='Apply';$Selected=@('MapsBroker');$before=$writes;$platformMock.Managed=$true;$r=Invoke-GamingCleanup
Assert ($writes -eq $before -and $r[0].State.StartsWith('Skipped:')) 'managed device service configuration preserved'
$platformMock.Managed=$false;$service.Status='Paused';$r=Invoke-GamingCleanup
Assert ($writes -eq $before -and $r[0].State.StartsWith('Skipped:')) 'paused service preserved'
$service.Status='Running'
# Policy store mocks never access or write live registry settings.
$script:policyStore=@{};$script:policyWrites=0;$script:policyFail=$false
function Get-CleanupPolicyState($policy) {if($script:policyStore.ContainsKey($policy.Name)){return $script:policyStore[$policy.Name]};return @{Exists=$false;Value=$null;Kind=$null}}
function Set-CleanupPolicyState($policy,$state) {
    $id=if($policy.Name -eq 'EnableFeeds'){'OptionalNewsFeeds'}else{'OptionalWidgets'}
    Assert (Test-Path (Join-Path $scratch ($id+'.json'))) 'policy backup durable before mutation'
    $script:policyWrites++;if($script:policyFail){throw 'Injected policy failure'}
    if($state.Exists){$script:policyStore[$policy.Name]=@{Exists=$true;Value=[int]$state.Value;Kind='DWord'}}else{$script:policyStore.Remove($policy.Name)}
}
$Mode='Apply';$Selected=@('OptionalWidgets','OptionalNewsFeeds');$r=Invoke-GamingCleanup
Assert ($policyWrites -eq 1 -and $policyStore.AllowNewsAndInterests.Value -eq 0) 'Windows 11 disables only supported widgets policy'
Assert (@($r|Where-Object {$_.Id -eq 'OptionalNewsFeeds' -and $_.State.StartsWith('Skipped:')}).Count -eq 1) 'Windows 10 feed skipped on Windows 11'
$baseline=Get-Content (Join-Path $scratch 'OptionalWidgets.json') -Raw
$r=Invoke-GamingCleanup
Assert ((Get-Content (Join-Path $scratch 'OptionalWidgets.json') -Raw) -eq $baseline) 'repeat policy apply preserves original absence'
$Mode='Restore';$r=Invoke-GamingCleanup
Assert (!$policyStore.ContainsKey('AllowNewsAndInterests') -and !(Test-Path (Join-Path $scratch 'OptionalWidgets.json'))) 'OFF restores original missing policy without deleting registry key'
$Mode='Apply';$Selected=@('OptionalWidgets');$policyStore.AllowNewsAndInterests=@{Exists=$true;Value=1;Kind='DWord'};$before=$policyWrites;$r=Invoke-GamingCleanup
Assert ($policyWrites -eq $before -and $r[0].State.StartsWith('Skipped:')) 'existing administrator policy preserved'
$policyStore.Clear();$platformMock.Edition='Core';$r=Invoke-GamingCleanup
Assert ($policyWrites -eq $before -and $r[0].State.StartsWith('Skipped:')) 'unsupported Home policy skipped'
$platformMock.Edition='Professional';$platformMock.Managed=$true;$r=Invoke-GamingCleanup
Assert ($policyWrites -eq $before -and $r[0].State.StartsWith('Skipped:')) 'managed policy preserved'
$platformMock.Managed=$false;$policyFail=$true;$r=Invoke-GamingCleanup
Assert ($r[0].State.StartsWith('Failed:') -and (Test-Path (Join-Path $scratch 'OptionalWidgets.json'))) 'failed policy write keeps recovery record'
$policyFail=$false;$r=Invoke-GamingCleanup;$policyStore.AllowNewsAndInterests.Value=1;$Mode='Restore';$r=Invoke-GamingCleanup
Assert (@($r|Where-Object {$_.Id -eq 'OptionalWidgets' -and $_.State.StartsWith('Failed:')}).Count -eq 1 -and (Test-Path (Join-Path $scratch 'OptionalWidgets.json'))) 'outside policy change blocks destructive restore'
$policyStore.AllowNewsAndInterests.Value=0;$platformMock.Managed=$true;$r=Invoke-GamingCleanup
Assert (@($r|Where-Object {$_.Id -eq 'OptionalWidgets' -and $_.State.StartsWith('Failed:')}).Count -eq 1) 'managed restore keeps recovery marker on failure'
$platformMock.Managed=$false;$r=Invoke-GamingCleanup
Assert (!(Test-Path (Join-Path $scratch 'OptionalWidgets.json'))) 'policy restoration can recover after conflict resolved'
$platformMock.Build=19045;$Mode='Apply';$Selected=@('OptionalNewsFeeds');$r=Invoke-GamingCleanup
Assert ($policyStore.EnableFeeds.Value -eq 0) 'Windows 10 feed policy applied'
$Mode='Restore';$r=Invoke-GamingCleanup
Assert (!$policyStore.ContainsKey('EnableFeeds')) 'Windows 10 feed policy original restored'
# Pure XML signatures ignore only the settings Enabled bit; action/trigger edits are detected.
$xml='<Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"><Settings><Enabled>true</Enabled></Settings><Actions><Exec><Command>example.exe</Command></Exec></Actions></Task>'
Assert ((Get-CleanupTaskSignature $xml) -eq (Get-CleanupTaskSignature ($xml.Replace('<Enabled>true','<Enabled>false')))) 'task signature permits only enabled-state change'
Assert ((Get-CleanupTaskSignature $xml) -ne (Get-CleanupTaskSignature ($xml.Replace('example.exe','different.exe')))) 'task signature detects altered executable'
$script:taskStore=@{Enabled=$true;Fingerprint='fixture-definition'};$script:taskWrites=0;$script:taskFail=$false
function Get-CleanupTaskState($definition){if($definition.Name -eq 'DmClient'){return $script:taskStore};return $null}
function Set-CleanupTaskEnabled($definition,[bool]$enabled){Assert ($definition.Name -eq 'DmClient') 'only exact allowed scheduled task changed';Assert (Test-Path (Join-Path $scratch 'OptionalTaskFeedback.json')) 'task original durable before write';$script:taskWrites++;if($script:taskFail){throw 'Injected task failure'};$script:taskStore.Enabled=$enabled}
$platformMock.Build=22631;$Mode='Apply';$Selected=@('OptionalTaskFeedback');$r=Invoke-GamingCleanup
Assert (!$taskStore.Enabled -and $r[0].State.StartsWith('Disabled')) 'optional task disabled without deleting definition'
$baseline=Get-Content (Join-Path $scratch 'OptionalTaskFeedback.json') -Raw;$r=Invoke-GamingCleanup
Assert ((Get-Content (Join-Path $scratch 'OptionalTaskFeedback.json') -Raw) -eq $baseline) 'repeat task application preserves original'
$Mode='Restore';$r=Invoke-GamingCleanup
Assert ($taskStore.Enabled -and !(Test-Path (Join-Path $scratch 'OptionalTaskFeedback.json'))) 'OFF restores original task enabled state'
$Mode='Apply';$taskFail=$true;$r=Invoke-GamingCleanup
Assert ($r[0].State.StartsWith('Failed:') -and (Test-Path (Join-Path $scratch 'OptionalTaskFeedback.json'))) 'failed task change retains baseline'
$taskFail=$false;$r=Invoke-GamingCleanup;$taskStore.Fingerprint='outside-definition';$Mode='Restore';$before=$taskWrites;$r=Invoke-GamingCleanup
Assert ($taskWrites -eq $before -and @($r|Where-Object {$_.Id -eq 'OptionalTaskFeedback' -and $_.State.StartsWith('Failed:')}).Count -eq 1) 'outside task definition change blocks restoration'
$taskStore.Fingerprint='fixture-definition';$platformMock.Managed=$true;$r=Invoke-GamingCleanup
Assert ($taskWrites -eq $before -and (Test-Path (Join-Path $scratch 'OptionalTaskFeedback.json'))) 'managed restore preserves task recovery record'
$platformMock.Managed=$false;$r=Invoke-GamingCleanup
Assert ($taskStore.Enabled -and !(Test-Path (Join-Path $scratch 'OptionalTaskFeedback.json'))) 'task restore succeeds after conflict resolved'
$Mode='Apply';$Selected=@('OptionalTaskMapsUpdate');$before=$taskWrites;$r=Invoke-GamingCleanup
Assert ($taskWrites -eq $before -and $r[0].State -eq 'Not installed') 'missing optional task does not cause blanket changes'
foreach($id in @('XboxNetApiSvc','XblAuthManager','XblGameSave','XboxGipSvc','ClipSVC','InstallService','BITS','wuauserv','UsoSvc','WaaSMedicSvc','TokenBroker','wlidsvc','BDESVC','EFS','RasMan','IKEEXT','edgeupdate','bthserv','Spooler','W32Time','PcaSvc','MixedRealityOpenXRSvc')){Assert ($id -notin $services) "risky video service excluded: $id"}
Assert (@($tasks.Values|Where-Object {$_.Path -match 'WindowsUpdate|UpdateOrchestrator|XblGameSave|TPM|License|Defrag|RecoveryEnvironment'}).Count -eq 0) 'game licensing/security/maintenance tasks protected'
Write-Output "PASS: $checks cleanup assertions; mocked apps/services, no live changes."

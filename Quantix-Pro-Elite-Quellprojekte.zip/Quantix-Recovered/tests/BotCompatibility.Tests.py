"""Exercise the real bot sync implementation with synthetic manager keys only."""
import base64
import importlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

from cryptography.hazmat.primitives import serialization

root = Path(__file__).resolve().parents[1]
bot = Path(sys.argv[1]).resolve()
checks = 0


def assert_ok(condition, name):
    global checks
    checks += 1
    if not condition:
        raise AssertionError(name)


for tier in ("Elite", "Pro"):
    recovered = serialization.load_pem_public_key((root / tier / "QuantixTweakingUtility.LicensePublicKey").read_bytes())
    registered = serialization.load_pem_public_key((bot / (tier.lower() + "-signing-public.pem")).read_bytes())
    assert_ok(recovered.public_numbers() == registered.public_numbers(), tier + " production verifier preserved")
    fixture = root / "tests" / (tier + "-manager-tests.txt")
    with tempfile.TemporaryDirectory(prefix="quantix-bot-tests-") as location:
        test_folder = Path(location)
        for module in ("quantix_licensing", "license_registry", "manager_sync"):
            shutil.copy2(bot / (module + ".py"), test_folder)
            sys.modules.pop(module, None)
        for slug in ("pro", "elite"):
            shutil.copy2(str(fixture) + ".public.pem", test_folder / (slug + "-signing-public.pem"))
        sys.path.insert(0, location)
        sync = importlib.import_module("manager_sync")
        registry = importlib.import_module("license_registry")
        request = Path(str(fixture) + ".sync.txt").read_text()
        body = request.split(".")[1]
        payload = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        con = sqlite3.connect(":memory:")
        con.row_factory = sqlite3.Row
        con.execute("""CREATE TABLE licenses (
            license_key TEXT PRIMARY KEY, tier TEXT NOT NULL, hwid TEXT NOT NULL,
            discord_user_id INTEGER NOT NULL, created_by INTEGER NOT NULL, created_at TEXT NOT NULL,
            expires_at TEXT, revoked INTEGER DEFAULT 0, revoked_at TEXT, revoked_by INTEGER DEFAULT 0)""")
        registry.migrate(con)
        con.commit()
        con.execute("BEGIN IMMEDIATE")
        result = sync.synchronize(con, tier.lower(), request, now=payload["timestamp"])
        con.commit()
        assert_ok(result["Product"] == "quantix-" + tier.lower(), tier + " sync product")
        assert_ok(len(result["Licenses"]) == 1, tier + " signed manager key imported")
        assert_ok(result["Licenses"][0]["Revoked"], tier + " revocation imported")
        assert_ok(result["Licenses"][0]["SyncVersion"] >= 1, tier + " server version returned")
        rejected = False
        try:
            sync.synchronize(con, tier.lower(), request, now=payload["timestamp"])
        except ValueError:
            rejected = True
        assert_ok(rejected, tier + " replay rejected")
        rejected = False
        try:
            sync.synchronize(con, tier.lower(), request, now=payload["timestamp"] + 121)
        except ValueError:
            rejected = True
        assert_ok(rejected, tier + " stale signature rejected")
        con.close()
        sys.path.remove(location)

report = f"PASS: {checks} assertions against the real bot modules in isolated SQLite databases. No Discord, GitHub write, or Railway request."
print(report)
(root / "tests" / "bot-compatibility-tests.txt").write_text(report, encoding="utf-8")

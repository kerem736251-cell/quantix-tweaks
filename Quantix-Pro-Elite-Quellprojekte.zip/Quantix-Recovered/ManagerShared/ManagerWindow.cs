using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using QuantixLicensing;

namespace QuantixManager;

public sealed class ManagerWindow : Window
{
    private readonly ManagerCore core;
    private readonly TextBox customer=new(), hwid=new(), url=new();
    private readonly ComboBox duration=new();
    private readonly DataGrid grid=new() { AutoGenerateColumns=false, IsReadOnly=true, SelectionMode=DataGridSelectionMode.Single };
    private readonly TextBlock status=new() { TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,12,0,0) };
    private readonly DispatcherTimer timer=new() { Interval=TimeSpan.FromSeconds(30) };
    private readonly StackPanel commands=new() { Orientation=Orientation.Horizontal };
    private bool busy;

    public ManagerWindow(ManagerCore manager)
    {
        core=manager; Title="Quantix "+ManagerCore.Tier+" License Manager"; Width=1120; Height=730; MinWidth=1000; MinHeight=650;
        Background=new SolidColorBrush(Color.FromRgb(13,15,21)); Foreground=Brushes.White;
        var layout=new Grid { Margin=new Thickness(24) };
        foreach(var height in new[]{GridLength.Auto,GridLength.Auto,GridLength.Auto,GridLength.Auto,new GridLength(1,GridUnitType.Star),GridLength.Auto})
            layout.RowDefinitions.Add(new RowDefinition { Height=height });
        var title=new TextBlock { Text="QUANTIX / "+ManagerCore.Tier.ToUpperInvariant()+" LICENSE MANAGER", FontSize=24,FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,10) };
        layout.Children.Add(title);
        var info=new TextBlock { Text="QTX2 · existing signing key · signed Railway sync\nImport the original private signing key from your Railway variables. A new key would invalidate compatibility.",TextWrapping=TextWrapping.Wrap,Opacity=.8,Margin=new Thickness(0,0,0,12) };
        Grid.SetRow(info,1);layout.Children.Add(info);
        var config=new StackPanel { Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,12) };
        config.Children.Add(Button("Import signing PEM",ImportPem));
        url.Width=420;url.Text=core.State.BotUrl;url.Margin=new Thickness(10,0,10,0);url.VerticalContentAlignment=VerticalAlignment.Center;
        config.Children.Add(url);config.Children.Add(Button("Save Railway URL",()=>{core.ConfigureUrl(url.Text);SetStatus("HTTPS bot URL saved. Sync starts every 30 seconds while open.");}));
        Grid.SetRow(config,2);layout.Children.Add(config);
        var creation=new StackPanel { Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,12) };
        creation.Children.Add(Field("Customer",customer,190));creation.Children.Add(Field("Full QX2 HWID",hwid,480));
        duration.Width=140;duration.ItemsSource=new[]{"1 day","7 days","30 days","365 days","Lifetime"};duration.SelectedIndex=2;
        var durationBox=new StackPanel { Margin=new Thickness(0,0,10,0) };durationBox.Children.Add(new TextBlock {Text="Duration",Margin=new Thickness(0,0,0,5)});durationBox.Children.Add(duration);creation.Children.Add(durationBox);
        var create=Button("Create key",()=>{var row=core.Create(customer.Text,hwid.Text,duration.SelectedIndex switch {0=>1,1=>7,2=>30,3=>365,_=>(int?)null});Refresh();grid.SelectedItem=row;SetStatus("Key saved locally. Use Export key or Copy key; sync registers it with the bot.");});
        create.VerticalAlignment=VerticalAlignment.Bottom;creation.Children.Add(create);Grid.SetRow(creation,3);layout.Children.Add(creation);
        grid.Background=new SolidColorBrush(Color.FromRgb(24,27,35));grid.Foreground=Brushes.Black;
        foreach(var (label,path,width) in new[]{("Customer","Customer",180.0),("License ID","Id",250.0),("HWID","Hwid",260.0),("Expiry","Expires",140.0),("Revoked","Revoked",70.0),("Pending sync","SyncDirty",85.0)})
            grid.Columns.Add(new DataGridTextColumn { Header=label,Binding=new System.Windows.Data.Binding(path),Width=width });
        Grid.SetRow(grid,4);layout.Children.Add(grid);
        commands.Margin=new Thickness(0,12,0,0);
        commands.Children.Add(Button("Sync now",async()=>await SyncAsync()));
        commands.Children.Add(Button("Import key",ImportKey));commands.Children.Add(Button("Copy key",()=>{Clipboard.SetText(Selected().Token);SetStatus("Selected key copied.");}));
        commands.Children.Add(Button("Export key",ExportKey));commands.Children.Add(Button("Revoke selected",()=>{var row=Selected(); if(MessageBox.Show("Revoke this license? The bot receives the change on sync; offline utilities require a signed license update.",Title,MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){core.Revoke(row);Refresh();SetStatus("Revoked locally; pending bot sync.");}}));
        commands.Children.Add(Button("Export offline update",ExportUpdate));
        var footer=new StackPanel();footer.Children.Add(commands);footer.Children.Add(status);Grid.SetRow(footer,5);layout.Children.Add(footer);
        Content=layout;Refresh();SetStatus(core.CanSign?"Matching signing key loaded. Ready.":"No signing key configured. Existing licenses can be imported and inspected; create/sync require the original key.");
        timer.Tick+=async(_,_)=>{if(core.CanSign&&!string.IsNullOrWhiteSpace(core.State.BotUrl)) await SyncAsync();};
        Loaded+=(_,_)=>timer.Start();Closed+=(_,_)=>{timer.Stop();core.Dispose();};
    }
    private UIElement Field(string label,TextBox box,double width)
    {
        var panel=new StackPanel{Margin=new Thickness(0,0,10,0)};panel.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,0,0,5)});box.Width=width;box.Height=30;panel.Children.Add(box);return panel;
    }
    private Button Button(string title,Action action)
    {
        var b=new Button{Content=title,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,0,8,0),Background=new SolidColorBrush(Color.FromRgb(67,48,99)),Foreground=Brushes.White};
        b.Click+=(_,_)=>{if(busy)return;try{action();}catch(Exception ex){SetStatus(ex.Message);}};return b;
    }
    private LicenseRow Selected()=>grid.SelectedItem as LicenseRow??throw new InvalidOperationException("Select a license first.");
    private void Refresh(){grid.ItemsSource=null;grid.ItemsSource=core.State.Licenses.Where(x=>!x.Deleted).ToList();}
    private void SetStatus(string message)=>status.Text=message;
    private void ImportPem(){var d=new OpenFileDialog{Filter="Private PEM|*.pem"};if(d.ShowDialog()==true){core.ImportSigner(d.FileName);SetStatus("Original signing key verified and stored encrypted for this Windows user.");}}
    private void ImportKey(){var d=new OpenFileDialog{Filter="License key|*.key;*.txt"};if(d.ShowDialog()==true){core.ImportToken(File.ReadAllText(d.FileName));Refresh();SetStatus("Signed key imported.");}}
    private void ExportKey(){var row=Selected();var d=new SaveFileDialog{FileName=ManagerCore.Tier+"-"+row.Id+".key",Filter="License key|*.key"};if(d.ShowDialog()==true){File.WriteAllText(d.FileName,row.Token);SetStatus("Key exported.");}}
    private void ExportUpdate(){var d=new SaveFileDialog{FileName="quantix-"+ManagerCore.Tier+".qrv",Filter="Signed update|*.qrv"};if(d.ShowDialog()==true){File.WriteAllText(d.FileName,core.ExportUpdate());SetStatus("Signed cumulative revocation update exported. Sync/import existing revocations before distributing.");}}
    private async Task SyncAsync(){if(busy)return;busy=true;commands.IsEnabled=false;try{SetStatus("Synchronizing…");SetStatus(await core.SyncAsync());Refresh();}catch(Exception ex){SetStatus("Sync unavailable; local database retained. "+ex.Message);}finally{busy=false;commands.IsEnabled=true;}}

    [STAThread]
    public static int Main(string[] args)
    {
        if(args.Contains("--self-test"))return ManagerTests.Run(args.Length>1?args[1]:null);
        if(args.Length==2 && args[0]=="--preview") {
            var folder=Path.Combine(Path.GetTempPath(),"quantix-manager-preview-"+Guid.NewGuid().ToString("N"));
            var app=new Application();var window=new ManagerWindow(new ManagerCore(folder));
            window.Left=-12000;window.Top=-12000;window.ShowInTaskbar=false;window.WindowStartupLocation=WindowStartupLocation.Manual;
            window.Show();window.UpdateLayout();
            var bitmap=new System.Windows.Media.Imaging.RenderTargetBitmap(1120,730,96,96,PixelFormats.Pbgra32);bitmap.Render(window);
            var encoder=new System.Windows.Media.Imaging.PngBitmapEncoder();encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bitmap));
            using(var output=File.Create(args[1]))encoder.Save(output);
            window.Close();return 0;
        }
        try{var app=new Application();app.Run(new ManagerWindow(new ManagerCore()));return 0;}
        catch(Exception ex){MessageBox.Show(ex.Message,"Quantix License Manager",MessageBoxButton.OK,MessageBoxImage.Error);return 1;}
    }
}

public static class ManagerTests
{
    public static int Run(string? report)
    {
        try {
            int checks=0;void Assert(bool good,string name){checks++;if(!good)throw new Exception(name);}
            using var key=ECDsa.Create(ECCurve.NamedCurves.nistP256);
            string folder=Path.Combine(Path.GetTempPath(),"quantix-manager-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
            string privateFile=Path.Combine(folder,"test-private.pem");File.WriteAllText(privateFile,key.ExportPkcs8PrivateKeyPem());
            using var manager=new ManagerCore(Path.Combine(folder,"data"),key.ExportSubjectPublicKeyInfoPem());
            manager.ImportSigner(privateFile);Assert(manager.CanSign,"matching key");
            var row=manager.Create("Test customer",new string('A',64),30);
            var validation=LicenseToken.Validate(row.Token,key.ExportSubjectPublicKeyInfoPem(),new string('A',64),DateTimeOffset.UtcNow,ManagerCore.Product);
            Assert(validation.IsValid,"generated QTX2 accepted by original utility library");
            Assert(!LicenseToken.Validate(row.Token,key.ExportSubjectPublicKeyInfoPem(),new string('B',64),null,ManagerCore.Product).IsValid,"wrong HWID rejected");
            Assert(!LicenseToken.Validate(row.Token,key.ExportSubjectPublicKeyInfoPem(),new string('A',64),DateTimeOffset.UtcNow.AddDays(31),ManagerCore.Product).IsValid,"expired key rejected");
            Assert(!LicenseToken.Inspect(row.Token,key.ExportSubjectPublicKeyInfoPem(),ManagerCore.Tier=="elite"?"quantix-pro":"quantix-elite").IsValid,"wrong edition rejected");
            manager.ImportToken(row.Token);Assert(manager.State.Licenses.Count==1,"duplicate import idempotent");
            manager.Revoke(row);Assert(row.Revoked&&row.SyncDirty,"revocation queued");
            bool exportBlocked=false;try{manager.ExportUpdate();}catch(InvalidOperationException){exportBlocked=true;}
            Assert(exportBlocked,"missing historical sync blocks revocation export");
            manager.State.HasSynced=true; // Isolated synthetic registry; no production history exists.
            var update=OfflineRevocations.Verify(manager.ExportUpdate(),key.ExportSubjectPublicKeyInfoPem(),ManagerCore.Product);
            Assert(update.RevokedIds.Contains(row.Id),"cumulative revocation signature");
            string sync=manager.BuildSyncRequest();string[] parts=sync.Split('.');
            byte[] Decode(string s)=>Convert.FromBase64String(s.Replace('-','+').Replace('_','/').PadRight((s.Length+3)/4*4,'='));
            Assert(parts[0]=="QMS1"&&key.VerifyData(System.Text.Encoding.ASCII.GetBytes(parts[0]+"."+parts[1]),Decode(parts[2]),HashAlgorithmName.SHA256,DSASignatureFormat.IeeeP1363FixedFieldConcatenation),"signed sync request");
            using var body=System.Text.Json.JsonDocument.Parse(Decode(parts[1]));Assert(body.RootElement.GetProperty("changes")[0].GetProperty("revoked").GetBoolean(),"sync wire fields");
            using var wrong=ECDsa.Create(ECCurve.NamedCurves.nistP256);File.WriteAllText(privateFile,wrong.ExportPkcs8PrivateKeyPem());
            bool rejected=false;try{manager.ImportSigner(privateFile);}catch(CryptographicException){rejected=true;}Assert(rejected,"wrong private key rejected");
            row.SyncVersion=1;row.SyncDirty=false;
            bool missingRejected=false;try{manager.MergeReply(new SyncReply{Version=1,Product=ManagerCore.Product,Revision=manager.State.Revision,Licenses=new()});}catch(IOException){missingRejected=true;}
            Assert(missingRejected&&manager.State.Licenses.Count==1,"server loss retains local data");
            if(report!=null){
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(report))!);
                File.WriteAllText(report,$"PASS: {checks} assertions. Temporary test keys only; no Railway/Discord requests or production signing keys used.");
                File.WriteAllText(report+".public.pem",key.ExportSubjectPublicKeyInfoPem());
                File.WriteAllText(report+".sync.txt",sync);
            }
            return 0;
        }catch(Exception ex){if(report!=null)File.WriteAllText(report,ex.ToString());return 71;}
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using QuantixLicensing;

namespace QuantixManager;

public sealed class LicenseRow
{
    public string Id { get; set; } = "";
    public string Customer { get; set; } = "";
    public string Hwid { get; set; } = "";
    public DateTimeOffset Issued { get; set; }
    public DateTimeOffset? Expires { get; set; }
    public string Token { get; set; } = "";
    public bool Revoked { get; set; }
    public bool Deleted { get; set; }
    public long SyncVersion { get; set; }
    public bool SyncDirty { get; set; }
    public string? ReplacedBy { get; set; }
}
public sealed class ManagerState
{
    public bool HasSynced { get; set; }
    public string BotUrl { get; set; } = "";
    public long Revision { get; set; } = 1;
    public List<string> ExternalRevokedIds { get; set; } = new();
    public List<LicenseRow> Licenses { get; set; } = new();
}
public sealed class SyncReply
{
    public int Version { get; set; }
    public string Product { get; set; } = "";
    public long Revision { get; set; }
    public List<string> Conflicts { get; set; } = new();
    public List<string> ExternalRevokedIds { get; set; } = new();
    public List<LicenseRow> Licenses { get; set; } = new();
}

public sealed class ManagerCore : IDisposable
{
#if QUANTIX_ELITE
    public const string Tier = "elite";
#else
    public const string Tier = "pro";
#endif
    public const string Product = "quantix-" + Tier;
    private readonly string folder;
    private readonly string publicPem;
    private ECDsa? signer;
    private readonly FileStream instanceLock;
    public ManagerState State { get; private set; }
    public bool CanSign => signer != null;
    public string StoragePath => folder;
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true };

    public ManagerCore(string? dataFolder = null, string? verifierOverride = null)
    {
        folder = dataFolder ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Quantix", "Managers", Tier);
        Directory.CreateDirectory(folder);
        instanceLock = new FileStream(Path.Combine(folder,"manager.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        using var stream = typeof(ManagerCore).Assembly.GetManifestResourceStream("SigningPublicKey");
        publicPem = verifierOverride ?? new StreamReader(stream ?? throw new IOException("Public verifier missing.")).ReadToEnd();
        string path = Path.Combine(folder,"licenses.json");
        State = File.Exists(path) ? JsonSerializer.Deserialize<ManagerState>(File.ReadAllText(path))
            ?? throw new IOException("Invalid manager database; restore its backup.") : new ManagerState();
        foreach (var row in State.Licenses) VerifyRow(row);
        string keyPath = Path.Combine(folder,"signing-key.dpapi");
        if (File.Exists(keyPath)) {
            byte[] bytes = ProtectedData.Unprotect(File.ReadAllBytes(keyPath), Encoding.UTF8.GetBytes(Product), DataProtectionScope.CurrentUser);
            try { LoadSigner(Encoding.UTF8.GetString(bytes)); } finally { CryptographicOperations.ZeroMemory(bytes); }
        }
    }

    private void LoadSigner(string pem)
    {
        var key = ECDsa.Create();
        try {
            key.ImportFromPem(pem);
            // Exporting a private parameter proves this is a signing key, not just the public PEM.
            var privatePart = key.ExportParameters(true);
            if (privatePart.D is null) throw new CryptographicException("Choose the existing private signing key.");
            CryptographicOperations.ZeroMemory(privatePart.D);
            using var verifier = ECDsa.Create(); verifier.ImportFromPem(publicPem);
            if (!key.ExportSubjectPublicKeyInfo().SequenceEqual(verifier.ExportSubjectPublicKeyInfo()))
                throw new CryptographicException("This private key does not match the existing " + Tier + " utility and bot. No replacement key was generated.");
            signer?.Dispose(); signer = key;
        } catch { key.Dispose(); throw; }
    }

    public void ImportSigner(string path)
    {
        byte[] bytes = File.ReadAllBytes(path);
        try {
            LoadSigner(Encoding.UTF8.GetString(bytes));
            AtomicWrite(Path.Combine(folder,"signing-key.dpapi"), ProtectedData.Protect(bytes,Encoding.UTF8.GetBytes(Product),DataProtectionScope.CurrentUser));
        } finally { CryptographicOperations.ZeroMemory(bytes); }
    }

    public void ConfigureUrl(string url)
    {
        var uri = new Uri(url.Trim());
        if (uri.Scheme != "https" || !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment))
            throw new ArgumentException("Enter the HTTPS base URL of your Railway bot, without credentials or query parameters.");
        State.BotUrl = uri.GetLeftPart(UriPartial.Authority); Save();
    }

    public LicenseRow Create(string customer, string hwid, int? days)
    {
        if (!CanSign) throw new InvalidOperationException("Import the existing Railway signing key for this edition first.");
        if (!HardwareFingerprint.TryNormalizeHash(hwid,out string normalized)) throw new ArgumentException("Paste the complete QX2 HWID.");
        if (string.IsNullOrWhiteSpace(customer) || customer.Trim().Length > 256) throw new ArgumentException("Enter a customer name (up to 256 characters).");
        if (days is <= 0 or > 36500) throw new ArgumentException("Invalid duration.");
        var now = DateTimeOffset.UtcNow;
        var payload = new LicensePayload { Version=2, Product=Product, LicenseId=Guid.NewGuid().ToString("N"),
            Customer=customer.Trim(), HwidHash=normalized, IssuedAtUtc=now, ExpiresAtUtc=days.HasValue ? now.AddDays(days.Value) : null };
        string pem = signer!.ExportPkcs8PrivateKeyPem();
        string token = LicenseToken.Create(payload,pem);
        var row = FromToken(token); row.SyncDirty=true;
        State.Licenses.Add(row);
        try { Save(); } catch { State.Licenses.Remove(row); throw; }
        return row;
    }

    private LicenseRow FromToken(string token)
    {
        token=string.Concat(token.Where(c=>!char.IsWhiteSpace(c)));
        var result=LicenseToken.Inspect(token,publicPem,Product);
        if (!result.IsValid) throw new ArgumentException(result.Message);
        var p=result.License!;
        return new LicenseRow { Id=p.LicenseId, Customer=p.Customer, Hwid=p.HwidHash, Issued=p.IssuedAtUtc, Expires=p.ExpiresAtUtc, Token=token };
    }
    private void VerifyRow(LicenseRow row)
    {
        var parsed=FromToken(row.Token);
        if (parsed.Id != row.Id || parsed.Customer != row.Customer || parsed.Hwid != row.Hwid || parsed.Issued != row.Issued || parsed.Expires != row.Expires || row.SyncVersion < 0)
            throw new InvalidDataException("License metadata does not match its signed token.");
    }
    public void ImportToken(string token)
    {
        var row=FromToken(token);
        if (State.Licenses.Any(x=>x.Id==row.Id)) return;
        row.Revoked=State.ExternalRevokedIds.Contains(row.Id); row.SyncDirty=true;
        State.Licenses.Add(row);
        try { Save(); } catch { State.Licenses.Remove(row); throw; }
    }
    public void Revoke(LicenseRow row)
    {
        bool previous=row.Revoked, dirty=row.SyncDirty;
        row.Revoked=true; row.SyncDirty=true; State.Revision++;
        try { Save(); } catch { row.Revoked=previous; row.SyncDirty=dirty; State.Revision--; throw; }
    }

    public string ExportUpdate()
    {
        if (!CanSign) throw new InvalidOperationException("Import the matching existing signing key first.");
        if (!State.HasSynced) throw new InvalidOperationException("Synchronize with the existing Railway registry before exporting revocations. Your old manager database was lost; an empty replacement list must not erase its history.");
        State.Revision++; Save();
        return OfflineRevocations.Sign(new OfflineRevocationManifest { Product=Product, Revision=State.Revision,
            IssuedUtc=DateTimeOffset.UtcNow, RevokedIds=State.Licenses.Where(x=>x.Revoked || x.Deleted).Select(x=>x.Id)
                .Concat(State.ExternalRevokedIds).Distinct().OrderBy(x=>x).ToArray() },signer!.ExportPkcs8PrivateKeyPem());
    }

    public string BuildSyncRequest()
    {
        if (!CanSign) throw new InvalidOperationException("Manager sync requires your existing private signing key; the bot verifies its signature.");
        if (State.Licenses.Count > 10000) throw new InvalidOperationException("Registry exceeds bot synchronization limit.");
        var body=new { version=1, product=Product, timestamp=DateTimeOffset.UtcNow.ToUnixTimeSeconds(), nonce=Guid.NewGuid().ToString("N"), revision=State.Revision,
            changes=State.Licenses.Where(x=>x.SyncDirty).Select(x=>new { token=x.Token, version=x.SyncVersion, revoked=x.Revoked, deleted=x.Deleted }).ToArray() };
        string b64=Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(body)).TrimEnd('=').Replace('+','-').Replace('/','_');
        string message="QMS1."+b64;
        string signature=Convert.ToBase64String(signer!.SignData(Encoding.ASCII.GetBytes(message),HashAlgorithmName.SHA256,DSASignatureFormat.IeeeP1363FixedFieldConcatenation))
            .TrimEnd('=').Replace('+','-').Replace('/','_');
        return message+"."+signature;
    }

    public async Task<string> SyncAsync()
    {
        if (string.IsNullOrWhiteSpace(State.BotUrl)) throw new InvalidOperationException("Configure the Railway HTTPS bot URL first.");
        // No redirects: signing credentials must never be forwarded to an unexpected host.
        using var handler=new HttpClientHandler { AllowAutoRedirect=false };
        using var client=new HttpClient(handler) { Timeout=TimeSpan.FromSeconds(25) };
        using var request=new HttpRequestMessage(HttpMethod.Post,State.BotUrl+"/api/manager/sync/"+Tier) {
            Content=new StringContent(JsonSerializer.Serialize(new { request=BuildSyncRequest() }),Encoding.UTF8,"application/json") };
        using var response=await client.SendAsync(request,HttpCompletionOption.ResponseHeadersRead);
        response.EnsureSuccessStatusCode();
        using var stream=await response.Content.ReadAsStreamAsync();
        using var memory=new MemoryStream(); byte[] buffer=new byte[8192]; int size;
        while ((size=await stream.ReadAsync(buffer))>0) {
            if (memory.Length+size>16_000_000) throw new IOException("Sync response exceeds size limit.");
            memory.Write(buffer,0,size);
        }
        var reply=JsonSerializer.Deserialize<SyncReply>(memory.ToArray()) ?? throw new IOException("Empty sync reply.");
        return MergeReply(reply);
    }

    public string MergeReply(SyncReply reply)
    {
        if (reply.Version!=1 || reply.Product!=Product || reply.Revision<1 || reply.Licenses.Count>10000 ||
            reply.Licenses.Select(x=>x.Id).Distinct().Count()!=reply.Licenses.Count ||
            reply.ExternalRevokedIds.Any(x=>!Guid.TryParseExact(x,"N",out _))) throw new IOException("Invalid synchronization reply.");
        foreach (var row in reply.Licenses) { VerifyRow(row); if (row.SyncVersion<1) throw new IOException("Missing server version."); }
        if (reply.Revision < State.Revision && State.Licenses.Any(x=>x.SyncVersion>0))
            throw new IOException("Server revision went backwards. Restore the Railway registry before syncing.");
        if (reply.Conflicts.Count>0) File.Copy(Path.Combine(folder,"licenses.json"),Path.Combine(folder,"conflict-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+".json"));
        var previous=State;
        var missing=State.Licenses.Where(x=>reply.Licenses.All(remote=>remote.Id!=x.Id)).ToList();
        if (missing.Any(x=>x.SyncVersion>0)) throw new IOException("Previously synchronized licenses are missing from the server. Local data retained.");
        State=new ManagerState { HasSynced=true, BotUrl=previous.BotUrl, Revision=Math.Max(reply.Revision,previous.Revision),
            Licenses=reply.Licenses.Concat(missing).ToList(), ExternalRevokedIds=reply.ExternalRevokedIds.Distinct().ToList() };
        foreach (var row in reply.Licenses) row.SyncDirty=false;
        try { Save(); } catch { State=previous; throw; }
        return $"Synchronized {reply.Licenses.Count} licenses. Conflicts: {reply.Conflicts.Count} (local conflict backup retained).";
    }

    public void Save() => AtomicWrite(Path.Combine(folder,"licenses.json"),JsonSerializer.SerializeToUtf8Bytes(State,Json));
    private static void AtomicWrite(string path,byte[] bytes)
    {
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try {
            using (var file=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) { file.Write(bytes);file.Flush(true); }
            if (File.Exists(path)) File.Replace(temp,path,path+".previous"); else File.Move(temp,path);
        } finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    public void Dispose() { signer?.Dispose();instanceLock.Dispose(); }
}

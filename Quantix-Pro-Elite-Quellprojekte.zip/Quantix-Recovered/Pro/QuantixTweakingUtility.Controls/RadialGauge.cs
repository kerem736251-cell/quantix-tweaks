using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace QuantixTweakingUtility.Controls;

public class RadialGauge : UserControl, IComponentConnector
{
	public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(double), typeof(RadialGauge), new PropertyMetadata(0.0));

	public static readonly DependencyProperty CaptionProperty = DependencyProperty.Register("Caption", typeof(string), typeof(RadialGauge), new PropertyMetadata(string.Empty));

	public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register("AccentBrush", typeof(Brush), typeof(RadialGauge), new PropertyMetadata(Brushes.MediumPurple));

	internal RadialGauge Root;

	private bool _contentLoaded;

	public double Value
	{
		get
		{
			return (double)GetValue(ValueProperty);
		}
		set
		{
			SetValue(ValueProperty, value);
		}
	}

	public string Caption
	{
		get
		{
			return (string)GetValue(CaptionProperty);
		}
		set
		{
			SetValue(CaptionProperty, value);
		}
	}

	public Brush AccentBrush
	{
		get
		{
			return (Brush)GetValue(AccentBrushProperty);
		}
		set
		{
			SetValue(AccentBrushProperty, value);
		}
	}

	public RadialGauge()
	{
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/quantixtweakingutility.controls.radialgauge.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		if (connectionId == 1)
		{
			Root = (RadialGauge)target;
		}
		else
		{
			_contentLoaded = true;
		}
	}
}

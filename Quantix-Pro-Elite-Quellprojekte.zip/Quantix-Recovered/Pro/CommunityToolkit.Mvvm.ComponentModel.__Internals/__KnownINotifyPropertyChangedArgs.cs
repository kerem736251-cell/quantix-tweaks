using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace CommunityToolkit.Mvvm.ComponentModel.__Internals;

[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
[DebuggerNonUserCode]
[ExcludeFromCodeCoverage]
[EditorBrowsable(EditorBrowsableState.Never)]
[Obsolete("This type is not intended to be used directly by user code")]
internal static class __KnownINotifyPropertyChangedArgs
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs SelectedNavItem = new PropertyChangedEventArgs("SelectedNavItem");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs CurrentViewModel = new PropertyChangedEventArgs("CurrentViewModel");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs CpuName = new PropertyChangedEventArgs("CpuName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs GpuName = new PropertyChangedEventArgs("GpuName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs RamTotal = new PropertyChangedEventArgs("RamTotal");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs OsName = new PropertyChangedEventArgs("OsName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs Uptime = new PropertyChangedEventArgs("Uptime");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs CpuUsage = new PropertyChangedEventArgs("CpuUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs GpuUsage = new PropertyChangedEventArgs("GpuUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs RamUsage = new PropertyChangedEventArgs("RamUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs GpuUsageAvailable = new PropertyChangedEventArgs("GpuUsageAvailable");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs IsBusy = new PropertyChangedEventArgs("IsBusy");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs IsApplied = new PropertyChangedEventArgs("IsApplied");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangedEventArgs StatusText = new PropertyChangedEventArgs("StatusText");
}

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace CommunityToolkit.Mvvm.ComponentModel.__Internals;

[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
[DebuggerNonUserCode]
[ExcludeFromCodeCoverage]
[EditorBrowsable(EditorBrowsableState.Never)]
[Obsolete("This type is not intended to be used directly by user code")]
internal static class __KnownINotifyPropertyChangingArgs
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs SelectedNavItem = new PropertyChangingEventArgs("SelectedNavItem");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs CurrentViewModel = new PropertyChangingEventArgs("CurrentViewModel");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs CpuName = new PropertyChangingEventArgs("CpuName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs GpuName = new PropertyChangingEventArgs("GpuName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs RamTotal = new PropertyChangingEventArgs("RamTotal");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs OsName = new PropertyChangingEventArgs("OsName");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs Uptime = new PropertyChangingEventArgs("Uptime");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs CpuUsage = new PropertyChangingEventArgs("CpuUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs GpuUsage = new PropertyChangingEventArgs("GpuUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs RamUsage = new PropertyChangingEventArgs("RamUsage");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs GpuUsageAvailable = new PropertyChangingEventArgs("GpuUsageAvailable");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs IsBusy = new PropertyChangingEventArgs("IsBusy");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs IsApplied = new PropertyChangingEventArgs("IsApplied");

	[EditorBrowsable(EditorBrowsableState.Never)]
	[Obsolete("This field is not intended to be referenced directly by user code")]
	public static readonly PropertyChangingEventArgs StatusText = new PropertyChangingEventArgs("StatusText");
}

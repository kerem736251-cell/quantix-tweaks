using System.Collections.ObjectModel;

namespace QuantixTweakingUtility.ViewModels;

public sealed class OptimizationGroupViewModel
{
	public string Title { get; set; }

	public ObservableCollection<OptimizationActionViewModel> Actions { get; set; }
}

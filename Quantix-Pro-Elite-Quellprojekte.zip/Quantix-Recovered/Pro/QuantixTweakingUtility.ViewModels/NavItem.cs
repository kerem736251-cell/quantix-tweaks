namespace QuantixTweakingUtility.ViewModels;

public sealed class NavItem
{
	public string Key { get; set; }

	public string Title { get; set; }

	public string ShortTitle { get; set; }

	public string IconGeometry { get; set; }
}

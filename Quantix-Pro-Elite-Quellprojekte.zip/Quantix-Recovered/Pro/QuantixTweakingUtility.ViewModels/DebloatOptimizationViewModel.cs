using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class DebloatOptimizationViewModel : OptimizationPageViewModel
{
	public DebloatOptimizationViewModel(IOptimizationService service)
		: base(service, OptimizationSection.Debloat, "LEAN WINDOWS", "Debloat Optimization", "Reduce optional background activity without mass-removing Windows dependencies.", "Service actions explain what stops working and restore the recorded startup mode. High-impact controls require confirmation and administrator rights.")
	{
	}
}

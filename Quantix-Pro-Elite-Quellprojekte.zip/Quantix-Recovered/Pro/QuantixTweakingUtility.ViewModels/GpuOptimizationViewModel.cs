using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class GpuOptimizationViewModel : OptimizationPageViewModel
{
	public GpuOptimizationViewModel(IOptimizationService service)
		: base(service, OptimizationSection.Gpu, "GRAPHICS", "GPU Optimization", "NVIDIA and Radeon driver tools with vendor-aware capability checks.", "Quantix opens official vendor panels for driver-profile choices and does not guess undocumented profile IDs.")
	{
	}
}

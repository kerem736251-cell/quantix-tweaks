using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class ExtrasOptimizationViewModel : OptimizationPageViewModel
{
	public ExtrasOptimizationViewModel(IOptimizationService service)
		: base(service, OptimizationSection.Extras, "GAMING", "Extra Optimization", "Game priority, CPU scheduling, input, DirectX, timing, and sound controls.", "Per-game priority is applied by executable name and never edits game files or anti-cheat components.")
	{
	}
}

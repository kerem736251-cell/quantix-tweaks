using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel.__Internals;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.DependencyInjection;

namespace QuantixTweakingUtility.ViewModels;

public sealed class MainViewModel : ObservableObject
{
	[ObservableProperty]
	private NavItem? _selectedNavItem;

	[ObservableProperty]
	private object? _currentViewModel;

	private readonly IServiceProvider _services;

	private readonly Dictionary<string, Type> _pageTypes;

	private readonly Dictionary<string, object> _pageCache = new Dictionary<string, object>();

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private RelayCommand? joinDiscordCommand;

	public ObservableCollection<NavItem> NavItems { get; }

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public NavItem? SelectedNavItem
	{
		get
		{
			return _selectedNavItem;
		}
		set
		{
			if (!EqualityComparer<NavItem>.Default.Equals(_selectedNavItem, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.SelectedNavItem);
				_selectedNavItem = value;
				OnSelectedNavItemChanged(value);
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.SelectedNavItem);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public object? CurrentViewModel
	{
		get
		{
			return _currentViewModel;
		}
		set
		{
			if (!EqualityComparer<object>.Default.Equals(_currentViewModel, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.CurrentViewModel);
				_currentViewModel = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.CurrentViewModel);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand JoinDiscordCommand => joinDiscordCommand ?? (joinDiscordCommand = new RelayCommand(JoinDiscord));

	public MainViewModel(IServiceProvider services)
	{
		_services = services;
		_pageTypes = new Dictionary<string, Type>
		{
			["home"] = typeof(HomeViewModel),
			["windows"] = typeof(WindowsOptimizationViewModel),
			["network"] = typeof(NetworkOptimizationViewModel),
			["debloat"] = typeof(DebloatOptimizationViewModel),
			["gpu"] = typeof(GpuOptimizationViewModel),
			["extras"] = typeof(ExtrasOptimizationViewModel)
		};
		NavItems = new ObservableCollection<NavItem>
		{
			new NavItem
			{
				Key = "home",
				Title = "Home",
				ShortTitle = "HOME",
				IconGeometry = "M3,9.5 L10,3 L17,9.5 V17 H12 V12 H8 V17 H3 Z"
			},
			new NavItem
			{
				Key = "windows",
				Title = "Windows Optimization",
				ShortTitle = "WINDOWS",
				IconGeometry = "M2,3 H9 V9 H2 Z M11,3 H18 V9 H11 Z M2,11 H9 V17 H2 Z M11,11 H18 V17 H11 Z"
			},
			new NavItem
			{
				Key = "network",
				Title = "Network Optimization",
				ShortTitle = "NETWORK",
				IconGeometry = "M2,8 C6,4 14,4 18,8 M5,11 C8,8 12,8 15,11 M8,14 C9,13 11,13 12,14 M10,17 L10,17"
			},
			new NavItem
			{
				Key = "debloat",
				Title = "Debloat Optimization",
				ShortTitle = "DEBLOAT",
				IconGeometry = "M4,6 H16 M8,6 V4 H12 V6 M6,6 L7,17 H13 L14,6"
			},
			new NavItem
			{
				Key = "gpu",
				Title = "GPU Optimization",
				ShortTitle = "GPU",
				IconGeometry = "M3,5 H17 V15 H3 Z M6,8 H11 V12 H6 Z M17,8 H19 M17,11 H19 M7,15 V18 M13,15 V18"
			},
			new NavItem
			{
				Key = "extras",
				Title = "Extra Optimization",
				ShortTitle = "EXTRAS",
				IconGeometry = "M10,3 L12,8 L17,10 L12,12 L10,17 L8,12 L3,10 L8,8 Z"
			}
		};
		SelectedNavItem = NavItems[0];
		CurrentViewModel = GetOrCreatePage("home");
	}

	private object GetOrCreatePage(string key)
	{
		if (_pageCache.TryGetValue(key, out var value))
		{
			return value;
		}
		if (!_pageTypes.TryGetValue(key, out var value2))
		{
			throw new InvalidOperationException("Unknown Quantix page: " + key);
		}
		object requiredService = _services.GetRequiredService(value2);
		_pageCache[key] = requiredService;
		return requiredService;
	}

	[RelayCommand]
	private static void JoinDiscord()
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://discord.gg/fBfUXh6YZt",
				UseShellExecute = true
			});
		}
		catch
		{
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	private void OnSelectedNavItemChanged(NavItem? value)
	{
		if (value != null)
		{
			CurrentViewModel = GetOrCreatePage(value.Key);
		}
	}
}

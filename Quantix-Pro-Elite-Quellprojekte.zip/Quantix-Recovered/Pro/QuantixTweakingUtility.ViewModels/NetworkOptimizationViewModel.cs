using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class NetworkOptimizationViewModel : OptimizationPageViewModel
{
	public NetworkOptimizationViewModel(IOptimizationService service)
		: base(service, OptimizationSection.Network, "CONNECTIVITY", "Network Optimization", "Adapter, TCP, DNS, and reset tools using Windows' own networking interfaces.", "Adapter controls are hardware-dependent. Test one change at a time; a network reset requires a Windows restart.")
	{
	}
}

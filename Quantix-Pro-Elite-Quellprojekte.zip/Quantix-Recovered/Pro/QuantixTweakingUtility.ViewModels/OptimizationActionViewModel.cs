using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel.__Internals;
using CommunityToolkit.Mvvm.Input;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class OptimizationActionViewModel : ObservableObject
{
	private readonly IOptimizationService _service;

	[ObservableProperty]
	private bool _isBusy;

	[ObservableProperty]
	private bool _isApplied;

	[ObservableProperty]
	private string _statusText = string.Empty;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private AsyncRelayCommand? runCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private AsyncRelayCommand? restoreCommand;

	public OptimizationActionDefinition Definition { get; }

	public string RiskLabel => Definition.Risk.ToString().ToUpperInvariant();

	public string TypeLabel => Definition.Kind switch
	{
		OptimizationActionKind.Reversible => "REVERSIBLE", 
		OptimizationActionKind.Launcher => "OPENS WINDOWS", 
		_ => "ONE-TIME", 
	};

	public bool CanRun
	{
		get
		{
			if (!IsBusy)
			{
				return !Definition.RestoreOnly;
			}
			return false;
		}
	}

	public bool CanRestore
	{
		get
		{
			if (Definition.CanRestore)
			{
				if (!IsBusy)
				{
					if (Definition.RestoreOnly)
					{
						return IsApplied;
					}
					return true;
				}
				return false;
			}
			return false;
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public bool IsBusy
	{
		get
		{
			return _isBusy;
		}
		set
		{
			if (!EqualityComparer<bool>.Default.Equals(_isBusy, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.IsBusy);
				_isBusy = value;
				OnIsBusyChanged(value);
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.IsBusy);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public bool IsApplied
	{
		get
		{
			return _isApplied;
		}
		set
		{
			if (!EqualityComparer<bool>.Default.Equals(_isApplied, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.IsApplied);
				_isApplied = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.IsApplied);
				OnPropertyChanged("CanRestore");
				RestoreCommand.NotifyCanExecuteChanged();
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string StatusText
	{
		get
		{
			return _statusText;
		}
		[MemberNotNull("_statusText")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_statusText, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.StatusText);
				_statusText = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.StatusText);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IAsyncRelayCommand RunCommand => runCommand ?? (runCommand = new AsyncRelayCommand(RunAsync, () => CanRun));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IAsyncRelayCommand RestoreCommand => restoreCommand ?? (restoreCommand = new AsyncRelayCommand(RestoreAsync, () => CanRestore));

	public OptimizationActionViewModel(OptimizationActionDefinition definition, IOptimizationService service)
	{
		Definition = definition;
		_service = service;
		RefreshStateAsync();
	}

	private async Task RefreshStateAsync()
	{
		try
		{
			IsApplied = await Definition.StateReader() == OptimizationState.Applied;
			if (Definition.RestoreOnly && string.IsNullOrEmpty(StatusText))
			{
				StatusText = (IsApplied ? "Saved original available. Restore, then restart Windows." : "No saved original found. This override cannot be reapplied.");
			}
		}
		catch
		{
			IsApplied = false;
		}
	}

	[RelayCommand(CanExecute = "CanRun")]
	private async Task RunAsync()
	{
		if (Definition.Risk == OptimizationRisk.High)
		{
			string value = (Definition.RequiresRestart ? "\n\nA Windows restart is required." : string.Empty);
			if (MessageBox.Show($"{Definition.Description}{value}\n\nRun {Definition.Name}?", "Confirm high-impact action", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
			{
				return;
			}
		}
		IsBusy = true;
		StatusText = "Working...";
		try
		{
			OptimizationActionResult optimizationActionResult = ((Definition.RequiresAdministrator && !AdminHelper.IsRunningAsAdministrator()) ? (await AdminHelper.RunElevatedActionAsync(Definition.Id)) : (await _service.ExecuteAsync(Definition.Id)));
			OptimizationActionResult optimizationActionResult2 = optimizationActionResult;
			StatusText = optimizationActionResult2.Message;
			await RefreshStateAsync();
		}
		finally
		{
			IsBusy = false;
		}
	}

	[RelayCommand(CanExecute = "CanRestore")]
	private async Task RestoreAsync()
	{
		IsBusy = true;
		StatusText = "Restoring...";
		try
		{
			OptimizationActionResult optimizationActionResult = ((Definition.RequiresAdministrator && !AdminHelper.IsRunningAsAdministrator()) ? (await AdminHelper.RunElevatedActionAsync(Definition.Id, restore: true)) : (await _service.RestoreAsync(Definition.Id)));
			OptimizationActionResult optimizationActionResult2 = optimizationActionResult;
			StatusText = optimizationActionResult2.Message;
			await RefreshStateAsync();
		}
		finally
		{
			IsBusy = false;
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	private void OnIsBusyChanged(bool value)
	{
		OnPropertyChanged("CanRun");
		OnPropertyChanged("CanRestore");
		RunCommand.NotifyCanExecuteChanged();
		RestoreCommand.NotifyCanExecuteChanged();
	}
}

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel.__Internals;
using CommunityToolkit.Mvvm.Input;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class HomeViewModel : ObservableObject
{
	private readonly ISystemInfoService _systemInfo;

	private readonly ILoggingService _logging;

	[ObservableProperty]
	private string _cpuName = "Detecting...";

	[ObservableProperty]
	private string _gpuName = "Detecting...";

	[ObservableProperty]
	private string _ramTotal = "Detecting...";

	[ObservableProperty]
	private string _osName = "Detecting...";

	[ObservableProperty]
	private string _uptime = "--";

	[ObservableProperty]
	private double _cpuUsage;

	[ObservableProperty]
	private double _gpuUsage;

	[ObservableProperty]
	private double _ramUsage;

	[ObservableProperty]
	private bool _gpuUsageAvailable;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private RelayCommand? openLogFolderCommand;

	public string UserName { get; } = Environment.UserName;

	public string AccessLevel { get; }

	public string LicenseOwner { get; }

	public string LicenseTerm { get; }

	public int TotalActions { get; }

	public int WorkingActions { get; }

	public int HighImpactActions { get; }

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string CpuName
	{
		get
		{
			return _cpuName;
		}
		[MemberNotNull("_cpuName")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_cpuName, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.CpuName);
				_cpuName = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.CpuName);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string GpuName
	{
		get
		{
			return _gpuName;
		}
		[MemberNotNull("_gpuName")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_gpuName, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.GpuName);
				_gpuName = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.GpuName);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string RamTotal
	{
		get
		{
			return _ramTotal;
		}
		[MemberNotNull("_ramTotal")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_ramTotal, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.RamTotal);
				_ramTotal = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.RamTotal);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string OsName
	{
		get
		{
			return _osName;
		}
		[MemberNotNull("_osName")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_osName, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.OsName);
				_osName = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.OsName);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string Uptime
	{
		get
		{
			return _uptime;
		}
		[MemberNotNull("_uptime")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_uptime, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.Uptime);
				_uptime = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.Uptime);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public double CpuUsage
	{
		get
		{
			return _cpuUsage;
		}
		set
		{
			if (!EqualityComparer<double>.Default.Equals(_cpuUsage, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.CpuUsage);
				_cpuUsage = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.CpuUsage);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public double GpuUsage
	{
		get
		{
			return _gpuUsage;
		}
		set
		{
			if (!EqualityComparer<double>.Default.Equals(_gpuUsage, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.GpuUsage);
				_gpuUsage = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.GpuUsage);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public double RamUsage
	{
		get
		{
			return _ramUsage;
		}
		set
		{
			if (!EqualityComparer<double>.Default.Equals(_ramUsage, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.RamUsage);
				_ramUsage = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.RamUsage);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public bool GpuUsageAvailable
	{
		get
		{
			return _gpuUsageAvailable;
		}
		set
		{
			if (!EqualityComparer<bool>.Default.Equals(_gpuUsageAvailable, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.GpuUsageAvailable);
				_gpuUsageAvailable = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.GpuUsageAvailable);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand OpenLogFolderCommand => openLogFolderCommand ?? (openLogFolderCommand = new RelayCommand(OpenLogFolder));

	public HomeViewModel(ISystemInfoService systemInfo, IOptimizationService optimizations, ILoggingService logging, ILicenseService licenseService)
	{
		_systemInfo = systemInfo;
		_logging = logging;
		AccessLevel = (AdminHelper.IsRunningAsAdministrator() ? "ADMINISTRATOR" : "STANDARD USER");
		LicenseValidation licenseValidation = licenseService.ValidateStoredLicense();
		LicenseOwner = (licenseValidation.IsValid ? licenseValidation.Customer : "UNLICENSED");
		LicenseTerm = (licenseValidation.ExpiresAt.HasValue ? $"EXPIRES  {licenseValidation.ExpiresAt.Value.LocalDateTime:d}" : "PERPETUAL LICENSE");
		TotalActions = optimizations.GetAllActions().Count;
		WorkingActions = TotalActions;
		HighImpactActions = optimizations.GetAllActions().Count((OptimizationActionDefinition action) => action.Risk == OptimizationRisk.High);
		_systemInfo.LiveMetricsUpdated += OnLiveMetricsUpdated;
		LoadAsync();
	}

	private async Task LoadAsync()
	{
		_ = 1;
		try
		{
			await Task.Yield();
			Task.Run((Action)_systemInfo.StartMonitoring);
			SystemSnapshot systemSnapshot = await _systemInfo.GetStaticInfoAsync();
			CpuName = systemSnapshot.CpuName;
			GpuName = systemSnapshot.GpuName;
			RamTotal = systemSnapshot.RamTotalDisplay;
			OsName = systemSnapshot.OsDisplay;
			Uptime = FormatUptime(systemSnapshot.Uptime);
		}
		catch (Exception ex)
		{
			_logging.Error("Home", "Could not load static system information.", ex);
		}
	}

	private void OnLiveMetricsUpdated(object? sender, SystemSnapshot snapshot)
	{
		Dispatcher dispatcher = Application.Current?.Dispatcher;
		if (dispatcher != null && !dispatcher.HasShutdownStarted)
		{
			dispatcher.BeginInvoke((Action)delegate
			{
				CpuUsage = snapshot.CpuUsagePercent;
				RamUsage = snapshot.RamUsagePercent;
				GpuUsageAvailable = snapshot.GpuUsagePercent.HasValue;
				GpuUsage = snapshot.GpuUsagePercent.GetValueOrDefault();
				Uptime = FormatUptime(snapshot.Uptime);
			});
		}
	}

	private static string FormatUptime(TimeSpan uptime)
	{
		if (!(uptime.TotalHours >= 1.0))
		{
			return $"{uptime.Minutes}m {uptime.Seconds}s";
		}
		return $"{(int)uptime.TotalHours}h {uptime.Minutes}m";
	}

	[RelayCommand]
	private static void OpenLogFolder()
	{
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Quantix", "Logs");
		Directory.CreateDirectory(text);
		Process.Start(new ProcessStartInfo
		{
			FileName = text,
			UseShellExecute = true
		});
	}
}

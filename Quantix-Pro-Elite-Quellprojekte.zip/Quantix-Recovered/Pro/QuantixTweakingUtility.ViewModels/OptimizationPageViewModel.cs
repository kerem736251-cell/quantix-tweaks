using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public abstract class OptimizationPageViewModel
{
	public string Eyebrow { get; }

	public string Title { get; }

	public string Description { get; }

	public string Notice { get; }

	public ObservableCollection<OptimizationGroupViewModel> Groups { get; }

	protected OptimizationPageViewModel(IOptimizationService service, OptimizationSection section, string eyebrow, string title, string description, string notice)
	{
		Eyebrow = eyebrow;
		Title = title;
		Description = description;
		Notice = notice;
		IReadOnlyList<OptimizationActionDefinition> actions = service.GetActions(section);
		Groups = new ObservableCollection<OptimizationGroupViewModel>(from action in actions
			group action by action.Group into @group
			select new OptimizationGroupViewModel
			{
				Title = @group.Key,
				Actions = new ObservableCollection<OptimizationActionViewModel>(@group.Select((OptimizationActionDefinition action) => new OptimizationActionViewModel(action, service)))
			});
	}
}

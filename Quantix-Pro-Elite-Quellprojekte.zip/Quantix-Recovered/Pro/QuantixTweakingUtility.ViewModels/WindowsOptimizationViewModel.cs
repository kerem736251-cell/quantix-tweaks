using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class WindowsOptimizationViewModel : OptimizationPageViewModel
{
	public WindowsOptimizationViewModel(IOptimizationService service)
		: base(service, OptimizationSection.Windows, "SYSTEM", "Windows Optimization", "Shell, performance, power, storage, repair, and GameDVR controls in one place.", "Reversible actions record the exact prior value. Restart badges mean Windows must be restarted before the change is fully active.")
	{
	}
}

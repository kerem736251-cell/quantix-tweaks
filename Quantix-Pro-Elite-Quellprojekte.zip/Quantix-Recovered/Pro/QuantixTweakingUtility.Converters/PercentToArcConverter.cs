using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace QuantixTweakingUtility.Converters;

public sealed class PercentToArcConverter : IValueConverter
{
	public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
	{
		double value2 = ((value is double num) ? num : ((!(value is int num2)) ? 0.0 : ((double)num2)));
		value2 = Math.Clamp(value2, 0.5, 99.9);
		double result = 60.0;
		if (parameter != null)
		{
			double.TryParse(parameter.ToString(), NumberStyles.Number, CultureInfo.InvariantCulture, out result);
		}
		double num3 = result / 2.0;
		double num4 = result / 2.0;
		double num5 = (result - 12.0) / 2.0;
		double num6 = -90.0;
		double num7 = -90.0 + value2 * 3.6;
		double num8 = num3 + num5 * Math.Cos(num6 * Math.PI / 180.0);
		double num9 = num4 + num5 * Math.Sin(num6 * Math.PI / 180.0);
		double num10 = num3 + num5 * Math.Cos(num7 * Math.PI / 180.0);
		double num11 = num4 + num5 * Math.Sin(num7 * Math.PI / 180.0);
		int num12 = ((value2 > 50.0) ? 1 : 0);
		return Geometry.Parse(FormattableString.Invariant($"M {num8:0.###},{num9:0.###} A {num5:0.###},{num5:0.###} 0 {num12} 1 {num10:0.###},{num11:0.###}"));
	}

	public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}

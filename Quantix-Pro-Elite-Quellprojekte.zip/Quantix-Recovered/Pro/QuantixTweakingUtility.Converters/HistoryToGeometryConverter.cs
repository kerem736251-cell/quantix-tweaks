using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace QuantixTweakingUtility.Converters;

public sealed class HistoryToGeometryConverter : IMultiValueConverter
{
	public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
	{
		if (values.Length == 0 || !(values[0] is IEnumerable source))
		{
			return Geometry.Empty;
		}
		List<double> list = source.Cast<object>().OfType<double>().ToList();
		if (list.Count < 2)
		{
			return Geometry.Empty;
		}
		(double Width, double Height) tuple = ParseSize(parameter?.ToString());
		double item = tuple.Width;
		double item2 = tuple.Height;
		StreamGeometry streamGeometry = new StreamGeometry();
		using (StreamGeometryContext streamGeometryContext = streamGeometry.Open())
		{
			for (int i = 0; i < list.Count; i++)
			{
				double x = (double)i * item / ((double)list.Count - 1.0);
				double y = item2 - Math.Clamp(list[i], 0.0, 100.0) / 100.0 * item2;
				if (i == 0)
				{
					streamGeometryContext.BeginFigure(new Point(x, y), isFilled: false, isClosed: false);
				}
				else
				{
					streamGeometryContext.LineTo(new Point(x, y), isStroked: true, isSmoothJoin: true);
				}
			}
		}
		streamGeometry.Freeze();
		return streamGeometry;
	}

	public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}

	private static (double Width, double Height) ParseSize(string? value)
	{
		string[] array = value?.Split(',') ?? Array.Empty<string>();
		if (array.Length != 2 || !double.TryParse(array[0], NumberStyles.Number, CultureInfo.InvariantCulture, out var result) || !double.TryParse(array[1], NumberStyles.Number, CultureInfo.InvariantCulture, out var result2))
		{
			return (Width: 240.0, Height: 64.0);
		}
		return (Width: result, Height: result2);
	}
}

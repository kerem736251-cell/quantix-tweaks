﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyCompany("QuantixTweakingUtility")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("2.8.7.0")]
[assembly: AssemblyInformationalVersion("2.8.7")]
[assembly: AssemblyProduct("QuantixTweakingUtility")]
[assembly: AssemblyTitle("QuantixTweakingUtility")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("2.8.7.0")]


using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;
using QuantixTweakingUtility.ViewModels;
using QuantixTweakingUtility.Views;

namespace QuantixTweakingUtility;

public class App : Application
{
	private IHost? _host;

	private bool _contentLoaded;

	public static IServiceProvider Services => ((App)Application.Current)._host.Services;

	protected override async void OnStartup(StartupEventArgs e)
	{
		base.OnStartup(e);
        if (await NetworkDiagnostics.RunAsync(e.Args)) return;
		int num = Array.IndexOf(e.Args, "--import-license-update");
		if (num >= 0)
		{
			try
			{
				OfflineUpdateUi.ImportFile(e.Args[num + 1]);
				Shutdown(0);
				return;
			}
			catch
			{
				Shutdown(65);
				return;
			}
		}
		base.ShutdownMode = ShutdownMode.OnExplicitShutdown;
		if (e.Args.Contains<string>("--verify-views", StringComparer.OrdinalIgnoreCase))
		{
			new HomeView();
			new OptimizationPageView();
			new ActivationWindow();
			Shutdown(0);
			return;
		}
		_host = Host.CreateDefaultBuilder().ConfigureServices(delegate(HostBuilderContext _, IServiceCollection services)
		{
			services.AddSingleton<ILoggingService, LoggingService>();
			services.AddSingleton<ISystemInfoService, SystemInfoService>();
			services.AddSingleton<IRestoreService, RestoreService>();
			services.AddSingleton<ILicenseService, LicenseService>();
			services.AddSingleton<IRevocationService, RevocationService>();
			services.AddSingleton<IOptimizationService, OptimizationEngineService>();
			services.AddSingleton<ICleanupService, CleanupService>();
			services.AddSingleton<MainViewModel>();
			services.AddSingleton<HomeViewModel>();
			services.AddSingleton<WindowsOptimizationViewModel>();
			services.AddSingleton<NetworkOptimizationViewModel>();
			services.AddSingleton<DebloatOptimizationViewModel>();
			services.AddSingleton<GpuOptimizationViewModel>();
			services.AddSingleton<ExtrasOptimizationViewModel>();
			services.AddTransient<ActivationWindow>();
			services.AddSingleton<MainWindow>();
		}).Build();
		_host.Start();
        if (await NetworkDiagnostics.RunVisibleAsync(e.Args)) return;
		if (e.Args.Contains<string>("--verify-catalog", StringComparer.OrdinalIgnoreCase))
		{
			IReadOnlyList<OptimizationActionDefinition> actions = Services.GetRequiredService<IOptimizationService>().GetAllActions();
			List<string> list = (from @group in actions.GroupBy<OptimizationActionDefinition, string>((OptimizationActionDefinition action) => action.Id, StringComparer.Ordinal)
				where @group.Count() > 1
				select @group.Key).ToList();
			OptimizationSection[] values = Enum.GetValues<OptimizationSection>();
			bool flag = actions.Count >= 55 && list.Count == 0 && values.All((OptimizationSection section) => actions.Any((OptimizationActionDefinition action) => action.Section == section)) && actions.All((OptimizationActionDefinition action) => !string.IsNullOrWhiteSpace(action.Group));
			if (!flag)
			{
				Console.Error.WriteLine($"Catalog verification failed: actions={actions.Count}, duplicates={string.Join(',', list)}.");
			}
			Shutdown((!flag) ? 2 : 0);
			return;
		}
		ILoggingService loggingService = Services.GetRequiredService<ILoggingService>();
		ILicenseService licenseService = Services.GetRequiredService<ILicenseService>();
		IRevocationService requiredService = Services.GetRequiredService<IRevocationService>();
		int num2 = Array.FindIndex(e.Args, (string argument) => string.Equals(argument, "--verify-license-file", StringComparison.OrdinalIgnoreCase));
		if (num2 >= 0)
		{
			if (num2 + 1 >= e.Args.Length || !File.Exists(e.Args[num2 + 1]))
			{
				Shutdown(3);
				return;
			}
			LicenseValidation verification = licenseService.ValidateLicense(File.ReadAllText(e.Args[num2 + 1]));
			if (verification.IsValid)
			{
				RevocationCheck revocationCheck = await requiredService.CheckAsync(verification.LicenseId);
				if (revocationCheck.IsRevoked)
				{
					verification = LicenseValidation.Invalid(revocationCheck.Message);
				}
			}
			Shutdown((!verification.IsValid) ? 4 : 0);
			return;
		}
		int num3 = Array.FindIndex(e.Args, (string argument) => string.Equals(argument, "--activate-license-file", StringComparison.OrdinalIgnoreCase));
		if (num3 >= 0)
		{
			if (num3 + 1 >= e.Args.Length || !File.Exists(e.Args[num3 + 1]))
			{
				loggingService.Warn("License", "Activation file argument was missing or unreadable.");
				Shutdown(3);
				return;
			}
			LicenseValidation verification = licenseService.ActivateLicense(File.ReadAllText(e.Args[num3 + 1]));
			if (verification.IsValid)
			{
				RevocationCheck revocationCheck2 = await requiredService.CheckAsync(verification.LicenseId);
				if (revocationCheck2.IsRevoked)
				{
					licenseService.RemoveStoredLicense("revoked");
					verification = LicenseValidation.Invalid(revocationCheck2.Message);
				}
			}
			Shutdown((!verification.IsValid) ? 4 : 0);
			return;
		}
		if (((ReadOnlySpan<string>)e.Args).Contains("--verify-saved-license"))
		{
			Shutdown((!licenseService.ValidateStoredLicense().IsValid) ? 4 : 0);
			return;
		}
		if (!e.Args.Any(a => a.StartsWith("--", StringComparison.Ordinal)))
			SessionRestorePoint.StartOnce(message => loggingService.Info("SystemRestore", message));
		int num4 = Array.FindIndex(e.Args, (string argument) => string.Equals(argument, "--execute-action", StringComparison.OrdinalIgnoreCase));
		int num5 = Array.FindIndex(e.Args, (string argument) => string.Equals(argument, "--restore-action", StringComparison.OrdinalIgnoreCase));
		int num6 = ((num4 >= 0) ? num4 : num5);
		if (num6 < 0 && Services.GetRequiredService<ActivationWindow>().ShowDialog() != true)
		{
			Shutdown(1);
			return;
		}
		LicenseValidation licenseStatus = licenseService.ValidateStoredLicense();
		if (!licenseStatus.IsValid)
		{
			Shutdown(4);
			return;
		}
		if ((await requiredService.CheckAsync(licenseStatus.LicenseId)).IsRevoked)
		{
			Shutdown(4);
			return;
		}
		loggingService.Info("License", $"License {licenseStatus.LicenseId} validated for {licenseStatus.Customer}.");
		if (num6 >= 0)
		{
			if (num6 + 1 >= e.Args.Length)
			{
				loggingService.Warn("OptimizationEngine", "Elevated action id was missing.");
				Shutdown(5);
				return;
			}
			IOptimizationService requiredService2 = Services.GetRequiredService<IOptimizationService>();
			OptimizationActionResult optimizationActionResult = ((num5 >= 0) ? (await requiredService2.RestoreAsync(e.Args[num6 + 1])) : (await requiredService2.ExecuteAsync(e.Args[num6 + 1])));
			OptimizationActionResult optimizationActionResult2 = optimizationActionResult;
			MessageBox.Show(optimizationActionResult2.Message, optimizationActionResult2.Success ? "Quantix action completed" : "Quantix action failed", MessageBoxButton.OK, optimizationActionResult2.Success ? MessageBoxImage.Asterisk : MessageBoxImage.Exclamation);
			Shutdown((!optimizationActionResult2.Success) ? 5 : 0);
		}
		else
		{
			loggingService.Info("Application", "Quantix Tweaking Utility Pro starting up.");
			MainWindow mainWindow = (MainWindow)(base.MainWindow = Services.GetRequiredService<MainWindow>());
			mainWindow.Closed += delegate
			{
				Shutdown();
			};
			mainWindow.Show();
		}
	}

	protected override void OnExit(ExitEventArgs e)
	{
		if (_host != null)
		{
			(_host.Services.GetService<ISystemInfoService>() as IDisposable)?.Dispose();
			_host.StopAsync().GetAwaiter().GetResult();
			_host.Dispose();
		}
		base.OnExit(e);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public static void Main()
	{
		App app = new App();
		app.InitializeComponent();
		app.Run();
	}
}


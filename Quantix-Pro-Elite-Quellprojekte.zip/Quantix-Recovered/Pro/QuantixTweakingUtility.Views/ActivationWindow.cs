using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.Views;

public class ActivationWindow : Window, IComponentConnector
{
	private readonly ILicenseService? _licenseService;

	internal TextBlock HardwareIdText;

	internal TextBox LicenseKeyText;

	internal TextBlock StatusText;

	internal Button ActivateButton;

	private bool _contentLoaded;

	public ActivationWindow()
	{
		InitializeComponent();
	}

	public ActivationWindow(ILicenseService licenseService)
		: this()
	{
		_licenseService = licenseService;
		HardwareIdText.Text = licenseService.HardwareId;
		try
		{
			if (File.Exists(licenseService.LicenseFilePath))
			{
				LicenseKeyText.Text = File.ReadAllText(licenseService.LicenseFilePath);
			}
		}
		catch
		{
			StatusText.Text = "Saved key could not be read. Paste your key to verify.";
		}
	}

	private void CopyHardwareId_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			Clipboard.SetText(HardwareIdText.Text);
			StatusText.Text = "Hardware ID copied.";
			StatusText.Foreground = (Brush)FindResource("GreenBrush");
		}
		catch
		{
			StatusText.Text = "Windows could not access the clipboard.";
			StatusText.Foreground = (Brush)FindResource("AmberBrush");
		}
	}

	private void PasteKey_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			if (Clipboard.ContainsText())
			{
				LicenseKeyText.Text = Clipboard.GetText().Trim();
			}
		}
		catch
		{
			StatusText.Text = "Windows could not access the clipboard.";
			StatusText.Foreground = (Brush)FindResource("AmberBrush");
		}
	}

	private void LicenseKeyText_TextChanged(object sender, TextChangedEventArgs e)
	{
		if (ActivateButton != null)
		{
			ActivateButton.IsEnabled = !string.IsNullOrWhiteSpace(LicenseKeyText.Text);
		}
	}

	private void Activate_Click(object sender, RoutedEventArgs e)
	{
		if (_licenseService != null)
		{
			ActivateButton.IsEnabled = false;
			LicenseValidation licenseValidation = _licenseService.ActivateLicense(LicenseKeyText.Text);
			StatusText.Text = licenseValidation.Message;
			StatusText.Foreground = (Brush)FindResource(licenseValidation.IsValid ? "GreenBrush" : "RedBrush");
			if (licenseValidation.IsValid)
			{
				base.DialogResult = true;
				Close();
			}
			else
			{
				ActivateButton.IsEnabled = true;
				LicenseKeyText.Focus();
			}
		}
	}

	private void ImportOfflineUpdate_Click(object sender, RoutedEventArgs e)
	{
		OfflineUpdateUi.Import(this);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/quantixtweakingutility.views.activationwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			HardwareIdText = (TextBlock)target;
			break;
		case 2:
			((Button)target).Click += CopyHardwareId_Click;
			break;
		case 3:
			LicenseKeyText = (TextBox)target;
			LicenseKeyText.TextChanged += LicenseKeyText_TextChanged;
			break;
		case 4:
			StatusText = (TextBlock)target;
			break;
		case 5:
			((Button)target).Click += PasteKey_Click;
			break;
		case 6:
			ActivateButton = (Button)target;
			ActivateButton.Click += Activate_Click;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}

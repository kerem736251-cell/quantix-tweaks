namespace QuantixTweakingUtility.Services;

public sealed record RevocationCheck(bool IsRevoked, bool IsOnline, string Message);

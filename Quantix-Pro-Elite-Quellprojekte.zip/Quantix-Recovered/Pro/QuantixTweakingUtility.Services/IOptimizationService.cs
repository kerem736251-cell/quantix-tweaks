using System.Collections.Generic;
using System.Threading.Tasks;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public interface IOptimizationService
{
	IReadOnlyList<OptimizationActionDefinition> GetAllActions();

	IReadOnlyList<OptimizationActionDefinition> GetActions(OptimizationSection section);

	Task<OptimizationActionResult> ExecuteAsync(string actionId);

	Task<OptimizationActionResult> RestoreAsync(string actionId);
}

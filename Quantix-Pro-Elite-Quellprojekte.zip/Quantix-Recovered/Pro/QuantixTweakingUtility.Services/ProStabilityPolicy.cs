using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public static class ProStabilityPolicy
{
	public const string Message = "Retired while investigating game-close/relaunch freezes. Restore the saved original value, then restart Windows before testing Fortnite. This setting is a suspect, not a confirmed cause.";

	private static readonly HashSet<string> Ids = new HashSet<string>(StringComparer.Ordinal) { "extras.fortnite", "extras.valorant", "extras.fivem", "extras.specific-game", "gpu.nvidia-msi", "gpu.nvidia-latency" };

	public static OptimizationActionDefinition Protect(OptimizationActionDefinition source, Func<bool> hasBackup)
	{
		if (!Ids.Contains(source.Id))
		{
			return source;
		}
		return new OptimizationActionDefinition
		{
			Id = source.Id,
			Name = source.Name + " (restore only)",
			Description = "Retired while investigating game-close/relaunch freezes. Restore the saved original value, then restart Windows before testing Fortnite. This setting is a suspect, not a confirmed cause.",
			Section = source.Section,
			Group = "Stability recovery",
			Risk = source.Risk,
			Kind = source.Kind,
			RequiresAdministrator = source.RequiresAdministrator,
			RequiresRestart = true,
			RestoreOnly = true,
			ActionLabel = "RETIRED",
			RestoreLabel = "RESTORE ORIGINAL",
			StateReader = () => Task.FromResult(hasBackup() ? OptimizationState.Applied : OptimizationState.NotApplied),
			ExecuteAction = () => Task.FromResult(OptimizationActionResult.Fail("Retired while investigating game-close/relaunch freezes. Restore the saved original value, then restart Windows before testing Fortnite. This setting is a suspect, not a confirmed cause.")),
			RestoreAction = async delegate
			{
				if (!hasBackup() || source.RestoreAction == null)
				{
					return OptimizationActionResult.Fail("No saved original value exists. No settings changed.");
				}
				OptimizationActionResult optimizationActionResult = await source.RestoreAction();
				return optimizationActionResult.Success ? OptimizationActionResult.Ok(optimizationActionResult.Message + " Restart Windows before testing Fortnite again.") : optimizationActionResult;
			}
		};
	}
}

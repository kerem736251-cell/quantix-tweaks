using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Threading.Tasks;
using System.Timers;
using Microsoft.Win32;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public sealed class SystemInfoService : ISystemInfoService, IDisposable
{
	private readonly ILoggingService _logging;

	private Timer? _timer;

	private PerformanceCounter? _cpuCounter;

	private PerformanceCounter? _availableMemoryCounter;

	private List<PerformanceCounter>? _gpuEngineCounters;

	private double _totalRamMb;

	private SystemSnapshot? _staticInfoCache;

	public event EventHandler<SystemSnapshot>? LiveMetricsUpdated;

	public SystemInfoService(ILoggingService logging)
	{
		_logging = logging;
	}

	public async Task<SystemSnapshot> GetStaticInfoAsync()
	{
		if (_staticInfoCache != null)
		{
			return _staticInfoCache;
		}
		return await Task.Run(delegate
		{
			SystemSnapshot systemSnapshot = new SystemSnapshot();
			try
			{
				using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT Name FROM Win32_Processor");
				using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectSearcher.Get().GetEnumerator();
				if (managementObjectEnumerator.MoveNext())
				{
					ManagementBaseObject current = managementObjectEnumerator.Current;
					systemSnapshot.CpuName = current["Name"]?.ToString()?.Trim() ?? "Unknown CPU";
				}
			}
			catch (Exception ex)
			{
				_logging.Error("SystemInfoService", "Failed reading CPU name via WMI.", ex);
				systemSnapshot.CpuName = "Unknown";
			}
			try
			{
				using ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT Name FROM Win32_VideoController");
				foreach (ManagementBaseObject item in managementObjectSearcher2.Get())
				{
					string text = item["Name"]?.ToString();
					if (!string.IsNullOrWhiteSpace(text))
					{
						systemSnapshot.GpuName = text.Trim();
						break;
					}
				}
			}
			catch (Exception ex2)
			{
				_logging.Error("SystemInfoService", "Failed reading GPU name via WMI.", ex2);
				systemSnapshot.GpuName = "Unknown";
			}
			try
			{
				using ManagementObjectSearcher managementObjectSearcher3 = new ManagementObjectSearcher("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem");
				using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator3 = managementObjectSearcher3.Get().GetEnumerator();
				if (managementObjectEnumerator3.MoveNext() && double.TryParse(managementObjectEnumerator3.Current["TotalPhysicalMemory"]?.ToString(), out var result))
				{
					_totalRamMb = result / 1024.0 / 1024.0;
					double value = result / 1024.0 / 1024.0 / 1024.0;
					systemSnapshot.RamTotalDisplay = $"{value:0} GB";
				}
			}
			catch (Exception ex3)
			{
				_logging.Error("SystemInfoService", "Failed reading RAM size via WMI.", ex3);
				systemSnapshot.RamTotalDisplay = "Unknown";
			}
			systemSnapshot.OsDisplay = GetFriendlyOsVersion();
			systemSnapshot.Uptime = TimeSpan.FromMilliseconds(Environment.TickCount64);
			PopulateSystemDriveInfo(systemSnapshot);
			_staticInfoCache = systemSnapshot;
			return systemSnapshot;
		});
	}

	public void StartMonitoring()
	{
		if (_timer == null)
		{
			try
			{
				_cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
				_cpuCounter.NextValue();
				_availableMemoryCounter = new PerformanceCounter("Memory", "Available MBytes");
				_gpuEngineCounters = TryBuildGpuEngineCounters();
			}
			catch (Exception ex)
			{
				_logging.Error("SystemInfoService", "Failed to initialize performance counters.", ex);
			}
			_timer = new Timer(1000.0);
			_timer.Elapsed += OnTick;
			_timer.AutoReset = true;
			_timer.Start();
		}
	}

	public void StopMonitoring()
	{
		_timer?.Stop();
		_timer?.Dispose();
		_timer = null;
	}

	private void OnTick(object? sender, ElapsedEventArgs e)
	{
		SystemSnapshot systemSnapshot = new SystemSnapshot
		{
			Uptime = TimeSpan.FromMilliseconds(Environment.TickCount64)
		};
		try
		{
			if (_cpuCounter != null)
			{
				systemSnapshot.CpuUsagePercent = Math.Clamp(_cpuCounter.NextValue(), 0f, 100f);
			}
		}
		catch
		{
		}
		try
		{
			if (_availableMemoryCounter != null && _totalRamMb > 0.0)
			{
				float num = _availableMemoryCounter.NextValue();
				double num2 = _totalRamMb - (double)num;
				systemSnapshot.RamUsagePercent = Math.Clamp(num2 / _totalRamMb * 100.0, 0.0, 100.0);
			}
		}
		catch
		{
		}
		try
		{
			List<PerformanceCounter> gpuEngineCounters = _gpuEngineCounters;
			if (gpuEngineCounters != null && gpuEngineCounters.Count > 0)
			{
				double value = _gpuEngineCounters.Sum((PerformanceCounter c) => SafeNextValue(c));
				systemSnapshot.GpuUsagePercent = Math.Clamp(value, 0.0, 100.0);
			}
			else
			{
				systemSnapshot.GpuUsagePercent = null;
			}
		}
		catch
		{
			systemSnapshot.GpuUsagePercent = null;
		}
		this.LiveMetricsUpdated?.Invoke(this, systemSnapshot);
	}

	private static double SafeNextValue(PerformanceCounter counter)
	{
		try
		{
			return counter.NextValue();
		}
		catch
		{
			return 0.0;
		}
	}

	private List<PerformanceCounter>? TryBuildGpuEngineCounters()
	{
		try
		{
			if (!PerformanceCounterCategory.Exists("GPU Engine"))
			{
				return null;
			}
			List<string> list = (from n in new PerformanceCounterCategory("GPU Engine").GetInstanceNames()
				where n.Contains("engtype_3D", StringComparison.OrdinalIgnoreCase)
				select n).ToList();
			if (list.Count == 0)
			{
				return null;
			}
			List<PerformanceCounter> list2 = new List<PerformanceCounter>();
			foreach (string item in list)
			{
				try
				{
					list2.Add(new PerformanceCounter("GPU Engine", "Utilization Percentage", item, readOnly: true));
				}
				catch
				{
				}
			}
			return list2;
		}
		catch (Exception ex)
		{
			_logging.Error("SystemInfoService", "GPU Engine counters unavailable.", ex);
			return null;
		}
	}

	private static string GetFriendlyOsVersion()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion");
			string text = registryKey?.GetValue("ProductName") as string;
			string text2 = registryKey?.GetValue("DisplayVersion") as string;
			if (!string.IsNullOrWhiteSpace(text))
			{
				return string.IsNullOrWhiteSpace(text2) ? text : (text + " " + text2);
			}
		}
		catch
		{
		}
		return Environment.OSVersion.VersionString;
	}

	private static void PopulateSystemDriveInfo(SystemSnapshot snapshot)
	{
		try
		{
			string pathRoot = Path.GetPathRoot(Environment.SystemDirectory);
			if (!string.IsNullOrWhiteSpace(pathRoot))
			{
				DriveInfo driveInfo = new DriveInfo(pathRoot);
				if (driveInfo.IsReady)
				{
					long num = driveInfo.TotalSize - driveInfo.AvailableFreeSpace;
					snapshot.DiskUsagePercent = Math.Clamp((double)num / (double)driveInfo.TotalSize * 100.0, 0.0, 100.0);
					snapshot.DiskDisplay = $"{driveInfo.Name.TrimEnd('\\')}  {(double)driveInfo.AvailableFreeSpace / 1024.0 / 1024.0 / 1024.0:0} GB free";
				}
			}
		}
		catch
		{
			snapshot.DiskDisplay = "Unknown";
		}
	}

	public void Dispose()
	{
		StopMonitoring();
		_cpuCounter?.Dispose();
		_availableMemoryCounter?.Dispose();
		if (_gpuEngineCounters == null)
		{
			return;
		}
		foreach (PerformanceCounter gpuEngineCounter in _gpuEngineCounters)
		{
			gpuEngineCounter.Dispose();
		}
	}
}

using System;
using System.Threading.Tasks;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public interface ISystemInfoService
{
	event EventHandler<SystemSnapshot>? LiveMetricsUpdated;

	Task<SystemSnapshot> GetStaticInfoAsync();

	void StartMonitoring();

	void StopMonitoring();
}

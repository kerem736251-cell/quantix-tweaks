using System.Threading;
using System.Threading.Tasks;

namespace QuantixTweakingUtility.Services;

public interface IRevocationService
{
	Task<RevocationCheck> CheckAsync(string licenseId, CancellationToken cancellationToken = default(CancellationToken));
}

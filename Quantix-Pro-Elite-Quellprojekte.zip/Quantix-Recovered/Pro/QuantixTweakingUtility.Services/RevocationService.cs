using System.Threading;
using System.Threading.Tasks;

namespace QuantixTweakingUtility.Services;

public sealed class RevocationService : IRevocationService
{
	public RevocationService(ILoggingService logging)
	{
	}

	public Task<RevocationCheck> CheckAsync(string licenseId, CancellationToken cancellationToken = default(CancellationToken))
	{
		cancellationToken.ThrowIfCancellationRequested();
		return Task.FromResult(new RevocationCheck(IsRevoked: false, IsOnline: false, "Offline signed licensing; no online revocation service is configured."));
	}
}

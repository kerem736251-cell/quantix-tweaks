﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.ServiceProcess;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public sealed class OptimizationEngineService : IOptimizationService
{
	private sealed record RegistryChange(RegistryHive Hive, string Path, string Name, RegistryValueKind Kind, object? Value, bool Delete);

	private sealed record RegistrySnapshot(RegistryHive Hive, string Path, string Name, bool Existed, RegistryValueKind Kind, string Value);

	private sealed record ServiceSnapshot(string Name, int StartValue, bool WasRunning);

	private sealed record ProcessResult(int ExitCode, string Output);

	private const string MissingValue = "__QUANTIX_MISSING__";

	private readonly ILoggingService _logging;

	private readonly IRestoreService _restore;

	private readonly ICleanupService _cleanup;

	private readonly List<OptimizationActionDefinition> _actions;

	public OptimizationEngineService(ILoggingService logging, IRestoreService restore, ICleanupService cleanup)
	{
		_logging = logging;
		_restore = restore;
		_cleanup = cleanup;
		_actions = (from a in BuildCatalog()
			select ProStabilityPolicy.Protect(a, () => _restore.GetBackup(a.Id) != null)).ToList();

		IGrouping<string, OptimizationActionDefinition> grouping = _actions.GroupBy<OptimizationActionDefinition, string>((OptimizationActionDefinition action) => action.Id, StringComparer.Ordinal).FirstOrDefault((IGrouping<string, OptimizationActionDefinition> group) => group.Count() > 1);
		if (grouping != null)
		{
			throw new InvalidOperationException("Duplicate optimization action id: " + grouping.Key);
		}
	}

	public IReadOnlyList<OptimizationActionDefinition> GetAllActions()
	{
		return _actions;
	}

	public IReadOnlyList<OptimizationActionDefinition> GetActions(OptimizationSection section)
	{
		return _actions.Where((OptimizationActionDefinition action) => action.Section == section).ToList();
	}

	public async Task<OptimizationActionResult> ExecuteAsync(string actionId)
	{
		OptimizationActionDefinition action = _actions.FirstOrDefault((OptimizationActionDefinition item) => item.Id == actionId);
		if (action == null)
		{
			return OptimizationActionResult.Fail("Unknown Quantix action.");
		}
		if (action.RestoreOnly)
		{
			return OptimizationActionResult.Fail(action.Section == OptimizationSection.Network ? "Use Optimize Network. Legacy controls are recovery only." : ProStabilityPolicy.Message);
		}
		if (action.RequiresAdministrator && !AdminHelper.IsRunningAsAdministrator())
		{
			return OptimizationActionResult.Fail("Restart Quantix as administrator to run this action.");
		}
		try
		{
			OptimizationActionResult result = await action.ExecuteAction();
			Log(action, "Run", result);
			return result;
		}
		catch (Exception ex)
		{
			_logging.Error("OptimizationEngine", "Run '" + action.Name + "' failed.", ex);
			return OptimizationActionResult.Fail("The action failed. See the Quantix log for details.");
		}
	}

	public async Task<OptimizationActionResult> RestoreAsync(string actionId)
	{
		OptimizationActionDefinition action = _actions.FirstOrDefault((OptimizationActionDefinition item) => item.Id == actionId);
		if (action == null)
		{
			return OptimizationActionResult.Fail("Unknown Quantix action.");
		}
		if (!action.CanRestore || action.RestoreAction == null)
		{
			return OptimizationActionResult.Fail("This is a one-time action and has no persistent setting to restore.");
		}
		if (_restore.GetBackup(action.Id) == null)
		{
			return OptimizationActionResult.Fail("Quantix has no recorded change for this action.");
		}
		if (action.RequiresAdministrator && !AdminHelper.IsRunningAsAdministrator())
		{
			return OptimizationActionResult.Fail("Restart Quantix as administrator to restore this action.");
		}
		try
		{
			OptimizationActionResult result = await action.RestoreAction();
			Log(action, "Restore", result);
			return result;
		}
		catch (Exception ex)
		{
			_logging.Error("OptimizationEngine", "Restore '" + action.Name + "' failed.", ex);
			return OptimizationActionResult.Fail("Restore failed. See the Quantix log for details.");
		}
	}

	private void Log(OptimizationActionDefinition action, string verb, OptimizationActionResult result)
	{
		string message = $"{verb} '{action.Name}': {(result.Success ? "success" : "failed")} - {result.Message}";
		if (result.Success)
		{
			_logging.Info("OptimizationEngine", message);
		}
		else
		{
			_logging.Warn("OptimizationEngine", message);
		}
	}

	private List<OptimizationActionDefinition> BuildCatalog()
	{
		List<OptimizationActionDefinition> list = new List<OptimizationActionDefinition>();
		list.Add(RegistryAction("windows.best-settings", "Optimize Windows Settings", "Disables Windows tips and suggested content while leaving update and security services intact.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, false, false, Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager", "SoftLandingEnabled", 0), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager", "SubscribedContent-338389Enabled", 0)));
		list.Add(RegistryAction("windows.useless-features", "Disable useless features", "Turns off Microsoft consumer-app suggestions through the supported policy value.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, true, false, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent", "DisableWindowsConsumerFeatures", 1)));
		list.Add(RegistryAction("windows.explorer", "Explorer Tweaks", "Shows file extensions, opens File Explorer to This PC, and isolates Explorer windows for stability.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, false, true, Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", 0), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "LaunchTo", 1), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "SeparateProcess", 1)));
		list.Add(RegistryAction("windows.core", "Windows Tweaks", "Enables long Win32 paths and removes sync-provider promotions from Explorer.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\FileSystem", "LongPathsEnabled", 1), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ShowSyncProviderNotifications", 0)));
		list.Add(RegistryAction("windows.menu-kill", "Menu Kill time", "Reduces the current user's menu-open delay to 100 ms without changing application termination timeouts.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, false, true, StringValue(RegistryHive.CurrentUser, "Control Panel\\Desktop", "MenuShowDelay", "100")));
		list.Add(RegistryAction("windows.additional", "Additional Tweaks", "Disables the advertising identifier and tailored diagnostic-data experiences for the current user.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.Low, false, false, Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo", "Enabled", 0), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Privacy", "TailoredExperiencesWithDiagnosticDataEnabled", 0)));
		list.Add(ServiceAction("windows.update-blocker", "Windows Update Blocker", "Stops and disables the Windows Update service. Security and quality updates will not install until you use Revert.", OptimizationSection.Windows, "Windows Settings", OptimizationRisk.High, "wuauserv"));
		list.Add(RegistryAction("windows.io-boost", "IO Tweaks + Boost", "Allocates a larger NTFS metadata cache. This can improve heavy file workloads but uses more memory.", OptimizationSection.Windows, "Performance Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\FileSystem", "NtfsMemoryUsage", 2)));
		list.Add(RegistryAction("windows.latency-cap", "Latency Cap Tweaks", "Sets MMCSS system responsiveness to 10 percent while keeping foreground multimedia scheduling enabled.", OptimizationSection.Windows, "Performance Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", 10)));
		list.Add(Launcher("windows.disable-mitigations", "Exploit Protection Settings", "Opens Windows Exploit Protection so mitigation changes remain explicit and use Microsoft's supported interface.", OptimizationSection.Windows, "Performance Tweaks", "OPEN", "windowsdefender://exploitprotection"));
		list.Add(RegistryAction("windows.onedrive", "Disable Onedrive", "Applies the OneDrive file-sync policy. Existing local files are not removed.", OptimizationSection.Windows, "Performance Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Windows\\OneDrive", "DisableFileSyncNGSC", 1)));
		list.Add(PowerPlanAction());
		list.Add(RegistryAction("debloat.edge-background", "Stop Edge background apps", "Stops Edge extensions and apps from continuing after its last window closes. Background notifications may stop. Close Edge normally after applying. Revert restores the previous policy.", OptimizationSection.Debloat, "Background Resources", OptimizationRisk.Medium, true, false, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Edge", "BackgroundModeEnabled", 0)));
		list.Add(RegistryAction("debloat.edge-startup-boost", "Disable Edge startup preload", "Prevents Edge startup boost from preloading browser processes at sign-in. This can free background memory, but Edge may open more slowly. Revert restores the previous policy.", OptimizationSection.Debloat, "Background Resources", OptimizationRisk.Low, true, false, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Edge", "StartupBoostEnabled", 0)));
		list.Add(TaskAction("extras.session-check", "Gaming session CPU check", "Samples accessible processes for three seconds and lists the largest CPU users. Run before gaming to identify background load. This is not an FPS benchmark and closes nothing.", OptimizationSection.Extras, "Gaming Session", OptimizationRisk.Low, admin: false, "CHECK", GamingSessionCheckAsync));
		list.Add(RegistryAction("windows.power-tweaks", "Power Tweaks", "Disables Windows power throttling for foreground workloads. Battery life and thermals may be affected.", OptimizationSection.Windows, "Power Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\Power\\PowerThrottling", "PowerThrottlingOff", 1)));
		list.Add(RegistryAction("windows.animations", "Animation + Visual Tweaks", "Turns off window animation and taskbar animation for a snappier desktop.", OptimizationSection.Windows, "Visual Tweaks", OptimizationRisk.Low, false, true, StringValue(RegistryHive.CurrentUser, "Control Panel\\Desktop\\WindowMetrics", "MinAnimate", "0"), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "TaskbarAnimations", 0)));
		list.Add(RegistryAction("windows.performance-options", "Performance Options", "Selects Windows' best-performance visual-effects preset for the current user.", OptimizationSection.Windows, "Visual Tweaks", OptimizationRisk.Low, false, true, Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects", "VisualFXSetting", 2)));
		list.Add(TaskAction("windows.clean-temp", "Clean temp all files", "Cleans user and Windows temporary folders. Locked files are skipped.", OptimizationSection.Windows, "Cleaner", OptimizationRisk.Medium, admin: true, "CLEAN", CleanTempAsync));
		list.Add(TaskAction("windows.cleaner", "Windows Cleaner", "Cleans temporary files only. Preserves compiled shaders and diagnostic reports to avoid unnecessary shader rebuilds and retain crash evidence.", OptimizationSection.Windows, "Cleaner", OptimizationRisk.Medium, admin: true, "CLEAN", CleanAllAsync));
		list.Add(Launcher("windows.bcdedit", "Boot Configuration", "Opens Microsoft System Configuration for supported boot options without applying guessed BCDEdit timer values.", OptimizationSection.Windows, "BCD-Edit", "OPEN", "msconfig.exe"));
		list.Add(Launcher("windows.sound", "Change Sound Settings", "Opens the Windows Sound control panel so you can select the correct device and format.", OptimizationSection.Windows, "Extra Tweaks", "OPEN", "mmsys.cpl"));
		list.Add(RegistryAction("windows.disable-uac", "Disable UAC", "Disables User Account Control through the documented EnableLUA policy. This weakens Windows security and requires a restart; Revert restores the exact previous value.", OptimizationSection.Windows, "Extra Tweaks", OptimizationRisk.High, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "EnableLUA", 0)));
		list.Add(RegistryAction("windows.better-alt-tab", "Better Alttab", "Uses the classic compact Alt+Tab switcher for the current user.", OptimizationSection.Windows, "Extra Tweaks", OptimizationRisk.Low, false, true, Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "AltTabSettings", 1)));
		list.Add(RegistryAction("windows.fsutil", "FSutil Tweaks", "Disables NTFS last-access timestamp updates to reduce metadata writes. Some backup tools may rely on them.", OptimizationSection.Windows, "Storage Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\FileSystem", "NtfsDisableLastAccessUpdate", 1)));
		list.Add(TaskAction("windows.optimize-drive", "Defrag Drive", "Runs Windows Optimize Drives on the system volume; Windows chooses trim for SSDs and defrag for HDDs.", OptimizationSection.Windows, "Storage Tweaks", OptimizationRisk.Medium, admin: true, "OPTIMIZE", OptimizeDriveAsync));
		list.Add(RegistryAction("windows.svc-split", "Svc Split Host", "Raises the service-host split threshold to reduce background process count. A restart is required.", OptimizationSection.Windows, "Ram Tweaks", OptimizationRisk.High, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control", "SvcHostSplitThresholdInKB", -1)));
		list.Add(RegistryAction("windows.more-ram", "More Ram Tweaks", "Keeps kernel-mode drivers resident in memory. This trades RAM use for fewer paging events and is intended for high-memory PCs.", OptimizationSection.Windows, "Ram Tweaks", OptimizationRisk.High, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management", "DisablePagingExecutive", 1)));
		list.Add(TaskAction("windows.sfc", "SFC /scannow", "Checks protected Windows system files and repairs them using the component store.", OptimizationSection.Windows, "Disc Errors", OptimizationRisk.Low, admin: true, "RUN", () => RunCommandTaskAsync("sfc.exe", "/scannow")));
		list.Add(TaskAction("windows.dism", "Restore Health", "Runs DISM component-store repair against the current Windows installation.", OptimizationSection.Windows, "Disc Errors", OptimizationRisk.Low, admin: true, "RUN", () => RunCommandTaskAsync("dism.exe", "/Online", "/Cleanup-Image", "/RestoreHealth")));
		list.Add(RegistryAction("windows.gamedvr", "GameDVR Off", "Disables background game capture while leaving Game Mode available.", OptimizationSection.Windows, "GameDVR", OptimizationRisk.Low, false, true, Dword(RegistryHive.CurrentUser, "System\\GameConfigStore", "GameDVR_Enabled", 0), Dword(RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR", "AppCaptureEnabled", 0)));
		list.Add(TaskAction("network.rss", "Enable Netadapter Processor", "Enables Receive Side Scaling on physical adapters that support it.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Low, admin: true, "ENABLE", EnableRssAsync));
		list.Add(NagleAction());
		list.Add(TaskAction("network.settings", "Change Network Settings", "Restores TCP receive auto-tuning to Normal and ECN capability to the Windows default.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Low, admin: true, "APPLY", ConfigureTcpDefaultsAsync));
		list.Add(TaskAction("network.power-saving", "Disable Power Saving", "Disables selective suspend and sleep-on-disconnect for active physical adapters. Ethernet and Wi-Fi power use may increase.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Medium, admin: true, "APPLY", DisableNetworkPowerSavingAsync));
		list.Add(RegistryAction("network.registry", "Network Registry Tweaks", "Enables RFC 1323 TCP window scaling and expands the dynamic client port range.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters", "Tcp1323Opts", 1), Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters", "MaxUserPort", 65534)));
		list.Add(TaskAction("network.powershell", "Powershell Net Tweaks", "Enables RSS and disables legacy TCP scaling heuristics using Windows networking cmdlets.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Medium, admin: true, "RUN", PowerShellNetworkAsync));
		list.Add(RegistryAction("network.limit", "Turn off limiting", "Removes MMCSS network throttling while multimedia scheduling remains active.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "NetworkThrottlingIndex", -1)));
		list.Add(RegistryAction("network.dns-priority", "DNS Priority", "Gives DNS resolution the highest Windows service-provider priority without changing your DNS servers.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\ServiceProvider", "DnsPriority", 6)));
		list.Add(TaskAction("network.reset", "Reset all network settings", "Resets Winsock and TCP/IP, then flushes the DNS resolver cache. A restart is required.", OptimizationSection.Network, "Network Optimization", OptimizationRisk.High, admin: true, "RESET", ResetNetworkAsync, restart: true));
		list.Add(ServiceAction("debloat.update-store", "Disable Microsoft Store Install Service", "Stops and disables Microsoft Store Install Service. Store app installation and updates will stop until you use Revert.", OptimizationSection.Debloat, "Process Lowering", OptimizationRisk.High, "InstallService"));
		list.Add(ServiceAction("debloat.wifi", "Disable Wifi Services (Ethernet only)", "Stops and disables WLAN AutoConfig. Use only when the PC has a working wired connection.", OptimizationSection.Debloat, "Process Lowering", OptimizationRisk.High, "WlanSvc"));
		list.Add(ServiceAction("debloat.bluetooth", "Disable Bluetooth Services", "Stops and disables the Bluetooth Support Service. Bluetooth peripherals will stop working.", OptimizationSection.Debloat, "Process Lowering", OptimizationRisk.Medium, "bthserv"));
		list.Add(ServiceAction("debloat.printer", "Disable Printer Services", "Stops and disables Print Spooler. Printing and some PDF workflows will stop working.", OptimizationSection.Debloat, "Process Lowering", OptimizationRisk.Medium, "Spooler"));
		list.Add(ServiceAction("debloat.remote", "Disable Remote Services", "Stops Remote Registry and Remote Desktop Services. Do not use this while connected remotely.", OptimizationSection.Debloat, "Process Lowering", OptimizationRisk.High, "RemoteRegistry", "TermService"));
		list.Add(Launcher("debloat.startup", "Startup Apps", "Opens Windows Startup Apps so you can disable only programs you recognize.", OptimizationSection.Debloat, "Debloat Windows", "OPEN", "ms-settings:startupapps"));
		list.Add(Launcher("debloat.uninstall", "Uninstall Apps", "Opens Installed Apps for selective, user-approved removal.", OptimizationSection.Debloat, "Debloat Windows", "OPEN", "ms-settings:appsfeatures"));
		list.Add(RegistryAction("debloat.chrome", "Debloat Chrome", "Disables Chrome background mode through enterprise policy without changing profiles or sign-in data.", OptimizationSection.Debloat, "Debloat Windows", OptimizationRisk.Low, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Policies\\Google\\Chrome", "BackgroundModeEnabled", 0)));
		list.Add(RegistryDeleteAction("debloat.discord", "Discord Debloat", "Removes Discord from the current user's automatic startup list. Discord itself is not uninstalled.", OptimizationSection.Debloat, "Application Debloat", OptimizationRisk.Low, RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Discord"));
		list.Add(RegistryDeleteAction("debloat.epic", "Epicgames Debloat", "Removes Epic Games Launcher from the current user's automatic startup list.", OptimizationSection.Debloat, "Application Debloat", OptimizationRisk.Low, RegistryHive.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "EpicGamesLauncher"));
		list.Add(Launcher("debloat.complete", "Complete Windows Debloat", "Opens Installed Apps for a selective review. Quantix never mass-removes inbox apps or dependencies.", OptimizationSection.Debloat, "Application Debloat", "REVIEW", "ms-settings:appsfeatures"));
		list.Add(TaskAction("gpu.clean-driver", "Clean Driver Installation", "Opens the official driver download page for the detected GPU vendor. Driver removal is never run silently.", OptimizationSection.Gpu, "Driver Tools", OptimizationRisk.Low, admin: false, "OPEN", OpenGpuDriverPageAsync));
		list.Add(ServiceAction("gpu.nvidia-telemetry", "Remove Nvidia Telemetry", "Stops and disables the NVIDIA Telemetry Container when that legacy service is present.", OptimizationSection.Gpu, "Nvidia GPU Tweaks", OptimizationRisk.Medium, "NvTelemetryContainer"));
		list.Add(NvidiaMsiAction());
		list.Add(Launcher("gpu.nvidia-advanced", "Advanced tweaks", "Opens NVIDIA Control Panel for supported driver-profile settings.", OptimizationSection.Gpu, "Nvidia GPU Tweaks", "OPEN", "nvcplui.exe"));
		list.Add(RegistryAction("gpu.nvidia-latency", "Hardware GPU Scheduling", "Enables Windows hardware-accelerated GPU scheduling. Unsupported drivers ignore the setting; restart Windows to apply it.", OptimizationSection.Gpu, "Nvidia GPU Tweaks", OptimizationRisk.High, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers", "HwSchMode", 2)));
		list.Add(Launcher("gpu.nvidia-power", "Power Tweaks", "Opens NVIDIA Control Panel so power mode can be set per game instead of forcing a global high-power profile.", OptimizationSection.Gpu, "Nvidia GPU Tweaks", "OPEN", "nvcplui.exe"));
		list.Add(Launcher("gpu.amd-registry", "AMD Performance Settings", "Opens AMD Software so driver-version-specific graphics, latency, and tuning options are applied through the supported vendor interface.", OptimizationSection.Gpu, "Radeon GPU Tweaks", "OPEN", "RadeonSoftware.exe"));
		list.Add(Launcher("gpu.amd-uxp", "Leave AMD User Experience Program", "Opens AMD Software where the User Experience Program preference can be changed in the supported UI.", OptimizationSection.Gpu, "Radeon GPU Tweaks", "OPEN", "RadeonSoftware.exe"));
		list.Add(TaskAction("gpu.amd-telemetry", "Disable Telemetry", "Disables AMD scheduled tasks whose names explicitly identify telemetry or customer-experience collection.", OptimizationSection.Gpu, "Radeon GPU Tweaks", OptimizationRisk.Medium, admin: true, "DISABLE", DisableAmdTelemetryTasksAsync));
		list.Add(RegistryAction("extras.priority", "Application Priority Tweaks", "Configures the MMCSS Games task for responsive Medium scheduling, priority 6, high I/O, and GPU priority.", OptimizationSection.Extras, "Game Priority Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", 8), Dword(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", 6), StringValue(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", "Medium"), StringValue(RegistryHive.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", "High")));
		list.Add(SpecificGamePickerAction());
		list.Add(GamePriorityAction("extras.fortnite", "Fortnite", "FortniteClient-Win64-Shipping.exe"));
		list.Add(GamePriorityAction("extras.valorant", "Valorant", "VALORANT-Win64-Shipping.exe"));
		list.Add(GamePriorityAction("extras.fivem", "FiveM", "FiveM.exe"));
		list.Add(RegistryAction("extras.cpu", "CPU Tweaks", "Favors short, responsive foreground scheduling quanta. Revert restores the exact prior Windows value.", OptimizationSection.Extras, "Additional Tweaks", OptimizationRisk.Medium, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\PriorityControl", "Win32PrioritySeparation", 38)));
		list.Add(RegistryAction("extras.data-queue", "Data Queue Size", "Sets keyboard and mouse class input queues to 50 entries. Very high polling-rate devices may drop input; Revert restores both previous values.", OptimizationSection.Extras, "KBM Tweaks", OptimizationRisk.High, true, true, Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\kbdclass\\Parameters", "KeyboardDataQueueSize", 50), Dword(RegistryHive.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\mouclass\\Parameters", "MouseDataQueueSize", 50)));
		list.Add(TaskAction("extras.directx", "Repair shader caches", "Troubleshooting only: clears compiled shaders. Games must rebuild them and may stutter. Do not use as routine performance optimization.", OptimizationSection.Extras, "Application & Latency", OptimizationRisk.Medium, admin: false, "CLEAN", CleanShaderCachesAsync));
		list.Add(Launcher("extras.latency-timing", "Game Mode and Latency Settings", "Opens Windows Game Mode settings for supported latency scheduling without forcing platform-specific boot timer overrides.", OptimizationSection.Extras, "Application & Latency", "OPEN", "ms-settings:gaming-gamemode"));
		list.Add(Launcher("extras.sound", "Complete Sound Optimization", "Opens Sound settings for device format, enhancements, and exclusive-mode tuning on the actual active device.", OptimizationSection.Extras, "Application & Latency", "OPEN", "ms-settings:sound"));
		return list;
	}

	private OptimizationActionDefinition RegistryAction(string id, string name, string description, OptimizationSection section, string group, OptimizationRisk risk, bool admin, bool restart, params RegistryChange[] changes)
	{
		return new OptimizationActionDefinition
		{
			Id = id,
			Name = name,
			Description = description,
			Section = section,
			Group = group,
			Risk = risk,
			Kind = OptimizationActionKind.Reversible,
			RequiresAdministrator = admin,
			RequiresRestart = restart,
			StateReader = () => Task.FromResult(ReadRegistryState(changes)),
			ExecuteAction = () => ApplyRegistryChangesAsync(id, (IReadOnlyCollection<RegistryChange>)(object)changes),
			RestoreAction = () => RestoreRegistryChangesAsync(id)
		};
	}

	private OptimizationActionDefinition RegistryDeleteAction(string id, string name, string description, OptimizationSection section, string group, OptimizationRisk risk, RegistryHive hive, string path, string valueName)
	{
		RegistryChange registryChange = new RegistryChange(hive, path, valueName, RegistryValueKind.String, null, Delete: true);
		return RegistryAction(id, name, description, section, group, risk, false, false, registryChange);
	}

	private OptimizationActionDefinition TaskAction(string id, string name, string description, OptimizationSection section, string group, OptimizationRisk risk, bool admin, string actionLabel, Func<Task<OptimizationActionResult>> execute, bool restart = false)
	{
		return new OptimizationActionDefinition
		{
			Id = id,
			Name = name,
			Description = description,
			Section = section,
			Group = group,
			Risk = risk,
			Kind = OptimizationActionKind.Task,
			RequiresAdministrator = admin,
			RequiresRestart = restart,
			ActionLabel = actionLabel,
			StateReader = () => Task.FromResult(OptimizationState.Unknown),
			ExecuteAction = execute
		};
	}

	private static OptimizationActionDefinition Launcher(string id, string name, string description, OptimizationSection section, string group, string label, string target)
	{
		return new OptimizationActionDefinition
		{
			Id = id,
			Name = name,
			Description = description,
			Section = section,
			Group = group,
			Risk = OptimizationRisk.Low,
			Kind = OptimizationActionKind.Launcher,
			ActionLabel = label,
			StateReader = () => Task.FromResult(OptimizationState.Unknown),
			ExecuteAction = () => LaunchAsync(target)
		};
	}

	private OptimizationActionDefinition ServiceAction(string id, string name, string description, OptimizationSection section, string group, OptimizationRisk risk, params string[] serviceNames)
	{
		return new OptimizationActionDefinition
		{
			Id = id,
			Name = name,
			Description = description,
			Section = section,
			Group = group,
			Risk = risk,
			Kind = OptimizationActionKind.Reversible,
			RequiresAdministrator = true,
			RequiresRestart = false,
			ActionLabel = "DISABLE",
			StateReader = () => ReadServiceStateAsync((IReadOnlyCollection<string>)(object)serviceNames),
			ExecuteAction = () => DisableServicesAsync(id, (IReadOnlyCollection<string>)(object)serviceNames),
			RestoreAction = () => RestoreServicesAsync(id)
		};
	}

	private OptimizationActionDefinition NagleAction()
	{
		return new OptimizationActionDefinition
		{
			Id = "network.nagle",
			Name = "Disable Nagles Algorithm",
			Description = "Disables Nagle coalescing and delayed ACK on active Ethernet/Wi-Fi interfaces. This may help small real-time packets but can increase packet overhead.",
			Section = OptimizationSection.Network,
			Group = "Network Optimization",
			Risk = OptimizationRisk.High,
			Kind = OptimizationActionKind.Reversible,
			RequiresAdministrator = true,
			RequiresRestart = true,
			StateReader = ReadNagleStateAsync,
			ExecuteAction = ApplyNagleAsync,
			RestoreAction = () => RestoreRegistryChangesAsync("network.nagle")
		};
	}

	private OptimizationActionDefinition PowerPlanAction()
	{
		return new OptimizationActionDefinition
		{
			Id = "windows.power-plan",
			Name = "Power Plan",
			Description = "Creates a Quantix custom gaming plan: CPU performance range 100%, PCIe link power saving off, display timeout Never (including the lock screen), and automatic sleep/hibernate Never on AC and battery. Uses more power and may increase heat and battery drain. Restoring returns to your previously active plan. FPS gains depend on hardware and game.",
			Section = OptimizationSection.Windows,
			Group = "Power Tweaks",
			Risk = OptimizationRisk.Medium,
			Kind = OptimizationActionKind.Reversible,
			ActionLabel = "ACTIVATE",
			StateReader = ReadPowerPlanStateAsync,
			ExecuteAction = ApplyPowerPlanAsync,
			RestoreAction = RestorePowerPlanAsync
		};
	}

	private OptimizationActionDefinition NvidiaMsiAction()
	{
		return new OptimizationActionDefinition
		{
			Id = "gpu.nvidia-msi",
			Name = "Enable MSI Mode",
			Description = "Enables message-signaled interrupts only for detected PCI NVIDIA display adapters. The exact prior value is recorded for Revert and Windows must restart.",
			Section = OptimizationSection.Gpu,
			Group = "Nvidia GPU Tweaks",
			Risk = OptimizationRisk.High,
			Kind = OptimizationActionKind.Reversible,
			RequiresAdministrator = true,
			RequiresRestart = true,
			ActionLabel = "ENABLE",
			StateReader = ReadNvidiaMsiStateAsync,
			ExecuteAction = ApplyNvidiaMsiAsync,
			RestoreAction = () => RestoreRegistryChangesAsync("gpu.nvidia-msi")
		};
	}

	private OptimizationActionDefinition SpecificGamePickerAction()
	{
		return new OptimizationActionDefinition
		{
			Id = "extras.specific-game",
			Name = "Priority for specific games",
			Description = "Selects a game executable and applies Windows High CPU priority through its IFEO PerfOptions entry.",
			Section = OptimizationSection.Extras,
			Group = "Game Priority Tweaks",
			Risk = OptimizationRisk.High,
			Kind = OptimizationActionKind.Reversible,
			RequiresAdministrator = true,
			ActionLabel = "SELECT GAME",
			StateReader = () => Task.FromResult((_restore.GetBackup("extras.specific-game") != null) ? OptimizationState.Applied : OptimizationState.NotApplied),
			ExecuteAction = ApplySpecificGamePriorityAsync,
			RestoreAction = () => RestoreRegistryChangesAsync("extras.specific-game")
		};
	}

	private OptimizationActionDefinition GamePriorityAction(string id, string name, string exeName)
	{
		string path = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + exeName + "\\PerfOptions";
		return RegistryAction(id, name, "Sets Windows High CPU priority whenever " + exeName + " starts. It does not modify game files.", OptimizationSection.Extras, "Game Priority Tweaks", OptimizationRisk.High, true, false, Dword(RegistryHive.LocalMachine, path, "CpuPriorityClass", 3));
	}

	private static RegistryChange Dword(RegistryHive hive, string path, string name, int value)
	{
		return new RegistryChange(hive, path, name, RegistryValueKind.DWord, value, Delete: false);
	}

	private static RegistryChange StringValue(RegistryHive hive, string path, string name, string value)
	{
		return new RegistryChange(hive, path, name, RegistryValueKind.String, value, Delete: false);
	}

	private OptimizationState ReadRegistryState(IEnumerable<RegistryChange> changes)
	{
		try
		{
			foreach (RegistryChange change in changes)
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(change.Hive, RegistryView.Registry64);
				using RegistryKey registryKey2 = registryKey.OpenSubKey(change.Path, writable: false);
				object obj = registryKey2?.GetValue(change.Name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
				if (change.Delete)
				{
					if (obj != null)
					{
						return OptimizationState.NotApplied;
					}
				}
				else if (!RegistryValuesEqual(obj, change.Value, change.Kind))
				{
					return OptimizationState.NotApplied;
				}
			}
			return OptimizationState.Applied;
		}
		catch
		{
			return OptimizationState.Unknown;
		}
	}

	private async Task<OptimizationActionResult> ApplyRegistryChangesAsync(string id, IReadOnlyCollection<RegistryChange> changes)
	{
		return await Task.Run(delegate
		{
			if (_restore.GetBackup(id) == null)
			{
				List<RegistrySnapshot> value = changes.Select(CaptureRegistryValue).ToList();
				_restore.SaveBackup(id, JsonSerializer.Serialize(value));
			}
			foreach (RegistryChange change in changes)
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(change.Hive, RegistryView.Registry64);
				using RegistryKey registryKey2 = registryKey.CreateSubKey(change.Path, writable: true) ?? throw new InvalidOperationException("Cannot open registry path " + change.Path + ".");
				if (change.Delete)
				{
					registryKey2.DeleteValue(change.Name, throwOnMissingValue: false);
				}
				else
				{
					registryKey2.SetValue(change.Name, change.Value, change.Kind);
				}
			}
			return OptimizationActionResult.Ok("Applied. The previous Windows values were recorded for Revert.");
		});
	}

	private async Task<OptimizationActionResult> RestoreRegistryChangesAsync(string id)
	{
		return await Task.Run(delegate
		{
			string backup = _restore.GetBackup(id);
			if (backup == null)
			{
				return OptimizationActionResult.Fail("No Quantix backup exists for this action.");
			}
			List<RegistrySnapshot> list = JsonSerializer.Deserialize<List<RegistrySnapshot>>(backup);
			if (list == null)
			{
				return OptimizationActionResult.Fail("The recorded backup is invalid.");
			}
			foreach (RegistrySnapshot item in list)
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(item.Hive, RegistryView.Registry64);
				using RegistryKey registryKey2 = registryKey.CreateSubKey(item.Path, writable: true) ?? throw new InvalidOperationException("Cannot open registry path " + item.Path + ".");
				if (!item.Existed)
				{
					registryKey2.DeleteValue(item.Name, throwOnMissingValue: false);
				}
				else
				{
					object value = item.Kind switch
					{
						RegistryValueKind.DWord => int.Parse(item.Value), 
						RegistryValueKind.QWord => long.Parse(item.Value), 
						_ => item.Value, 
					};
					registryKey2.SetValue(item.Name, value, item.Kind);
				}
			}
			_restore.ClearBackup(id);
			return OptimizationActionResult.Ok("Restored the exact values recorded before Quantix changed them.");
		});
	}

	private static RegistrySnapshot CaptureRegistryValue(RegistryChange change)
	{
		using RegistryKey registryKey = RegistryKey.OpenBaseKey(change.Hive, RegistryView.Registry64);
		using RegistryKey registryKey2 = registryKey.OpenSubKey(change.Path, writable: false);
		object obj = registryKey2?.GetValue(change.Name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
		bool flag = obj != null;
		RegistryValueKind kind = (flag ? registryKey2.GetValueKind(change.Name) : change.Kind);
		return new RegistrySnapshot(change.Hive, change.Path, change.Name, flag, kind, flag ? (Convert.ToString(obj, CultureInfo.InvariantCulture) ?? string.Empty) : "__QUANTIX_MISSING__");
	}

	private static bool RegistryValuesEqual(object? current, object? desired, RegistryValueKind kind)
	{
		if (current == null || desired == null)
		{
			if (current == null)
			{
				return desired == null;
			}
			return false;
		}
		return kind switch
		{
			RegistryValueKind.DWord => Convert.ToInt64(current) == Convert.ToInt64(desired), 
			RegistryValueKind.QWord => Convert.ToInt64(current) == Convert.ToInt64(desired), 
			_ => string.Equals(Convert.ToString(current), Convert.ToString(desired), StringComparison.Ordinal), 
		};
	}

	private async Task<OptimizationState> ReadServiceStateAsync(IReadOnlyCollection<string> serviceNames)
	{
		return await Task.Run(delegate
		{
			bool flag = false;
			foreach (string serviceName in serviceNames)
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + serviceName);
				if (registryKey != null)
				{
					flag = true;
					if (Convert.ToInt32(registryKey.GetValue("Start", 3)) != 4)
					{
						return OptimizationState.NotApplied;
					}
				}
			}
			return flag ? OptimizationState.Applied : OptimizationState.Unsupported;
		});
	}

	private async Task<OptimizationActionResult> DisableServicesAsync(string id, IReadOnlyCollection<string> serviceNames)
	{
		return await Task.Run(delegate
		{
			List<ServiceSnapshot> list = new List<ServiceSnapshot>();
			foreach (string serviceName in serviceNames)
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + serviceName, writable: false);
				if (registryKey != null)
				{
					bool wasRunning = false;
					try
					{
						using ServiceController serviceController = new ServiceController(serviceName);
						wasRunning = serviceController.Status == ServiceControllerStatus.Running;
					}
					catch
					{
					}
					list.Add(new ServiceSnapshot(serviceName, Convert.ToInt32(registryKey.GetValue("Start", 3)), wasRunning));
				}
			}
			if (list.Count == 0)
			{
				return OptimizationActionResult.Fail("The matching Windows or vendor service is not installed on this PC.");
			}
			if (_restore.GetBackup(id) == null)
			{
				_restore.SaveBackup(id, JsonSerializer.Serialize(list));
			}
			foreach (ServiceSnapshot item in list)
			{
				try
				{
					using ServiceController serviceController2 = new ServiceController(item.Name);
					ServiceControllerStatus status = serviceController2.Status;
					if (status != ServiceControllerStatus.Stopped && status != ServiceControllerStatus.StopPending)
					{
						serviceController2.Stop();
						serviceController2.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15.0));
					}
				}
				catch
				{
				}
				using RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + item.Name, writable: true);
				registryKey2?.SetValue("Start", 4, RegistryValueKind.DWord);
			}
			return OptimizationActionResult.Ok("Matching services were stopped and disabled. Revert restores their recorded startup modes.");
		});
	}

	private async Task<OptimizationActionResult> RestoreServicesAsync(string id)
	{
		return await Task.Run(delegate
		{
			string backup = _restore.GetBackup(id);
			List<ServiceSnapshot> list = ((backup == null) ? null : JsonSerializer.Deserialize<List<ServiceSnapshot>>(backup));
			if (list == null)
			{
				return OptimizationActionResult.Fail("No valid service backup exists.");
			}
			foreach (ServiceSnapshot item in list)
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + item.Name, writable: true))
				{
					registryKey?.SetValue("Start", item.StartValue, RegistryValueKind.DWord);
				}
				if (item.WasRunning && item.StartValue != 4)
				{
					try
					{
						using ServiceController serviceController = new ServiceController(item.Name);
						serviceController.Start();
						serviceController.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(15.0));
					}
					catch
					{
					}
				}
			}
			_restore.ClearBackup(id);
			return OptimizationActionResult.Ok("Service startup modes and running state were restored.");
		});
	}

	private Task<OptimizationState> ReadNagleStateAsync()
	{
		List<RegistryChange> nagleChanges = GetNagleChanges();
		return Task.FromResult((nagleChanges.Count == 0) ? OptimizationState.Unsupported : ReadRegistryState(nagleChanges));
	}

	private Task<OptimizationActionResult> ApplyNagleAsync()
	{
		List<RegistryChange> nagleChanges = GetNagleChanges();
		if (nagleChanges.Count == 0)
		{
			return Task.FromResult(OptimizationActionResult.Fail("No active Ethernet or Wi-Fi interface was found."));
		}
		return ApplyRegistryChangesAsync("network.nagle", nagleChanges);
	}

	private Task<OptimizationState> ReadNvidiaMsiStateAsync()
	{
		List<RegistryChange> nvidiaMsiChanges = GetNvidiaMsiChanges();
		return Task.FromResult((nvidiaMsiChanges.Count == 0) ? OptimizationState.Unsupported : ReadRegistryState(nvidiaMsiChanges));
	}

	private Task<OptimizationActionResult> ApplyNvidiaMsiAsync()
	{
		List<RegistryChange> nvidiaMsiChanges = GetNvidiaMsiChanges();
		if (nvidiaMsiChanges.Count == 0)
		{
			return Task.FromResult(OptimizationActionResult.Fail("No PCI NVIDIA display adapter was detected on this PC."));
		}
		return ApplyRegistryChangesAsync("gpu.nvidia-msi", nvidiaMsiChanges);
	}

	private static List<RegistryChange> GetNvidiaMsiChanges()
	{
		List<RegistryChange> list = new List<RegistryChange>();
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT Name, PNPDeviceID FROM Win32_VideoController");
			foreach (ManagementObject item in managementObjectSearcher.Get().Cast<ManagementObject>())
			{
				string text = item["Name"]?.ToString() ?? string.Empty;
				string text2 = item["PNPDeviceID"]?.ToString() ?? string.Empty;
				if (text.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase) && text2.StartsWith("PCI\\", StringComparison.OrdinalIgnoreCase))
				{
					string path = "SYSTEM\\CurrentControlSet\\Enum\\" + text2 + "\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties";
					list.Add(Dword(RegistryHive.LocalMachine, path, "MSISupported", 1));
				}
			}
		}
		catch
		{
		}
		return list.DistinctBy<RegistryChange, string>((RegistryChange change) => change.Path, StringComparer.OrdinalIgnoreCase).ToList();
	}

	private static List<RegistryChange> GetNagleChanges()
	{
		List<RegistryChange> list = new List<RegistryChange>();
		foreach (NetworkInterface item in NetworkInterface.GetAllNetworkInterfaces().Where(delegate(NetworkInterface adapter)
		{
			bool flag = adapter.OperationalStatus == OperationalStatus.Up;
			if (flag)
			{
				NetworkInterfaceType networkInterfaceType = adapter.NetworkInterfaceType;
				flag = ((networkInterfaceType == NetworkInterfaceType.Ethernet || networkInterfaceType == NetworkInterfaceType.Wireless80211) ? true : false);
			}
			return flag;
		}))
		{
			string path = "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\" + item.Id;
			list.Add(Dword(RegistryHive.LocalMachine, path, "TCPNoDelay", 1));
			list.Add(Dword(RegistryHive.LocalMachine, path, "TcpAckFrequency", 1));
		}
		return list;
	}

	private async Task<OptimizationState> ReadPowerPlanStateAsync()
	{
		return (await RunProcessAsync("powercfg.exe", "/getactivescheme")).Output.Contains("Quantix Pro", StringComparison.OrdinalIgnoreCase) ? OptimizationState.Applied : OptimizationState.NotApplied;
	}

	private async Task<OptimizationActionResult> ApplyPowerPlanAsync()
	{
		string text = ExtractGuid((await RunProcessAsync("powercfg.exe", "/getactivescheme")).Output);
		if (text == null)
		{
			return OptimizationActionResult.Fail("Could not read the active Windows power plan.");
		}
		if (_restore.GetBackup("windows.power-plan") == null)
		{
			_restore.SaveBackup("windows.power-plan", text);
		}
		string text2 = (await RunProcessAsync("powercfg.exe", "/list")).Output.Split('\n').FirstOrDefault((string line) => line.Contains("Quantix Pro", StringComparison.OrdinalIgnoreCase));
		string targetGuid = ExtractGuid(text2 ?? string.Empty);
		if (targetGuid == null)
		{
			targetGuid = ExtractGuid((await RunProcessAsync("powercfg.exe", "/duplicatescheme", "SCHEME_BALANCED")).Output);
			if (targetGuid == null)
			{
				return OptimizationActionResult.Fail("Windows could not create the Quantix Pro power plan.");
			}
			await RunProcessAsync("powercfg.exe", "/changename", targetGuid, "Quantix Pro");
		}
		if (!(await QuantixPowerSettings.ConfigureAsync(targetGuid, async (string command) => (await RunProcessAsync("powercfg.exe", command.Split(' '))).ExitCode == 0)))
		{
			return OptimizationActionResult.Fail("Windows rejected a custom power setting. The plan was not activated; use Revert if it was already active.");
		}
		ProcessResult processResult = await RunProcessAsync("powercfg.exe", "/setactive", targetGuid);
		return (processResult.ExitCode == 0) ? OptimizationActionResult.Ok("Quantix Pro custom gaming plan is active. Display, automatic sleep and hibernate timeouts are Never on AC and battery.") : OptimizationActionResult.Fail(processResult.Output);
	}

	private async Task<OptimizationActionResult> RestorePowerPlanAsync()
	{
		string backup = _restore.GetBackup("windows.power-plan");
		if (string.IsNullOrWhiteSpace(backup))
		{
			return OptimizationActionResult.Fail("No previous power plan was recorded.");
		}
		ProcessResult processResult = await RunProcessAsync("powercfg.exe", "/setactive", backup);
		if (processResult.ExitCode != 0)
		{
			return OptimizationActionResult.Fail(processResult.Output);
		}
		_restore.ClearBackup("windows.power-plan");
		return OptimizationActionResult.Ok("The previously active Windows power plan was restored.");
	}

	private async Task<OptimizationActionResult> ApplySpecificGamePriorityAsync()
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Title = "Choose a game executable",
			Filter = "Applications (*.exe)|*.exe",
			CheckFileExists = true,
			Multiselect = false
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return OptimizationActionResult.Fail("No game executable was selected.");
		}
		string fileName = Path.GetFileName(openFileDialog.FileName);
		string path = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + fileName + "\\PerfOptions";
		return await ApplyRegistryChangesAsync("extras.specific-game", (IReadOnlyCollection<RegistryChange>)(object)new RegistryChange[1] { Dword(RegistryHive.LocalMachine, path, "CpuPriorityClass", 3) });
	}

	private async Task<OptimizationActionResult> CleanTempAsync()
	{
		CleanupActionResult cleanupActionResult = await _cleanup.CleanAsync(new string[2] { "user-temp", "windows-temp" });
		return cleanupActionResult.Success ? OptimizationActionResult.Ok(cleanupActionResult.Message) : OptimizationActionResult.Fail(cleanupActionResult.Message);
	}

	private static async Task<OptimizationActionResult> GamingSessionCheckAsync()
	{
		Dictionary<int, (string Name, long Started, double Cpu)> before = new Dictionary<int, (string, long, double)>();
		Process[] processes = Process.GetProcesses();
		foreach (Process process in processes)
		{
			using (process)
			{
				try
				{
					before[process.Id] = (process.ProcessName, process.StartTime.Ticks, process.TotalProcessorTime.TotalSeconds);
				}
				catch
				{
				}
			}
		}
		Stopwatch timer = Stopwatch.StartNew();
		await Task.Delay(3000);
		double totalSeconds = timer.Elapsed.TotalSeconds;
		List<(string, int, double)> list = new List<(string, int, double)>();
		processes = Process.GetProcesses();
		foreach (Process process2 in processes)
		{
			using (process2)
			{
				try
				{
					if (before.TryGetValue(process2.Id, out (string, long, double) value) && value.Item2 == process2.StartTime.Ticks)
					{
						list.Add((process2.ProcessName, process2.Id, Math.Clamp(100.0 * (process2.TotalProcessorTime.TotalSeconds - value.Item3) / totalSeconds / (double)Environment.ProcessorCount, 0.0, 100.0)));
					}
				}
				catch
				{
				}
			}
		}
		MessageBox.Show("CPU snapshot (accessible processes only; not an FPS benchmark)\n\n" + string.Join("\n", from r in list.OrderByDescending<(string, int, double), double>(((string Name, int Id, double Cpu) r) => r.Cpu).Take(10)
			select $"{r.Item1} (PID {r.Item2}): {r.Item3:F1}%") + "\n\nClose only apps you recognize and do not need. Leave game, anti-cheat, security and system processes running. Compare the same game scene before and after changes.", "Quantix Pro - Gaming session", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		return OptimizationActionResult.Ok("CPU snapshot complete. No processes or settings were changed.");
	}

	private async Task<OptimizationActionResult> CleanAllAsync()
	{
		string[] targetIds = new string[2] { "user-temp", "windows-temp" };
		CleanupActionResult cleanupActionResult = await _cleanup.CleanAsync(targetIds);
		return cleanupActionResult.Success ? OptimizationActionResult.Ok(cleanupActionResult.Message) : OptimizationActionResult.Fail(cleanupActionResult.Message);
	}

	private async Task<OptimizationActionResult> CleanShaderCachesAsync()
	{
		CleanupActionResult cleanupActionResult = await _cleanup.CleanAsync(new string[2] { "directx-shader-cache", "gpu-shader-caches" });
		return cleanupActionResult.Success ? OptimizationActionResult.Ok(cleanupActionResult.Message) : OptimizationActionResult.Fail(cleanupActionResult.Message);
	}

	private static async Task<OptimizationActionResult> OptimizeDriveAsync()
	{
		string text = Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";
		return await RunCommandTaskAsync("defrag.exe", text, "/O", "/U", "/V");
	}

	private static async Task<OptimizationActionResult> EnableRssAsync()
	{
		return await RunPowerShellTaskAsync("Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Enable-NetAdapterRss -Confirm:$false");
	}

	private static async Task<OptimizationActionResult> ConfigureTcpDefaultsAsync()
	{
		ProcessResult processResult = await RunProcessAsync("netsh.exe", "int", "tcp", "set", "global", "autotuninglevel=normal");
		if (processResult.ExitCode != 0)
		{
			return OptimizationActionResult.Fail(processResult.Output);
		}
		ProcessResult processResult2 = await RunProcessAsync("netsh.exe", "int", "tcp", "set", "global", "ecncapability=default");
		return (processResult2.ExitCode == 0) ? OptimizationActionResult.Ok("Windows TCP defaults were applied.") : OptimizationActionResult.Fail(processResult2.Output);
	}

	private static async Task<OptimizationActionResult> DisableNetworkPowerSavingAsync()
	{
		return await RunPowerShellTaskAsync("$names=(Get-NetAdapter -Physical | Where-Object Status -eq 'Up').Name; foreach($name in $names){Set-NetAdapterPowerManagement -Name $name -SelectiveSuspend Disabled -DeviceSleepOnDisconnect Disabled -NoRestart -ErrorAction Continue}; Write-Output ('Processed: ' + ($names -join ', '))");
	}

	private static async Task<OptimizationActionResult> PowerShellNetworkAsync()
	{
		return await RunPowerShellTaskAsync("Get-NetAdapter -Physical | Enable-NetAdapterRss -Confirm:$false; Set-NetTCPSetting -SettingName InternetCustom -ScalingHeuristics Disabled -AutoTuningLevelLocal Normal");
	}

	private static async Task<OptimizationActionResult> ResetNetworkAsync()
	{
		string[][] array = new string[2][]
		{
			new string[2] { "winsock", "reset" },
			new string[3] { "int", "ip", "reset" }
		};
		string[][] array2 = array;
		foreach (string[] arguments in array2)
		{
			ProcessResult processResult = await RunProcessAsync("netsh.exe", arguments);
			if (processResult.ExitCode != 0)
			{
				return OptimizationActionResult.Fail(processResult.Output);
			}
		}
		ProcessResult processResult2 = await RunProcessAsync("ipconfig.exe", "/flushdns");
		return (processResult2.ExitCode == 0) ? OptimizationActionResult.Ok("Network stack reset completed. Restart Windows before testing the connection.") : OptimizationActionResult.Fail(processResult2.Output);
	}

	private static Task<OptimizationActionResult> OpenGpuDriverPageAsync()
	{
		List<string> list = new List<string>();
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT Name FROM Win32_VideoController");
			foreach (ManagementBaseObject item in managementObjectSearcher.Get())
			{
				list.Add(item["Name"]?.ToString() ?? string.Empty);
			}
		}
		catch
		{
		}
		return LaunchAsync(list.Any((string name) => name.Contains("AMD", StringComparison.OrdinalIgnoreCase) || name.Contains("Radeon", StringComparison.OrdinalIgnoreCase)) ? "https://www.amd.com/en/support/download/drivers.html" : "https://www.nvidia.com/Download/index.aspx");
	}

	private static async Task<OptimizationActionResult> DisableAmdTelemetryTasksAsync()
	{
		return await RunPowerShellTaskAsync("$tasks=Get-ScheduledTask | Where-Object {$_.TaskName -match 'AMD' -and $_.TaskName -match 'Telemetry|Customer|Experience'}; if(!$tasks){Write-Output 'No explicitly named AMD telemetry tasks were found.'} else {$tasks | Disable-ScheduledTask | Out-Null; $tasks.TaskName}");
	}

	private static async Task<OptimizationActionResult> RunCommandTaskAsync(string fileName, params string[] arguments)
	{
		ProcessResult processResult = await RunProcessAsync(fileName, arguments);
		string message = (string.IsNullOrWhiteSpace(processResult.Output) ? $"{fileName} finished with exit code {processResult.ExitCode}." : LastLines(processResult.Output));
		return (processResult.ExitCode == 0) ? OptimizationActionResult.Ok(message) : OptimizationActionResult.Fail(message);
	}

	private static async Task<OptimizationActionResult> RunPowerShellTaskAsync(string command)
	{
		ProcessResult processResult = await RunProcessAsync("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command);
		string message = (string.IsNullOrWhiteSpace(processResult.Output) ? $"PowerShell finished with exit code {processResult.ExitCode}." : LastLines(processResult.Output));
		return (processResult.ExitCode == 0) ? OptimizationActionResult.Ok(message) : OptimizationActionResult.Fail(message);
	}

	private static Task<OptimizationActionResult> LaunchAsync(string target)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = target,
				UseShellExecute = true
			});
			return Task.FromResult(OptimizationActionResult.Ok("Opened the supported Windows or vendor interface."));
		}
		catch (Exception ex)
		{
			return Task.FromResult(OptimizationActionResult.Fail("Could not open " + target + ": " + ex.Message));
		}
	}

	private static async Task<ProcessResult> RunProcessAsync(string fileName, params string[] arguments)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo
		{
			FileName = fileName,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true
		};
		foreach (string item in arguments)
		{
			processStartInfo.ArgumentList.Add(item);
		}
		using Process process = Process.Start(processStartInfo) ?? throw new InvalidOperationException("Could not start " + fileName + ".");
		Task<string> standardOutput = process.StandardOutput.ReadToEndAsync();
		Task<string> standardError = process.StandardError.ReadToEndAsync();
		await process.WaitForExitAsync();
		string text = await standardOutput;
		string newLine = Environment.NewLine;
		string text2 = text;
		string text3 = newLine;
		string text4 = text2 + text3 + await standardError;
		return new ProcessResult(process.ExitCode, text4.Trim());
	}

	private static string? ExtractGuid(string input)
	{
		Match match = Regex.Match(input, "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
		if (!match.Success)
		{
			return null;
		}
		return match.Value;
	}

	private static string LastLines(string text)
	{
		string[] source = text.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
		return string.Join(" ", source.TakeLast(3)).Trim();
	}
}

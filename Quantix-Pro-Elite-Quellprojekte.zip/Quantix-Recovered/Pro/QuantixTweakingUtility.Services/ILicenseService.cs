using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public interface ILicenseService
{
	string HardwareId { get; }

	string LicenseFilePath { get; }

	LicenseValidation ValidateStoredLicense();

	LicenseValidation ValidateLicense(string licenseKey);

	LicenseValidation ActivateLicense(string licenseKey);

	void RemoveStoredLicense(string suffix);
}

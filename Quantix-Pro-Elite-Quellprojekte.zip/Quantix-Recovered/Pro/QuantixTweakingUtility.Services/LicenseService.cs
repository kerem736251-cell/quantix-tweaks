using System;
using System.IO;
using System.Reflection;
using QuantixLicensing;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public sealed class LicenseService : ILicenseService
{
	private readonly ILoggingService _logging;

	private readonly string _publicKey;

	public string HardwareId { get; } = HardwareFingerprint.FormatHash(HardwareFingerprint.GetCurrentHash());

	public string LicenseFilePath { get; } = ActivationStore.PathFor("quantix-pro");

	public LicenseService(ILoggingService logging)
	{
		_logging = logging;
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("QuantixTweakingUtility.LicensePublicKey") ?? throw new InvalidOperationException("License verifier is missing.");
		using StreamReader streamReader = new StreamReader(stream);
		_publicKey = streamReader.ReadToEnd();
	}

	public LicenseValidation ValidateStoredLicense()
	{
		try
		{
			return ValidateLicense(ActivationStore.Read(LicenseFilePath) ?? "");
		}
		catch (Exception ex)
		{
			_logging.Error("License", "Could not read saved activation.", ex);
			return LicenseValidation.Invalid("The saved activation could not be read.");
		}
	}

	public LicenseValidation ValidateLicense(string licenseKey)
	{
		LicenseValidationResult licenseValidationResult = LicenseToken.Validate(licenseKey, _publicKey, HardwareId, null, "quantix-pro");
		if (!licenseValidationResult.IsValid)
		{
			return LicenseValidation.Invalid(licenseValidationResult.Message);
		}
		return LicenseValidation.Valid(licenseValidationResult.License.Customer, licenseValidationResult.License.LicenseId, licenseValidationResult.License.ExpiresAtUtc);
	}

	public LicenseValidation ActivateLicense(string licenseKey)
	{
		LicenseValidation licenseValidation = ValidateLicense(licenseKey);
		if (!licenseValidation.IsValid)
		{
			return licenseValidation;
		}
		try
		{
			ActivationStore.Save(LicenseFilePath, licenseKey);
			_logging.Info("License", "Saved activation " + licenseValidation.LicenseId);
			return licenseValidation;
		}
		catch (Exception ex)
		{
			_logging.Error("License", "Could not save activation.", ex);
			return LicenseValidation.Invalid("The key is valid, but could not be saved. Check folder access and try again.");
		}
	}

	public void RemoveStoredLicense(string suffix)
	{
		if (File.Exists(LicenseFilePath))
		{
			File.Move(LicenseFilePath, LicenseFilePath + "." + DateTime.UtcNow.Ticks + ".disabled");
		}
	}
}

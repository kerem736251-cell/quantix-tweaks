using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Security.Principal;
using System.Threading.Tasks;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public static class AdminHelper
{
	public static bool IsRunningAsAdministrator()
	{
		using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
		return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
	}

	public static async Task<OptimizationActionResult> RunElevatedActionAsync(string actionId, bool restore = false)
	{
		try
		{
			string processPath = Environment.ProcessPath;
			if (string.IsNullOrWhiteSpace(processPath))
			{
				return OptimizationActionResult.Fail("Quantix could not locate its executable for elevation.");
			}
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				FileName = processPath,
				UseShellExecute = true,
				Verb = "runas"
			};
			processStartInfo.ArgumentList.Add(restore ? "--restore-action" : "--execute-action");
			processStartInfo.ArgumentList.Add(actionId);
			using Process process = Process.Start(processStartInfo);
			if (process == null)
			{
				return OptimizationActionResult.Fail("Windows did not start the elevated Quantix helper.");
			}
			await process.WaitForExitAsync();
			return (process.ExitCode == 0) ? OptimizationActionResult.Ok("The elevated action completed. State refreshed.") : OptimizationActionResult.Fail("The elevated action did not complete. Review the message from the administrator window.");
		}
		catch (Win32Exception ex) when (ex.NativeErrorCode == 1223)
		{
			return OptimizationActionResult.Fail("Administrator approval was cancelled.");
		}
		catch (Exception ex2)
		{
			return OptimizationActionResult.Fail("Could not start the elevated action: " + ex2.Message);
		}
	}
}

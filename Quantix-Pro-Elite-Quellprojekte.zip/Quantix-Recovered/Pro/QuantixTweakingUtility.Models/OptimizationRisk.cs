namespace QuantixTweakingUtility.Models;

public enum OptimizationRisk
{
	Low,
	Medium,
	High
}

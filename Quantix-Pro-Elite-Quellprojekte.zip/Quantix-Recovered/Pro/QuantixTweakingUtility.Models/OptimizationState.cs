namespace QuantixTweakingUtility.Models;

public enum OptimizationState
{
	Unknown,
	Applied,
	NotApplied,
	Unsupported
}

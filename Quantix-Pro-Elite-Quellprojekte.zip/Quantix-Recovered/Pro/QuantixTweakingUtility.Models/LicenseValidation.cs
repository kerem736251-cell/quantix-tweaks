using System;

namespace QuantixTweakingUtility.Models;

public sealed class LicenseValidation
{
	public bool IsValid { get; set; }

	public string Message { get; set; } = string.Empty;

	public string Customer { get; set; } = string.Empty;

	public string LicenseId { get; set; } = string.Empty;

	public DateTimeOffset? ExpiresAt { get; set; }

	public static LicenseValidation Valid(string customer, string licenseId, DateTimeOffset? expiresAt)
	{
		return new LicenseValidation
		{
			IsValid = true,
			Message = (expiresAt.HasValue ? $"Activated for {customer}. Expires {expiresAt.Value.LocalDateTime:d}." : ("Activated for " + customer + ". Perpetual license.")),
			Customer = customer,
			LicenseId = licenseId,
			ExpiresAt = expiresAt
		};
	}

	public static LicenseValidation Invalid(string message)
	{
		return new LicenseValidation
		{
			Message = message
		};
	}
}

namespace QuantixTweakingUtility.Models;

public enum OptimizationSection
{
	Windows,
	Network,
	Debloat,
	Gpu,
	Extras
}

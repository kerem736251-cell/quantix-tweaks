namespace QuantixTweakingUtility.Models;

public sealed class OptimizationActionResult
{
	public bool Success { get; set; }

	public string Message { get; set; } = string.Empty;

	public static OptimizationActionResult Ok(string message = "Completed.")
	{
		return new OptimizationActionResult
		{
			Success = true,
			Message = message
		};
	}

	public static OptimizationActionResult Fail(string message)
	{
		return new OptimizationActionResult
		{
			Success = false,
			Message = message
		};
	}
}

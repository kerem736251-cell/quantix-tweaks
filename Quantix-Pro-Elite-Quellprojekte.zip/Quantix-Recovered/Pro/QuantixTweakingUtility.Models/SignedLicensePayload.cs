using System.Text.Json.Serialization;

namespace QuantixTweakingUtility.Models;

internal sealed class SignedLicensePayload
{
	[JsonPropertyName("v")]
	public int Version { get; set; }

	[JsonPropertyName("p")]
	public string Product { get; set; } = string.Empty;

	[JsonPropertyName("id")]
	public string LicenseId { get; set; } = string.Empty;

	[JsonPropertyName("customer")]
	public string Customer { get; set; } = string.Empty;

	[JsonPropertyName("iat")]
	public long IssuedAtUnix { get; set; }

	[JsonPropertyName("exp")]
	public long? ExpiresAtUnix { get; set; }

	[JsonPropertyName("hw")]
	public string HardwareId { get; set; } = string.Empty;
}

namespace QuantixTweakingUtility.Models;

public enum OptimizationActionKind
{
	Reversible,
	Task,
	Launcher
}

namespace QuantixTweakingUtility.Models;

public sealed class CleanupScanResult
{
	public CleanupTarget Target { get; set; }

	public long ReclaimableBytes { get; set; }

	public string Status { get; set; } = "Ready";
}

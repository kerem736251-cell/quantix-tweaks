namespace QuantixTweakingUtility.Models;

public sealed class CleanupActionResult
{
	public bool Success { get; set; }

	public long ReclaimedBytes { get; set; }

	public string Message { get; set; } = string.Empty;
}

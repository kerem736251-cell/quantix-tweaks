using System;
using System.Threading.Tasks;

namespace QuantixTweakingUtility.Models;

public sealed class OptimizationActionDefinition
{
	public string Id { get; set; }

	public string Name { get; set; }

	public string Description { get; set; }

	public OptimizationSection Section { get; set; }

	public string Group { get; set; }

	public OptimizationRisk Risk { get; set; }

	public OptimizationActionKind Kind { get; set; }

	public bool RequiresAdministrator { get; set; }

	public bool RequiresRestart { get; set; }

	public bool RestoreOnly { get; set; }

	public string ActionLabel { get; set; } = "APPLY";

	public string RestoreLabel { get; set; } = "REVERT";

	public bool CanRestore => Kind == OptimizationActionKind.Reversible;

	public Func<Task<OptimizationState>> StateReader { get; set; }

	public Func<Task<OptimizationActionResult>> ExecuteAction { get; set; }

	public Func<Task<OptimizationActionResult>>? RestoreAction { get; set; }
}

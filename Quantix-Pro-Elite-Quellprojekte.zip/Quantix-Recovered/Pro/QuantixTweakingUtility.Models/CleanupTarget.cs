using System;
using System.Collections.Generic;

namespace QuantixTweakingUtility.Models;

public sealed class CleanupTarget
{
	public string Id { get; set; }

	public string Name { get; set; }

	public string Description { get; set; }

	public IReadOnlyList<string> Paths { get; set; } = Array.Empty<string>();

	public bool IsCleanable { get; set; }

	public string UnavailableReason { get; set; } = string.Empty;
}

using System;
using System.Collections.Generic;
using System.Linq;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public static class TweakTabCatalog
{
	private static readonly (string Key, string Title, string Description)[] TabDefinitions = new(string, string, string)[10]
	{
		("basic", "Basic", "Broad Windows gaming, update, responsiveness, background, and maintenance controls."),
		("privacy", "Privacy", "Telemetry, advertising, input personalization, content, search, and app-permission controls."),
		("power", "Power", "CPU, hibernation, timer, and device power behavior. Desktop-oriented settings are clearly marked."),
		("gpu", "GPU", "Quantix graphics controls: Windows scheduling, NVIDIA profiles, and AMD Radeon driver settings."),
		("precision", "Precision", "Mouse consistency and pointer controls. These change Windows pointer behavior; games using raw input handle aiming separately. Keep your in-game sensitivity consistent."),
		("network", "Network", "TCP, DNS, adapter, delivery, and legacy protocol controls for a cleaner network stack."),
		("advanced", "Advanced", "Memory management, scheduling, storage, services, and advanced input behavior."),
		("mitigations", "Mitigations", "Optional high-risk security and virtualization controls. Nothing here is applied automatically."),
		("services", "Services", "Reversible service-stack groups for hardware or Windows features you do not use."),
		("appearance", "Appearance", "Windows visual behavior, File Explorer namespaces, and context-menu preferences.")
	};

	public static IReadOnlyDictionary<string, TweakTabViewModel> Build(ITweakService tweakService)
	{
		Dictionary<string, TweakTabViewModel> dictionary = TabDefinitions.ToDictionary<(string, string, string), string, TweakTabViewModel>(((string Key, string Title, string Description) definition) => definition.Key, delegate((string Key, string Title, string Description) definition)
		{
			TweakTabViewModel tweakTabViewModel = new TweakTabViewModel();
			(tweakTabViewModel.Key, tweakTabViewModel.Title, tweakTabViewModel.Description) = definition;
			return tweakTabViewModel;
		}, StringComparer.OrdinalIgnoreCase);
		Dictionary<string, Dictionary<string, TweakGroupViewModel>> dictionary2 = dictionary.Keys.ToDictionary<string, string, Dictionary<string, TweakGroupViewModel>>((string key) => key, (string _) => new Dictionary<string, TweakGroupViewModel>(StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
		foreach (TweakDefinition allTweak in tweakService.GetAllTweaks())
		{
			if(allTweak.Category==TweakCategory.Gpu && allTweak.RestoreOnly)continue;
			(string, string) tuple = ResolvePlacement(allTweak);
			Dictionary<string, TweakGroupViewModel> dictionary3 = dictionary2[tuple.Item1];
			if (!dictionary3.TryGetValue(tuple.Item2, out var value))
			{
				value = new TweakGroupViewModel
				{
					Name = tuple.Item2
				};
				dictionary3[tuple.Item2] = value;
				dictionary[tuple.Item1].Groups.Add(value);
			}
			value.Rows.Add(new TweakRowViewModel(allTweak, tweakService));
		}
		List<string> list = (from row in dictionary.Values.SelectMany((TweakTabViewModel tab) => tab.Groups).SelectMany((TweakGroupViewModel @group) => @group.Rows)
			select row.Definition.Id).ToList();
		if (list.Count != tweakService.GetAllTweaks().Count(t=>t.Category!=TweakCategory.Gpu || !t.RestoreOnly) || list.Distinct<string>(StringComparer.OrdinalIgnoreCase).Count() != list.Count)
		{
			throw new InvalidOperationException("The tweak tab catalog must place every tweak exactly once.");
		}
		return dictionary;
	}

	private static (string Tab, string Group) ResolvePlacement(TweakDefinition tweak)
	{
		string id = tweak.Id;
		if (id == "gaming.mouse-acceleration.disable" || id.StartsWith("precision.", StringComparison.OrdinalIgnoreCase))
		{
			return (Tab: "precision", Group: "MOUSE & POINTER CONSISTENCY");
		}
		if (id.StartsWith("mitigations.", StringComparison.OrdinalIgnoreCase))
		{
			string item = ((id.Contains("smartscreen") || id.Contains("mark-of-the-web")) ? "APP & DOWNLOAD PROTECTIONS" : (id.Contains("cpu-side-channel") ? "CPU SIDE-CHANNEL MITIGATIONS" : "VIRTUALIZATION & KERNEL ISOLATION"));
			return (Tab: "mitigations", Group: item);
		}
		if (id.StartsWith("services.", StringComparison.OrdinalIgnoreCase))
		{
			return (Tab: "services", Group: "WINDOWS SERVICE STACKS");
		}
		if (id.StartsWith("appearance.", StringComparison.OrdinalIgnoreCase) || id == "perf.visual-effects.best-performance" || id == "windows.file-extensions.show")
		{
			string item2 = ((id.Contains("explorer", StringComparison.OrdinalIgnoreCase) || id == "windows.file-extensions.show") ? "FILE EXPLORER" : ((id.Contains("context", StringComparison.OrdinalIgnoreCase) || id.Contains("previous-versions", StringComparison.OrdinalIgnoreCase)) ? "CONTEXT MENU" : "GENERAL"));
			return (Tab: "appearance", Group: item2);
		}
		if (tweak.Category == TweakCategory.Network)
		{
			return (Tab: "network", Group: "NETWORK STACK");
		}
		if (tweak.Category == TweakCategory.Gpu)
		{
			string item3 = (id.StartsWith("gpu.nvidia.", StringComparison.OrdinalIgnoreCase) ? "NVIDIA DRIVER" : (id.StartsWith("gpu.amd.", StringComparison.OrdinalIgnoreCase) ? "AMD RADEON DRIVER" : "WINDOWS GPU SCHEDULING"));
			return (Tab: "gpu", Group: item3);
		}
		if (tweak.Category == TweakCategory.Cpu || id.StartsWith("power.", StringComparison.OrdinalIgnoreCase) || id == "perf.usb-selective-suspend" || id == "windows.fast-startup.disable")
		{
			string item4 = (id.Contains("usb", StringComparison.OrdinalIgnoreCase) ? "USB POWER" : ((id.Contains("hibernation", StringComparison.OrdinalIgnoreCase) || id.Contains("fast-startup", StringComparison.OrdinalIgnoreCase)) ? "HIBERNATION & STARTUP" : "CPU & TIMER POWER"));
			return (Tab: "power", Group: item4);
		}
		if (IsBasicTweak(id, tweak.Category))
		{
			return (Tab: "basic", Group: ResolveBasicGroup(id));
		}
		if (tweak.Category == TweakCategory.Windows)
		{
			return (Tab: "privacy", Group: ResolvePrivacyGroup(id));
		}
		return (Tab: "advanced", Group: tweak.Category switch
		{
			TweakCategory.Memory => "MEMORY & SCHEDULING", 
			TweakCategory.Storage => "STORAGE", 
			TweakCategory.Input => "INPUT", 
			TweakCategory.Gpu => "GPU SCHEDULING", 
			TweakCategory.Gaming => "GAME TASK SCHEDULING", 
			_ => "SYSTEM", 
		});
	}

	private static bool IsBasicTweak(string id, TweakCategory category)
	{
		bool flag = category == TweakCategory.Gaming;
		if (!flag)
		{
			bool flag2;
			switch (id)
			{
			case "gaming.mouse-acceleration.disable":
			case "windows.automatic-updates.disable":
			case "perf.background-apps.disable":
			case "windows.widgets-news.disable":
			case "windows.fast-user-switching.enable":
			case "windows.store-auto-updates.disable":
			case "windows.audio-ducking.disable":
			case "windows.onedrive-sync.disable":
			case "windows.update-driver-delivery.disable":
			case "windows.menu-delay.reduce":
			case "windows.automatic-maintenance.disable":
			case "windows.sleep-study.disable":
			case "windows.accessibility-shortcut-prompts.disable":
				flag2 = true;
				break;
			default:
				flag2 = false;
				break;
			}
			flag = flag2;
		}
		return flag;
	}

	private static string ResolveBasicGroup(string id)
	{
		if (id.StartsWith("gaming.", StringComparison.OrdinalIgnoreCase))
		{
			return "GAMING";
		}
		if (id.Contains("update", StringComparison.OrdinalIgnoreCase))
		{
			return "UPDATES";
		}
		if (id.Contains("background", StringComparison.OrdinalIgnoreCase) || id.Contains("widgets", StringComparison.OrdinalIgnoreCase) || id.Contains("onedrive", StringComparison.OrdinalIgnoreCase))
		{
			return "BACKGROUND APPS";
		}
		if (id.Contains("maintenance", StringComparison.OrdinalIgnoreCase) || id.Contains("store-auto", StringComparison.OrdinalIgnoreCase) || id.Contains("sleep-study", StringComparison.OrdinalIgnoreCase))
		{
			return "MAINTENANCE & REPORTING";
		}
		if (id.Contains("accessibility", StringComparison.OrdinalIgnoreCase))
		{
			return "CONVENIENCE";
		}
		return "RESPONSIVENESS";
	}

	private static string ResolvePrivacyGroup(string id)
	{
		if (id.Contains("telemetry", StringComparison.OrdinalIgnoreCase) || id.Contains("ceip", StringComparison.OrdinalIgnoreCase) || id.Contains("feedback", StringComparison.OrdinalIgnoreCase) || id.Contains("app-launch", StringComparison.OrdinalIgnoreCase) || id.Contains("activity-history", StringComparison.OrdinalIgnoreCase) || id.Contains("error-reporting", StringComparison.OrdinalIgnoreCase))
		{
			return "TELEMETRY";
		}
		if (id.Contains("advertising", StringComparison.OrdinalIgnoreCase) || id.Contains("language-header", StringComparison.OrdinalIgnoreCase))
		{
			return "ADVERTISING";
		}
		if (id.Contains("typing", StringComparison.OrdinalIgnoreCase) || id.Contains("speech", StringComparison.OrdinalIgnoreCase) || id.Contains("input-personalization", StringComparison.OrdinalIgnoreCase))
		{
			return "INPUT PERSONALIZATION";
		}
		if (id.Contains("search", StringComparison.OrdinalIgnoreCase))
		{
			return "SEARCH SUGGESTIONS";
		}
		if (id.Contains("location", StringComparison.OrdinalIgnoreCase) || id.Contains("diagnostic-access", StringComparison.OrdinalIgnoreCase) || id.Contains("notification-access", StringComparison.OrdinalIgnoreCase))
		{
			return "APP PERMISSIONS";
		}
		if (id.Contains("lock-screen", StringComparison.OrdinalIgnoreCase))
		{
			return "LOCK SCREEN";
		}
		return "TAILORED EXPERIENCES";
	}
}

using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel.__Internals;
using CommunityToolkit.Mvvm.Input;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class MainViewModel : ObservableObject
{
	[ObservableProperty]
	private NavItem? _selectedNavItem;

	[ObservableProperty]
	private object? _currentViewModel;

	private readonly Dictionary<string, object> _pages;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private RelayCommand? joinDiscordCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private RelayCommand? openYouTubeCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private RelayCommand? openTikTokCommand;

	public ObservableCollection<NavItem> NavItems { get; }

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public NavItem? SelectedNavItem
	{
		get
		{
			return _selectedNavItem;
		}
		set
		{
			if (!EqualityComparer<NavItem>.Default.Equals(_selectedNavItem, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.SelectedNavItem);
				_selectedNavItem = value;
				OnSelectedNavItemChanged(value);
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.SelectedNavItem);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public object? CurrentViewModel
	{
		get
		{
			return _currentViewModel;
		}
		set
		{
			if (!EqualityComparer<object>.Default.Equals(_currentViewModel, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.CurrentViewModel);
				_currentViewModel = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.CurrentViewModel);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand JoinDiscordCommand => joinDiscordCommand ?? (joinDiscordCommand = new RelayCommand(JoinDiscord));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand OpenYouTubeCommand => openYouTubeCommand ?? (openYouTubeCommand = new RelayCommand(OpenYouTube));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand OpenTikTokCommand => openTikTokCommand ?? (openTikTokCommand = new RelayCommand(OpenTikTok));

	public MainViewModel(DashboardViewModel dashboard, ITweakService tweakService, IGpuToolService gpuToolService, ISystemInfoService systemInfoService, GamingViewModel gaming, CleanupViewModel cleanup, StartupManagerViewModel startupManager, SettingsViewModel settings)
	{
		IReadOnlyDictionary<string, TweakTabViewModel> readOnlyDictionary = TweakTabCatalog.Build(tweakService);
		_pages = new Dictionary<string, object>
		{
			["dashboard"] = dashboard,
			["basic"] = readOnlyDictionary["basic"],
			["privacy"] = readOnlyDictionary["privacy"],
			["power"] = readOnlyDictionary["power"],
			["gpu"] = new GpuViewModel(readOnlyDictionary["gpu"], gpuToolService, systemInfoService),
			["network"] = readOnlyDictionary["network"],
			["advanced"] = readOnlyDictionary["advanced"],
			["mitigations"] = readOnlyDictionary["mitigations"],
			["service-groups"] = readOnlyDictionary["services"],
			["appearance"] = readOnlyDictionary["appearance"],
			["precision"] = readOnlyDictionary["precision"],
			["bios"] = new BiosViewModel(),
			["games"] = gaming,
			["cleanup"] = cleanup,
			["startup-manager"] = startupManager,
			["settings"] = settings
		};
		NavItems = new ObservableCollection<NavItem>
		{
			new NavItem
			{
				Key = "dashboard",
				Title = "Home",
				IconGeometry = "M2,2 H9 V9 H2 Z M11,2 H18 V9 H11 Z M2,11 H9 V18 H2 Z M11,11 H18 V18 H11 Z"
			},
			new NavItem
			{
				Key = "basic",
				Title = "Basic",
				IconGeometry = "M3,10 H17 M10,3 V17 M5,5 L15,15 M15,5 L5,15"
			},
			new NavItem
			{
				Key = "privacy",
				Title = "Privacy",
				IconGeometry = "M10,2 L17,5 V10 C17,14 14,17 10,19 C6,17 3,14 3,10 V5 Z"
			},
			new NavItem
			{
				Key = "power",
				Title = "Power",
				IconGeometry = "M11,2 L5,11 H10 L9,18 L16,8 H11 Z"
			},
			new NavItem
			{
				Key = "gpu",
				Title = "GPU",
				IconGeometry = "M3,5 H17 V15 H3 Z M6,8 H10 V12 H6 Z M17,8 H19 M17,12 H19 M7,15 V18 M13,15 V18"
			},
			new NavItem
			{
				Key = "network",
				Title = "Network",
				IconGeometry = "M2,8 C6,4 14,4 18,8 M5,11 C8,8 12,8 15,11 M8,14 C9,13 11,13 12,14 M10,17 L10,17"
			},
			new NavItem
			{
				Key = "advanced",
				Title = "Advanced",
				IconGeometry = "M2,15 L7,9 L11,13 L18,4"
			},
			new NavItem
			{
				Key = "mitigations",
				Title = "Mitigations",
				IconGeometry = "M10,2 L17,5 V10 C17,14 14,17 10,19 C6,17 3,14 3,10 V5 Z M7,10 L9,12 L13,8"
			},
			new NavItem
			{
				Key = "service-groups",
				Title = "Services",
				IconGeometry = "M3,4 H17 V8 H3 Z M3,11 H17 V15 H3 Z M6,6 H6 M6,13 H13"
			},
			new NavItem
			{
				Key = "appearance",
				Title = "Appearance",
				IconGeometry = "M3,6 H17 M3,10 H17 M3,14 H17 M6,6 A1.5,1.5 0 1 1 5.9,6 M13,10 A1.5,1.5 0 1 1 12.9,10 M8,14 A1.5,1.5 0 1 1 7.9,14"
			},
			new NavItem
			{
				Key = "precision",
				Title = "Precision",
				IconGeometry = "M10,1 V5 M10,15 V19 M1,10 H5 M15,10 H19 M10,4 A6,6 0 1 1 9.99,4"
			},
			new NavItem
			{
				Key = "games",
				Title = "Games",
				IconGeometry = "M3,7 H17 V13 H3 Z M6,10 H6 M14,9 H14 M14,11 H14"
			},
			new NavItem
			{
				Key = "cleanup",
				Title = "Cleanup",
				IconGeometry = "M4,6 H16 M8,6 V4 H12 V6 M6,6 L7,17 H13 L14,6"
			},
			new NavItem
			{
				Key = "startup-manager",
				Title = "Startup",
				IconGeometry = "M10,3 V9 M5.5,5 A6,6 0 1 0 14.5,5"
			},
			new NavItem
			{
				Key = "bios",
				Title = "BIOS",
				IconGeometry = "M4,4 H16 V16 H4 Z M7,1 V4 M13,1 V4 M7,16 V19 M13,16 V19 M1,7 H4 M16,7 H19 M7,7 H13 V13 H7 Z"
			},
			new NavItem
			{
				Key = "settings",
				Title = "Settings",
				IconGeometry = "M3,6 H17 M3,10 H17 M3,14 H17 M6,6 A1.5,1.5 0 1 1 5.9,6 M13,10 A1.5,1.5 0 1 1 12.9,10 M8,14 A1.5,1.5 0 1 1 7.9,14"
			}
		};
		SelectedNavItem = NavItems[0];
		CurrentViewModel = dashboard;
	}

	[RelayCommand]
	private void JoinDiscord()
	{
		OpenCommunityLink("https://discord.gg/quantix");
	}

	[RelayCommand]
	private void OpenYouTube()
	{
		OpenCommunityLink("https://www.youtube.com/@quantixtweaks");
	}

	[RelayCommand]
	private void OpenTikTok()
	{
		OpenCommunityLink("https://www.tiktok.com/@quantix_tweaks");
	}

	private static void OpenCommunityLink(string url)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = url,
				UseShellExecute = true
			});
		}
		catch
		{
			MessageBox.Show("Could not open your browser. Visit " + url, "Quantix community", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	private void OnSelectedNavItemChanged(NavItem? value)
	{
		if (value != null && _pages.TryGetValue(value.Key, out var value2))
		{
			CurrentViewModel = value2;
		}
	}
}

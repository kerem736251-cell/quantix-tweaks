using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel.__Internals;
using CommunityToolkit.Mvvm.Input;
using QuantixTweakingUtility.Models;
using QuantixTweakingUtility.Services;

namespace QuantixTweakingUtility.ViewModels;

public sealed class TweakRowViewModel : ObservableObject
{
	private readonly ITweakService _tweaks;

	private TweakState _state;

	[ObservableProperty]
	private bool _isApplied;

	[ObservableProperty]
	private bool _isBusy;

	[ObservableProperty]
	private string _busyActionText = string.Empty;

	[ObservableProperty]
	private string _statusText = string.Empty;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	private AsyncRelayCommand? toggleCommand;

	public string StateLabel => _state switch
	{
		TweakState.Applied => "ON", 
		TweakState.NotApplied => "OFF", 
		TweakState.Unsupported => "UNAVAILABLE", 
		_ => "UNKNOWN", 
	};

	public TweakDefinition Definition { get; }

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public bool IsApplied
	{
		get
		{
			return _isApplied;
		}
		set
		{
			if (!EqualityComparer<bool>.Default.Equals(_isApplied, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.IsApplied);
				_isApplied = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.IsApplied);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public bool IsBusy
	{
		get
		{
			return _isBusy;
		}
		set
		{
			if (!EqualityComparer<bool>.Default.Equals(_isBusy, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.IsBusy);
				_isBusy = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.IsBusy);
				ToggleCommand.NotifyCanExecuteChanged();
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string BusyActionText
	{
		get
		{
			return _busyActionText;
		}
		[MemberNotNull("_busyActionText")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_busyActionText, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.BusyActionText);
				_busyActionText = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.BusyActionText);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.ObservablePropertyGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public string StatusText
	{
		get
		{
			return _statusText;
		}
		[MemberNotNull("_statusText")]
		set
		{
			if (!EqualityComparer<string>.Default.Equals(_statusText, value))
			{
				OnPropertyChanging(__KnownINotifyPropertyChangingArgs.StatusText);
				_statusText = value;
				OnPropertyChanged(__KnownINotifyPropertyChangedArgs.StatusText);
			}
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.2.0.0")]
	[ExcludeFromCodeCoverage]
	public IAsyncRelayCommand ToggleCommand => toggleCommand ?? (toggleCommand = new AsyncRelayCommand(ToggleAsync, CanToggle));

	private bool CanToggle()
	{
		if (!IsBusy && (!Definition.RestoreOnly || IsApplied))
		{
			if (_state != TweakState.Applied)
			{
				return _state == TweakState.NotApplied;
			}
			return true;
		}
		return false;
	}

	public TweakRowViewModel(TweakDefinition definition, ITweakService tweaks)
	{
		Definition = definition;
		_tweaks = tweaks;
		RefreshStateAsync();
	}

	public async Task RefreshStateAsync()
	{
		try
		{
			_state = await Definition.CurrentStateReader();
			IsApplied = _state == TweakState.Applied;
			StatusText = _state switch
			{
				TweakState.Unsupported => "Not supported on this system. No changes will be made.", 
				TweakState.Unknown => "State unavailable. Refresh status before changing this setting.", 
				TweakState.Applied => "Currently applied.", 
				_ => "Not applied.", 
			};
		}
		catch
		{
			_state = TweakState.Unknown;
			StatusText = "State unavailable. Refresh status before changing this setting.";
		}
		if (Definition.RestoreOnly)
		{
			StatusText = (IsApplied ? "Retired for stability. Switch OFF to restore your saved values, then restart Windows." : "Retired for stability. New application is blocked; no saved recovery is available.");
		}
		OnPropertyChanged("StateLabel");
		ToggleCommand.NotifyCanExecuteChanged();
	}

	[RelayCommand]
	private async Task ToggleAsync()
	{
		if (IsBusy)
		{
			return;
		}
		IsBusy = true;
		await RefreshStateAsync();
		IsBusy = false;
		if (!CanToggle())
		{
			return;
		}
		if (!IsApplied && Definition.RiskLevel == TweakRiskLevel.High && MessageBox.Show(Definition.Name + "\n\n" + Definition.Description + "\n\nThis is a HIGH-RISK setting and can reduce security, compatibility, or system stability. It is never included in automatic presets. Apply it anyway?", "Confirm high-risk tweak", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
		{
			StatusText = "High-risk change cancelled.";
			return;
		}
		bool wasApplied = IsApplied;
		BusyActionText = (wasApplied ? "RESTORING" : "APPLYING");
		StatusText = (wasApplied ? ("Restoring " + Definition.Name + "...") : ("Applying " + Definition.Name + "..."));
		IsBusy = true;
		try
		{
			await Task.Yield();
			TweakActionResult tweakActionResult = (wasApplied ? (await _tweaks.RestoreTweakAsync(Definition.Id)) : (await _tweaks.ApplyTweakAsync(Definition.Id)));
			TweakActionResult tweakActionResult2 = tweakActionResult;
			TweakActionResult tweakActionResult3 = tweakActionResult2;
			await RefreshStateAsync();
			string text = ((_state == TweakState.Unknown || _state == TweakState.Unsupported) ? (" " + StatusText) : "");
			StatusText = tweakActionResult3.Message + text;
			if (tweakActionResult3.Success && Definition.RequiresRestart)
			{
				StatusText += " Restart Windows to finish this change.";
			}
		}
		catch (Exception ex)
		{
			await RefreshStateAsync();
			StatusText = "Could not change " + Definition.Name + ": " + ex.Message;
		}
		finally
		{
			IsBusy = false;
			BusyActionText = string.Empty;
			OnPropertyChanged("IsApplied");
		}
	}
}

using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading.Tasks;
using QuantixTweakingUtility.Models;

namespace QuantixTweakingUtility.Services;

public sealed class NetworkInfoService : INetworkInfoService
{
	private readonly ILoggingService _logging;

	public NetworkInfoService(ILoggingService logging)
	{
		_logging = logging;
	}

    public async Task<NetworkSnapshot> GetSnapshotAsync()
    {
        var result = await NetworkWorkflow.RunAsync("Inspect");
        var connection = result.Connection;
        if (!result.Success || connection == null)
            return new NetworkSnapshot { ConnectionState = result.Message, IsConnected = false };
        var nic = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(n => n.Id.Trim('{','}').Equals(connection.Id, StringComparison.OrdinalIgnoreCase));
        var properties = nic?.GetIPProperties();
        return new NetworkSnapshot {
            AdapterName = connection.Adapter, ConnectionState = connection.Status, ConnectionType = connection.Type,
            LinkSpeed = connection.LinkSpeed, DnsServers = connection.Dns,
            IPv4Address = properties?.UnicastAddresses.FirstOrDefault(a => a.Address.AddressFamily == AddressFamily.InterNetwork)?.Address.ToString() ?? "Unavailable",
            IPv6Address = properties?.UnicastAddresses.FirstOrDefault(a => a.Address.AddressFamily == AddressFamily.InterNetworkV6 && !a.Address.IsIPv6LinkLocal)?.Address.ToString() ?? "Unavailable",
            IsConnected = connection.Index > 0
        };
    }

	public async Task<(bool Success, string Message)> TestLatencyAsync()
	{
		try
		{
			using Ping ping = new Ping();
			PingReply pingReply = await ping.SendPingAsync("1.1.1.1", 3000);
			if (pingReply.Status == IPStatus.Success)
			{
				return (Success: true, Message: $"Latency to 1.1.1.1: {pingReply.RoundtripTime} ms");
			}
			return (Success: false, Message: $"Latency test did not complete: {pingReply.Status}.");
		}
		catch (Exception ex)
		{
			_logging.Error("NetworkInfo", "Latency test failed.", ex);
			return (Success: false, Message: "Latency test could not reach the network.");
		}
	}

	public async Task<(bool Success, string Message)> FlushDnsAsync()
	{
		_ = 2;
		try
		{
			ProcessStartInfo startInfo = new ProcessStartInfo
			{
				FileName = "ipconfig",
				Arguments = "/flushdns",
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};
			using Process process = Process.Start(startInfo);
			if (process == null)
			{
				return (Success: false, Message: "Windows could not start ipconfig.");
			}
			Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
			Task<string> errorTask = process.StandardError.ReadToEndAsync();
			await process.WaitForExitAsync();
			await outputTask;
			string text = await errorTask;
			if (process.ExitCode == 0)
			{
				_logging.Info("NetworkInfo", "Flushed the Windows DNS resolver cache.");
				return (Success: true, Message: "DNS resolver cache flushed.");
			}
			_logging.Warn("NetworkInfo", "DNS flush failed: " + text);
			return (Success: false, Message: string.IsNullOrWhiteSpace(text) ? "Windows could not flush the DNS resolver cache." : text.Trim());
		}
		catch (Exception ex)
		{
			_logging.Error("NetworkInfo", "DNS flush failed.", ex);
			return (Success: false, Message: "DNS cache could not be flushed. See the log for details.");
		}
	}

	private static string FormatLinkSpeed(long bitsPerSecond)
	{
		if (bitsPerSecond <= 0)
		{
			return "Unknown";
		}
		if (bitsPerSecond < 1000000000)
		{
			return $"{(double)bitsPerSecond / 1000000.0:0.#} Mbps";
		}
		return $"{(double)bitsPerSecond / 1000000000.0:0.#} Gbps";
	}
}

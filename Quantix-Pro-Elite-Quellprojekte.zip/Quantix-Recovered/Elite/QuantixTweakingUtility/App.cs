using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using QuantixLicensing;
using QuantixTweakingUtility.Services;
using QuantixTweakingUtility.ViewModels;
using QuantixTweakingUtility.Views;

namespace QuantixTweakingUtility;

public class App : Application
{
	private IHost? _host;

	private bool _contentLoaded;

	public static IServiceProvider Services => ((App)Application.Current)._host.Services;

	protected override async void OnStartup(StartupEventArgs e)
	{
		base.OnStartup(e);
        if (await NetworkDiagnostics.RunAsync(e.Args)) return;
		int num = Array.IndexOf(e.Args, "--import-license-update");
		if (num >= 0)
		{
			try
			{
				OfflineUpdateUi.ImportFile(e.Args[num + 1]);
				Shutdown(0);
				return;
			}
			catch
			{
				Shutdown(65);
				return;
			}
		}
		base.ShutdownMode = ShutdownMode.OnExplicitShutdown;
		if (e.Args.Contains<string>("--verify-views", StringComparer.OrdinalIgnoreCase))
		{
			new DashboardView();
			new PerformanceView();
			new GamingView();
			new NetworkView();
			new WindowsView();
			new CleanupView();
			new GamingCleanupWindow();
			new GamingSessionWindow();
			new SettingsView();
			new TweakTabView();
			new GpuView();
			new BiosView();
			new LicenseWindow();
			Shutdown(0);
			return;
		}
		if (TryGetOption(e.Args, "--verify-bios", out string value))
		{
			try
			{
				ArgumentException.ThrowIfNullOrWhiteSpace(value, "previewPath");
				BiosViewModel biosViewModel = new BiosViewModel();
				foreach (string motherboardBrand in biosViewModel.MotherboardBrands)
				{
					foreach (string cpuPlatform in biosViewModel.CpuPlatforms)
					{
						bool[] array = new bool[2] { false, true };
						foreach (bool flag in array)
						{
							bool[] array2 = new bool[2] { false, true };
							foreach (bool flag2 in array2)
							{
								bool[] array3 = new bool[2] { false, true };
								foreach (bool cStateExperiment in array3)
								{
									string text = BiosViewModel.BuildGuide(motherboardBrand, cpuPlatform, "Test board", "Test CPU", flag, flag2, cStateExperiment);
									bool flag3 = motherboardBrand.Contains("OEM") || cpuPlatform.StartsWith("Select") || cpuPlatform.StartsWith("Other");
									if (text.Contains("NO TUNING PRESET SELECTED") != flag3 || (!flag3 && text.Contains("Precision Boost Overdrive") != cpuPlatform.StartsWith("AMD")) || (!flag3 && text.Contains("Memory profiles are overclocking") != flag) || (text.Contains("Enabled (optional overclocking trial)") && (!flag2 || !cpuPlatform.StartsWith("AMD") || cpuPlatform.Contains("1000") || cpuPlatform.Contains("8000G") || cpuPlatform.Contains("5000 X3D"))) || (cpuPlatform.Contains("13th / 14th") && text.Contains("Disabled (comparison test only)")))
									{
										throw new InvalidOperationException("BIOS guide matrix failed.");
									}
								}
							}
						}
					}
				}
				biosViewModel.SelectedPlatform = "AMD AM5 — Ryzen 7000 / 9000 (non-X3D)";
				biosViewModel.PboSupportConfirmed = true;
				biosViewModel.MotherboardModel = "Test model";
				if (biosViewModel.PboSupportConfirmed)
				{
					throw new InvalidOperationException("Hardware change must reset PBO confirmation.");
				}
				biosViewModel.PboSupportConfirmed = true;
				biosViewModel.IncludeCStateExperiment = true;
				biosViewModel.IncludeMemoryProfile = true;
				Window window = new Window
				{
					Content = new BiosView
					{
						DataContext = biosViewModel
					},
					Width = 1100.0,
					Height = 800.0,
					ShowInTaskbar = false,
					Left = -10000.0,
					Top = -10000.0,
					WindowStartupLocation = WindowStartupLocation.Manual
				};
				window.Show();
				window.UpdateLayout();
				using (FileStream output = File.Create(value))
				{
					BiosView.ExportGuidePng(biosViewModel.GuideText, output);
				}
				window.Close();
				Shutdown(0);
				return;
			}
			catch
			{
				Shutdown(40);
				return;
			}
		}
		_host = Host.CreateDefaultBuilder().ConfigureServices(delegate(HostBuilderContext _, IServiceCollection services)
		{
			services.AddSingleton<ILoggingService, LoggingService>();
			services.AddSingleton<ISystemInfoService, SystemInfoService>();
			services.AddSingleton<IRestoreService, RestoreService>();
			services.AddSingleton<ITweakService, TweakEngineService>();
			services.AddSingleton<INetworkInfoService, NetworkInfoService>();
			services.AddSingleton<ICleanupService, CleanupService>();
			services.AddSingleton<IAppSettingsService, AppSettingsService>();
			services.AddSingleton<IWindowsMaintenanceService, WindowsMaintenanceService>();
			services.AddSingleton<IGameLibraryService, GameLibraryService>();
			services.AddSingleton<IStartupManagerService, StartupManagerService>();
			services.AddSingleton<IRevocationService, RevocationService>();
			services.AddSingleton<ILicenseService, LicenseService>();
			services.AddSingleton<IGpuToolService, GpuToolService>();
			services.AddSingleton<MainViewModel>();
			services.AddSingleton<DashboardViewModel>();
			services.AddSingleton<PerformanceViewModel>();
			services.AddSingleton<GamingViewModel>();
			services.AddSingleton<NetworkViewModel>();
			services.AddSingleton<WindowsViewModel>();
			services.AddSingleton<CleanupViewModel>();
			services.AddSingleton<StartupManagerViewModel>();
			services.AddSingleton<SettingsViewModel>();
			services.AddTransient<LicenseViewModel>();
			services.AddSingleton<MainWindow>();
			services.AddTransient<LicenseWindow>();
		}).Build();
		await _host.StartAsync();
        if (await NetworkDiagnostics.RunVisibleAsync(e.Args)) return;
        if (await CleanupDiagnostics.RunAsync(e.Args)) return;
        if (await ScewinDiagnostics.RunAsync(e.Args)) return;
        if (await GraphicsDiagnostics.RunAsync(e.Args)) return;
		if (e.Args.Contains<string>("--verify-host", StringComparer.OrdinalIgnoreCase))
		{
			Services.GetRequiredService<MainWindow>();
			LicenseWindow requiredService = Services.GetRequiredService<LicenseWindow>();
			requiredService.ShowInTaskbar = false;
			requiredService.WindowStartupLocation = WindowStartupLocation.Manual;
			requiredService.Left = -10000.0;
			requiredService.Top = -10000.0;
			requiredService.Show();
			requiredService.UpdateLayout();
			requiredService.Close();
			Shutdown(0);
			return;
		}
		if (e.Args.Contains<string>("--verify-gpu-tool", StringComparer.OrdinalIgnoreCase))
		{
			IGpuToolService gpuToolService = Services.GetRequiredService<IGpuToolService>();
			GpuToolResult result = Task.Run(() => gpuToolService.PrepareNvidiaProfileInspectorAsync(openInspector: false)).GetAwaiter().GetResult();
			Shutdown((!result.Success) ? 30 : 0);
			return;
		}
		if (TryGetOption(e.Args, "--verify-license", out string value2))
		{
			if (string.IsNullOrWhiteSpace(value2) || !File.Exists(value2))
			{
				Shutdown(64);
				return;
			}
			TryGetOption(e.Args, "--hwid-override", out string value3);
			DateTimeOffset? nowUtc = null;
			if (TryGetOption(e.Args, "--time-override", out string value4) && DateTimeOffset.TryParse(value4, out var result2))
			{
				nowUtc = result2;
			}
			LicenseValidationResult licenseValidationResult = Services.GetRequiredService<ILicenseService>().ValidateToken(File.ReadAllText(value2), value3, nowUtc);
			Shutdown((int)((!licenseValidationResult.IsValid) ? (20 + licenseValidationResult.Status) : LicenseStatus.Valid));
			return;
		}
		if (TryGetOption(e.Args, "--activate-license-file", out string value5))
		{
			LicenseValidationResult licenseValidationResult2 = await Services.GetRequiredService<ILicenseService>().ActivateAsync(File.ReadAllText(value5));
			Shutdown((int)((!licenseValidationResult2.IsValid) ? (20 + licenseValidationResult2.Status) : LicenseStatus.Valid));
			return;
		}
		if (((ReadOnlySpan<string>)e.Args).Contains("--verify-saved-license"))
		{
			LicenseValidationResult licenseValidationResult3 = await Services.GetRequiredService<ILicenseService>().ValidateSavedLicenseAsync();
			Shutdown((int)((!licenseValidationResult3.IsValid) ? (20 + licenseValidationResult3.Status) : LicenseStatus.Valid));
			return;
		}
		ILoggingService loggingService = Services.GetRequiredService<ILoggingService>();
		loggingService.Info("Application", "Quantix Tweaking Utility Elite starting up.");
		SessionRestorePoint.StartOnce(message => loggingService.Info("SystemRestore", message));
		Window window2 = (base.MainWindow = Services.GetRequiredService<MainWindow>());
		MainWindow mainWindow = (MainWindow)window2;
		ILicenseService requiredService3 = Services.GetRequiredService<ILicenseService>();
		if (Services.GetRequiredService<LicenseWindow>().ShowDialog() != true)
		{
			Shutdown(2);
			return;
		}
		if (!(await requiredService3.ValidateSavedLicenseAsync()).IsValid)
		{
			Shutdown(3);
			return;
		}
		loggingService.Info("License", "License explicitly verified for this launch.");
		mainWindow.Loaded += delegate
		{
			loggingService.Info("Application", "Main window loaded and visible.");
		};
		mainWindow.Closed += delegate
		{
			loggingService.Info("Application", "Main window closed; shutting down normally.");
			Shutdown(0);
		};
		try
		{
			mainWindow.Show();
			loggingService.Info("Application", "Main window show completed.");
		}
		catch (Exception ex)
		{
			loggingService.Error("Application", "Main window could not be displayed.", ex);
			MessageBox.Show("Quantix could not open the main window.\n\n" + ex.Message, "Quantix Elite — Startup Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			Shutdown(4);
		}
	}

	private static bool TryGetOption(IReadOnlyList<string> args, string option, out string? value)
	{
		value = null;
		for (int i = 0; i < args.Count; i++)
		{
			if (string.Equals(args[i], option, StringComparison.OrdinalIgnoreCase))
			{
				if (i + 1 < args.Count && !args[i + 1].StartsWith("--", StringComparison.Ordinal))
				{
					value = args[i + 1];
				}
				return true;
			}
		}
		return false;
	}

	protected override void OnExit(ExitEventArgs e)
	{
		if (_host != null)
		{
			_host.Services.GetService<ILoggingService>()?.Info("Application", $"Application exit requested with code {e.ApplicationExitCode}.");
			_host.StopAsync().GetAwaiter().GetResult();
			_host.Dispose();
		}
		base.OnExit(e);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public static void Main()
	{
		App app = new App();
		app.InitializeComponent();
		app.Run();
	}
}


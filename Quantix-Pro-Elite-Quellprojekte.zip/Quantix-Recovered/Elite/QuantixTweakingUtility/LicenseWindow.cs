using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Markup;
using QuantixTweakingUtility.Services;
using QuantixTweakingUtility.ViewModels;

namespace QuantixTweakingUtility;

public class LicenseWindow : Window, IComponentConnector
{
	private LicenseViewModel? _viewModel;

	private bool _contentLoaded;

	public LicenseWindow()
	{
		InitializeComponent();
	}

	public LicenseWindow(LicenseViewModel viewModel)
		: this()
	{
		_viewModel = viewModel;
		base.DataContext = viewModel;
		viewModel.LicenseAccepted += ViewModel_LicenseAccepted;
		viewModel.ExitRequested += ViewModel_ExitRequested;
		base.Closed += LicenseWindow_Closed;
	}

	private void ViewModel_LicenseAccepted(object? sender, EventArgs e)
	{
		base.DialogResult = true;
	}

	private void ViewModel_ExitRequested(object? sender, EventArgs e)
	{
		base.DialogResult = false;
	}

	private void LicenseWindow_Closed(object? sender, EventArgs e)
	{
		if (_viewModel != null)
		{
			_viewModel.LicenseAccepted -= ViewModel_LicenseAccepted;
			_viewModel.ExitRequested -= ViewModel_ExitRequested;
		}
	}

	private void ImportOfflineUpdate_Click(object sender, RoutedEventArgs e)
	{
		OfflineUpdateUi.Import(this);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/quantixtweakingutility.licensewindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		_contentLoaded = true;
	}
}

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using QuantixTweakingUtility.Services;
using QuantixTweakingUtility.ViewModels;

namespace QuantixTweakingUtility;

public class MainWindow : Window, IComponentConnector
{
	private const double CornerRadiusPx = 12.0;

	private bool _contentLoaded;

	public MainWindow(MainViewModel viewModel)
	{
		InitializeComponent();
        Loaded += (_, _) => VersionLabels.Refresh(this);
		base.DataContext = viewModel;
		base.Loaded += delegate
		{
			ApplyRoundedClip();
		};
		base.SizeChanged += delegate
		{
			ApplyRoundedClip();
		};
		base.StateChanged += delegate
		{
			ApplyRoundedClip();
		};
	}

	private void Window_SourceInitialized(object? sender, EventArgs e)
	{
		WindowCornerHelper.TryEnableRoundedCorners(new WindowInteropHelper(this).Handle);
	}

	private void ApplyRoundedClip()
	{
		if (!(base.ActualWidth <= 0.0) && !(base.ActualHeight <= 0.0))
		{
			base.Clip = ((base.WindowState == WindowState.Maximized) ? new RectangleGeometry(new Rect(0.0, 0.0, base.ActualWidth, base.ActualHeight)) : new RectangleGeometry(new Rect(0.0, 0.0, base.ActualWidth, base.ActualHeight), 12.0, 12.0));
		}
	}

	private void MinimizeButton_Click(object sender, RoutedEventArgs e)
	{
		base.WindowState = WindowState.Minimized;
	}

	private void MaximizeRestoreButton_Click(object sender, RoutedEventArgs e)
	{
		base.WindowState = ((base.WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
	}

	private void CloseButton_Click(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private void ImportOfflineUpdate_Click(object sender, RoutedEventArgs e)
	{
		OfflineUpdateUi.Import(this);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/quantixtweakingutility.mainwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			((MainWindow)target).SourceInitialized += Window_SourceInitialized;
			break;
		case 2:
			((Button)target).Click += MinimizeButton_Click;
			break;
		case 3:
			((Button)target).Click += MaximizeRestoreButton_Click;
			break;
		case 4:
			((Button)target).Click += CloseButton_Click;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}

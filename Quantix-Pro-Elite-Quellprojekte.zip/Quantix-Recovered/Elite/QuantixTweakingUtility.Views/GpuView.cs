using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace QuantixTweakingUtility.Views;

public class GpuView : UserControl, IComponentConnector
{
	private bool _contentLoaded;

	public GpuView()
	{
		InitializeComponent();
		var scroll=FindScroll(Content as DependencyObject);
        if(scroll?.Content is Panel panel){panel.Children.Add(new GpuMsiPanel());panel.Children.Add(new NvidiaSettingsPanel(false));AddRecovery(panel);panel.Children.Add(new GameGraphicsPanel());}
        else if(scroll!=null){var old=scroll.Content;scroll.Content=null;var body=new StackPanel();if(old is UIElement element)body.Children.Add(element);body.Children.Add(new GpuMsiPanel());body.Children.Add(new NvidiaSettingsPanel(false));AddRecovery(body);body.Children.Add(new GameGraphicsPanel());scroll.Content=body;}
	}

	private static void AddRecovery(Panel panel){var service=new QuantixTweakingUtility.Services.NvidiaSettingsService();if(System.Linq.Enumerable.Any(QuantixTweakingUtility.Services.NvidiaSettingsService.LegacyOptions,option=>service.HasOriginal(option.Id)))panel.Children.Add(new Expander{Header="Restore previous NVIDIA profile switches",Content=new NvidiaSettingsPanel(),Foreground=System.Windows.Media.Brushes.LightSteelBlue});}
    private static ScrollViewer? FindScroll(DependencyObject? root){if(root is ScrollViewer viewer)return viewer;if(root==null)return null;foreach(var child in LogicalTreeHelper.GetChildren(root))if(child is DependencyObject dependency){var found=FindScroll(dependency);if(found!=null)return found;}return null;}
[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/QuantixTweakingUtility;component/quantixtweakingutility.views.gpuview.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.12.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		_contentLoaded = true;
	}
}




